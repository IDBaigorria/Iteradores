<?php
session_start();
header("Cache-control: no-cache, must-revalidate");

use Iteradores\Controlador\Controlador;
use Iteradores\Configuracion\Conf;
use Iteradores\Nodos\Nodo;

/**
 * Punto de entrada principal del framework.
 *
 * Orquesta la carga de todos los módulos del sistema en un orden
 * específico que garantiza la ausencia de dependencias circulares
 * y permite que los componentes se autoencolen correctamente en
 * {@link \Iteradores\Controlador\RegistroGlobal} antes de que el
 * {@link \Iteradores\Controlador\Controlador} sea inicializado.
 *
 * @author Ignacio David Baigorria
 * @package   Iteradores
 * @since     1.0.0
 * @version   1.5piloto.55
 */

// --- Utilidades base ----------------------------------
include_once("miscelaneas/benchmark.php");
include_once("miscelaneas/generarUUID.php");

// --- Configuración ------------------------------------
include_once("Configuracion/Configuracion.php");

// --- Núcleo -------------------------------------------
include_once("Nucleo/Objeto.php");

// --- Entorno (debe ir después de Objeto.php) ----------
include_once("Configuracion/Entorno.php");

// --- Nodos --------------------------------------------
include_once("Nodos/Nodo.php");
include_once("Nodos/NodoElectrico.php");
include_once("Nodos/Matriz2x2.php");
include_once("Nodos/NodoNumerico.php");
include_once("Nodos/NodoPrimo.php");
include_once("Nodos/NodoParalelo.php");

// --- V 1.4.8 – Comunicación: Señal y Antenas ---------
include_once("Iteradores/Senal.php");
include_once("Iteradores/AntenaComun.php");
include_once("Iteradores/AntenaDeMarcado.php");
include_once("Controlador/AntenaTraduccion.php");

// --- Iteradores ---------------------------------------
include_once("Controlador/ProcesadorDeDominio.php");
include_once("Controlador/Talamo.php");

// --- Tiempo -------------------------------------------
include_once("Tiempo/RelojAstronomico.php");

// --- Comandos y Comunicadores (autoencolación) ---------
include_once("Controlador/RegistroGlobal.php");
include_once("Comandos/index.php");
include_once("Comunicadores/index.php");

// --- Controlador (inicialización) ----------------------
include_once("Controlador/Controlador.php");

// Inicialización de la persistencia
Controlador::establecer_metodo('SQL');
$nombre_app = Conf::NOMBRE_APP;
if (Controlador::existe($nombre_app)) {
    Controlador::cargar($nombre_app);
} else {
    Controlador::guardar($nombre_app);
}

// Incluir módulos de la aplicación
require_once __DIR__ . '/Aplicacion/FuncionesAuxiliares.php';
require_once __DIR__ . '/Aplicacion/Usuarios/Usuario.php';
require_once __DIR__ . '/Aplicacion/Sesiones/Sesion.php';
require_once __DIR__ . '/Aplicacion/Admin/Admin.php';
require_once __DIR__ . '/Aplicacion/Autenticacion/Autenticacion.php';
require_once __DIR__ . '/Aplicacion/Empresas/Empresa.php';
require_once __DIR__ . '/Aplicacion/Vehiculos/Vehiculo.php';
require_once __DIR__ . '/Aplicacion/Viajes/Viaje.php';
require_once __DIR__ . '/Aplicacion/Ventas/Venta.php';
require_once __DIR__ . '/Aplicacion/Pasajeros/Pasajero.php';
require_once __DIR__ . '/Aplicacion/Rendiciones/Rendicion.php';
require_once __DIR__ . '/Aplicacion/Liquidaciones/Liquidacion.php';
require_once __DIR__ . '/Aplicacion/Enrutador.php';


// ==== Bloque temporal para pruebas de árbol ====
if (isset($_GET['probar_arbol'])) {
    require_once __DIR__ . '/miscelaneas/Arbol.php';
    require_once __DIR__ . '/miscelaneas/pruebas_arbol.php';
    exit;
}
// ==== Bloque temporal para migración de micros (versión 1.5piloto.27) ====
if (isset($_GET['migrar_micros'])) {
    require_once __DIR__ . '/miscelaneas/migrar_micros.php';
    header('Content-Type: text/plain; charset=utf-8');
    $res = migrar_micros_empresa();
    echo "Migración completada.\n";
    echo "Dueños procesados: {$res['duenos_procesados']}\n";
    echo "Micros procesados: {$res['micros_procesados']}\n";
    echo "Micros migrados:   {$res['micros_migrados']}\n";
    echo "Sin cambios:       {$res['micros_sin_cambio']}\n";
    echo "Sin empresa:       {$res['micros_sin_empresa']}\n";
    echo "Sin match:         {$res['micros_sin_match']}\n";
    exit;
}
// ==== Bloque temporal para migración de patente en micros (v1.5piloto.27) ====
if (isset($_GET['migrar_micros_patente'])) {
    require_once __DIR__ . '/miscelaneas/migrar_micros_patente.php';
    header('Content-Type: text/plain; charset=utf-8');
    $res = migrar_micros_patente();
    echo "Migración de patente completada.\n";
    echo "Micros procesados:  {$res['micros_procesados']}\n";
    echo "Micros limpiados:   {$res['micros_limpiados']}\n";
    echo "Sin enlace previo:  {$res['micros_sin_enlace']}\n";
    echo "Sin copia:          {$res['micros_sin_copia']}\n";
    exit;
}
// ==== Bloque temporal para migración de terminales autorizadas (v1.5piloto.31) ====
// Convierte los enlaces directos al Nodo Usuario terminal en nodos intermedios
// "TerminalViaje", que cuelgan del contenedor `terminales_autorizadas`.
// Es idempotente: si un enlace ya apunta a un TerminalViaje, lo saltea.
if (isset($_GET['migrar_terminales_autorizadas'])) {
    require_once __DIR__ . '/miscelaneas/migrar_terminales_autorizadas.php';
    header('Content-Type: text/plain; charset=utf-8');
    $res = migrar_terminales_autorizadas();
    echo "Migración de terminales autorizadas completada.\n";
    echo "Dueños procesados:         {$res['duenos_procesados']}\n";
    echo "Viajes procesados:         {$res['viajes_procesados']}\n";
    echo "Terminales migradas:       {$res['terminales_migradas']}\n";
    echo "Terminales sin cambio:     {$res['terminales_sin_cambio']}\n";
    echo "Terminales sin nodo usuario: {$res['terminales_sin_nodo_usuario']}\n";
    exit;
}
// ==== Bloque temporal para migración de cupones (v1.5piloto.44) ====
// Crea el contenedor `cupones` en cada venta existente que no lo tenga.
// Es idempotente: si una venta ya tiene cupones, la saltea.
if (isset($_GET['migrar_cupones'])) {
    require_once __DIR__ . '/miscelaneas/migrar_cupones.php';
    header('Content-Type: text/plain; charset=utf-8');
    $res = migrar_cupones();
    echo "Migración de cupones completada.\n";
    echo "Dueños procesados:    {$res['duenos_procesados']}\n";
    echo "Ventas procesadas:    {$res['ventas_procesadas']}\n";
    echo "Ventas migradas:      {$res['ventas_migradas']}\n";
    echo "Ventas ya migradas:   {$res['ventas_ya_migradas']}\n";
    echo "Ventas sin datos:     {$res['ventas_sin_datos']}\n";
    exit;
}

// ==== Bloque temporal para migración de nombres de pasajeros (v1.5piloto.36) ====
// Separa el campo `nombre` de cada pasajero en dos enlaces: `nombres` y `apellido`.
// Toma la última palabra como apellido y el resto como nombres. Si el nombre
// original tiene una sola palabra, el apellido queda vacío.
// Es idempotente: si un pasajero ya está migrado, lo saltea.
if (isset($_GET['migrar_nombres_pasajeros'])) {
    require_once __DIR__ . '/miscelaneas/migrar_nombres_pasajeros.php';
    header('Content-Type: text/plain; charset=utf-8');
    $res = migrar_nombres_pasajeros();
    echo "Migración de nombres de pasajeros completada.\n";
    echo "Dueños procesados:    {$res['duenos_procesados']}\n";
    echo "Pasajeros procesados: {$res['pasajeros_procesados']}\n";
    echo "Migrados:             {$res['migrados']}\n";
    echo "Sin cambio:           {$res['sin_cambio']}\n";
    echo "Sin nombre:           {$res['sin_nombre']}\n";
    echo "Sin apellido:         {$res['sin_apellido']}\n";
    exit;
}

// Crear usuario administrador si no existe
if (!buscar_usuario_por_codigo(Conf::CODIGO_ADMIN)) {
    $raiz_usuarios = Nodo::nodo_por_id('usuarios');
    if (!$raiz_usuarios) {
        Nodo::crear_con_id('usuarios');
        $raiz_usuarios = Nodo::nodo_por_id('usuarios');
    }
    $nodo_admin = Nodo::crear_con_dato(Conf::NOMBRE_ADMIN);
    $nodo_admin->_adyacente_en(Nodo::crear_con_dato(Conf::NOMBRE_ADMIN), 'nombre_real');
    $nodo_admin->_adyacente_en(Nodo::crear_con_dato('admin'), 'nivel');
    $nodo_admin->_adyacente_en(Nodo::crear_con_dato(Conf::CODIGO_ADMIN), 'codigo_acceso');
    $raiz_usuarios->_adyacente_en($nodo_admin, Conf::NOMBRE_ADMIN);
    Controlador::guardar($nombre_app);
    Controlador::establecer_metodo('JSON');
    Controlador::guardar($nombre_app);
}

// Manejo de impresión
if (isset($_GET['imprimir']) && $_GET['imprimir'] === '1') {
    require_once __DIR__ . '/Aplicacion/Impresion/Impresion.php';
    $tipo = $_GET['tipo'] ?? '';

    // Caso especial: informe de ventas de la pestaña Vendidos.
    // Se pasa el tipo de solicitante, el nombre, los filtros aplicados
    // y los datos del usuario que lo pide.
    if ($tipo === 'informe_ventas') {
        imprimir_informe_ventas($_GET);
        exit;
    }

    // Caso especial: pasaje de asiento reservado para el equipo (sin venta).
    // Se pasa dueño, viaje, micro, fila y columna por GET.
    if ($tipo === 'pasaje_reserva') {
        imprimir_pasaje_reserva(
            $_GET['dueno'] ?? '',
            $_GET['viaje'] ?? '',
            $_GET['micro'] ?? '',
            $_GET['fila'] ?? '',
            $_GET['columna'] ?? ''
        );
        exit;
    }
    // Caso especial: pasajes actualizados de un pasajero en viajes activos.
    // Se pasa dueño y DNI por GET.
    if ($tipo === 'pasajes_actualizados') {
        imprimir_pasajes_actualizados(
            $_GET['dueno'] ?? '',
            $_GET['dni'] ?? ''
        );
        exit;
    }

    // Caso especial: informe imprimible de una rendición.
    // Se pasa el id_rendicion por GET.
    if ($tipo === 'informe_rendicion') {
        imprimir_informe_rendicion($_GET['id_rendicion'] ?? '');
        exit;
    }

    // Caso especial: informe imprimible de una liquidación.
    // Si el dueño es quien imprime, el frontend manda
    // ocultar_datos_generales=1 para no mostrarle su propio nombre.
    if ($tipo === 'informe_liquidacion') {
        $ocultar_datos = ($_GET['ocultar_datos_generales'] ?? '0') === '1';
        imprimir_informe_liquidacion($_GET['id_liquidacion'] ?? '', $ocultar_datos);
        exit;
    }

    // Caso especial: informe imprimible de una cancelación de compra.
    if ($tipo === 'informe_cancelacion') {
        imprimir_informe_cancelacion($_GET['id_cancelacion'] ?? '');
        exit;
    }

    // Caso especial: croquis del micro con los pasajeros.
    if ($tipo === 'croquis_micro') {
        imprimir_croquis_micro(
            $_GET['dueno'] ?? '',
            $_GET['viaje'] ?? '',
            $_GET['micro'] ?? ''
        );
        exit;
    }

    // Caso especial: planilla de pasajeros del micro.
    if ($tipo === 'planilla_pasajeros_micro') {
        imprimir_planilla_pasajeros_micro(
            $_GET['dueno'] ?? '',
            $_GET['viaje'] ?? '',
            $_GET['micro'] ?? ''
        );
        exit;
    }
    $dni_filtro = $_GET['dni'] ?? '';
    $numero_cupon = $_GET['numero_cupon'] ?? '';
    generar_impresion($tipo, $_GET['id_venta'] ?? '', $dni_filtro, $numero_cupon);
    exit;
}

// Enrutar según método
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion'])) {
    header('Content-Type: application/json; charset=utf-8');
    enrutar_peticion_post($_POST['accion'], $_POST);
    Controlador::guardar($nombre_app);
    Controlador::establecer_metodo('JSON');
    Controlador::guardar($nombre_app);
    Controlador::imprimir_alertas();
    Controlador::imprimir_errores();
    exit;
}

// Si es GET, mostrar la interfaz
readfile(__DIR__ . '/aplicacion_GET.html');
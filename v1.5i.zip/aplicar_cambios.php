<?php
/**
 * Aplicador — Tanda C.4b: reparación de ciclos en árboles de cancelaciones.
 *
 * 1. Fix de _hmi en miscelaneas/Arbol.php: idempotente cuando el
 *    hijo ya es hmi; limpia hd residual cuando el padre no tenía
 *    hmi. Evita que migraciones futuras generen ciclos.
 *
 * 2. Nuevo comando app:reparar_cancelaciones_arboles: recorre cada
 *    árbol de cancelaciones (default del dueño + parametrizados
 *    de los compartidos), detecta ciclos y los reconstruye.
 *    Idempotente.
 *
 * 3. Endpoint ?reparar_cancelaciones_arboles=1 (admin, carga total).
 *
 * Uso (raíz del proyecto): php aplicar_cambios.php
 */

$modo_estricto = true;
$raiz_proyecto = __DIR__;
$version_nueva = '1.5piloto.81v';

$htmls_a_bumpear = ['aplicacion_GET.html'];

$cambios = [

// ============================================================
// 1. miscelaneas/Arbol.php: fix _hmi
// ============================================================
[
    'tipo' => 'reemplazar',
    'archivo' => 'miscelaneas/Arbol.php',
    'descripcion' => 'Fix _hmi: idempotente + limpiar hd residual',
    'buscar' => [
        'function _hmi(Nodo $padre, Nodo $hijo, ?array $nombres = null): void {',
        '    $n = _arbol_nombres($nombres);',
        '    $antiguo_hmi = $padre->adyacente($n[\'hmi\']);',
        '    if ($antiguo_hmi) {',
        '        // El nuevo hijo toma al antiguo hmi como su hermano derecho (reemplaza si existía)',
        '        $hijo->_adyacente_en($antiguo_hmi, $n[\'hd\'], true);',
        '    }',
        '    // Reemplazar el hmi del padre con el nuevo hijo',
        '    $padre->_adyacente_en($hijo, $n[\'hmi\'], true);',
        '    // Establecer el padre del hijo (reemplaza si ya tenía)',
        '    $hijo->_adyacente_en($padre, $n[\'p\'], true);',
        '}',
    ],
    'reemplazar' => [
        'function _hmi(Nodo $padre, Nodo $hijo, ?array $nombres = null): void {',
        '    $n = _arbol_nombres($nombres);',
        '    $antiguo_hmi = $padre->adyacente($n[\'hmi\']);',
        '',
        '    // Fix 1.5piloto.81v: idempotente y sin ciclos.',
        '    // Si el hijo ya es el hmi actual, no-op. Antes se dejaba',
        '    // al hijo con hd hacia sí mismo (autoenlace), lo que',
        '    // generaba ciclos al recorrer.',
        '    if ($antiguo_hmi && $antiguo_hmi->id() === $hijo->id()) {',
        '        return;',
        '    }',
        '',
        '    if ($antiguo_hmi) {',
        '        // El nuevo hijo toma al antiguo hmi como su hermano derecho.',
        '        $hijo->_adyacente_en($antiguo_hmi, $n[\'hd\'], true);',
        '    } else {',
        '        // Fix 1.5piloto.81v: si el padre no tenía hmi y el hijo',
        '        // traía un hd residual (por haber estado en otra cadena),',
        '        // limpiarlo. Antes quedaba apuntando a un nodo de otra',
        '        // cadena y formaba un ciclo.',
        '        $hijo->eliminar_adyacente($n[\'hd\']);',
        '    }',
        '    // Reemplazar el hmi del padre con el nuevo hijo',
        '    $padre->_adyacente_en($hijo, $n[\'hmi\'], true);',
        '    // Establecer el padre del hijo (reemplaza si ya tenía)',
        '    $hijo->_adyacente_en($padre, $n[\'p\'], true);',
        '}',
    ],
],

// ============================================================
// 2. RepararCancelaciones.php: nueva función de reparación de ciclos
// ============================================================
[
    'tipo' => 'reemplazar',
    'archivo' => 'Aplicacion/Reparacion/RepararCancelaciones.php',
    'descripcion' => 'Agregar reparar_cancelaciones_arboles',
    'buscar' => [
        '        $res[\'detalles\'][] = "$dato: huérfana reinsertada en compartido de $nombre_term y en árbol de $nombre_dueno";',
        '    }, null);',
        '',
        '    return $res;',
        '}',
    ],
    'reemplazar' => [
        '        $res[\'detalles\'][] = "$dato: huérfana reinsertada en compartido de $nombre_term y en árbol de $nombre_dueno";',
        '    }, null);',
        '',
        '    return $res;',
        '}',
        '',
        '/**',
        ' * Repara ciclos en los árboles de cancelaciones.',
        ' *',
        ' * Recorre cada árbol de cancelaciones:',
        ' *   - El del dueño (nombres default hmi/hd/p).',
        ' *   - Los de cada compartido (parametrizados hmi_<term>/hd_<term>/p_<term>).',
        ' *',
        ' * Si detecta un ciclo (un nodo ya visitado), desenlaza TODAS',
        ' * las aristas del árbol y lo reconstruye como cadena lineal,',
        ' * preservando el orden de visita. Idempotente.',
        ' *',
        ' * La causa raíz de los ciclos es el bug de _hmi al reinsertar',
        ' * nodos que ya estaban en la cadena (fix en v1.5piloto.81v).',
        ' *',
        ' * @param string $token',
        ' * @return array',
        ' * @since 1.5piloto.81v',
        ' */',
        'function reparar_cancelaciones_arboles(string $token): array {',
        '    require_once __DIR__ . \'/../../miscelaneas/Arbol.php\';',
        '',
        '    $res = [',
        '        \'cambios\' => 0,',
        '        \'duenos\' => 0,',
        '        \'compartidos\' => 0,',
        '        \'arboles_revisados\' => 0,',
        '        \'arboles_reconstruidos\' => 0,',
        '        \'detalles\' => [],',
        '    ];',
        '',
        '    $raiz = Nodo::nodo_por_id(\'usuarios\');',
        '    if (!$raiz) {',
        '        $res[\'detalles\'][] = \'No existe la raíz usuarios.\';',
        '        return $res;',
        '    }',
        '',
        '    foreach ($raiz->adyacentes() as $nombre_dueno => $nodo_dueno) {',
        '        $nombre_dueno = (string)$nombre_dueno;',
        '        $nivel = $nodo_dueno->adyacente(\'nivel\');',
        '        if (!$nivel || $nivel->dato() !== \'dueno\') continue;',
        '        $res[\'duenos\']++;',
        '',
        '        $nodo_dueno_real = Nodo::nodo_por_id(\'us_\' . $nombre_dueno);',
        '        if (!$nodo_dueno_real) continue;',
        '',
        '        // Compartidos (parametrizados).',
        '        foreach ($nodo_dueno_real->adyacentes() as $enlace => $nodo_comp) {',
        '            $enlace = (string)$enlace;',
        '            if (strpos($enlace, \'compartido_con_\') !== 0) continue;',
        '            if (!$nodo_comp->adyacente(\'_es_compartido\')) continue;',
        '            $res[\'compartidos\']++;',
        '',
        '            $nombre_term = _nombre_terminal_de_compartido($nodo_comp);',
        '            if ($nombre_term === \'\') continue;',
        '',
        '            $cont = $nodo_comp->adyacente(\'cancelaciones\');',
        '            if (!$cont) continue;',
        '',
        '            $nombres = [',
        '                \'p\'   => \'p_\'   . $nombre_term,',
        '                \'hd\'  => \'hd_\'  . $nombre_term,',
        '                \'hmi\' => \'hmi_\' . $nombre_term,',
        '            ];',
        '',
        '            $res[\'arboles_revisados\']++;',
        '            $r = _reconstruir_arbol_cadena_si_ciclo($cont, $nombres);',
        '            if ($r[\'reconstruido\']) {',
        '                $res[\'arboles_reconstruidos\']++;',
        '                $res[\'cambios\'] += $r[\'cambios\'];',
        '                $res[\'detalles\'][] = "$nombre_dueno/$nombre_term: " . $r[\'detalle\'];',
        '            }',
        '        }',
        '',
        '        // Árbol del dueño (default).',
        '        $cont = $nodo_dueno_real->adyacente(\'cancelaciones\');',
        '        if ($cont) {',
        '            $res[\'arboles_revisados\']++;',
        '            $r = _reconstruir_arbol_cadena_si_ciclo($cont, null);',
        '            if ($r[\'reconstruido\']) {',
        '                $res[\'arboles_reconstruidos\']++;',
        '                $res[\'cambios\'] += $r[\'cambios\'];',
        '                $res[\'detalles\'][] = "$nombre_dueno/default: " . $r[\'detalle\'];',
        '            }',
        '        }',
        '    }',
        '',
        '    return $res;',
        '}',
        '',
        '/**',
        ' * Detecta ciclo en la cadena del contenedor. Si hay ciclo,',
        ' * desenlaza y reconstruye como cadena lineal. Si no hay, no',
        ' * toca nada.',
        ' *',
        ' * @param Nodo       $contenedor',
        ' * @param array|null $nombres',
        ' * @return array {reconstruido: bool, cambios: int, detalle: string}',
        ' */',
        'function _reconstruir_arbol_cadena_si_ciclo(Nodo $contenedor, ?array $nombres): array {',
        '    $n = _arbol_nombres($nombres);',
        '    $hmi_enl = $n[\'hmi\'];',
        '    $hd_enl  = $n[\'hd\'];',
        '    $p_enl   = $n[\'p\'];',
        '',
        '    // 1. Recorrer la cadena detectando ciclo.',
        '    $nodos = [];',
        '    $visto = [];',
        '    $actual = $contenedor->adyacente($hmi_enl);',
        '    $seg = 0;',
        '    $hay_ciclo = false;',
        '    while ($actual && $seg < 5000) {',
        '        $id = (string)$actual->id();',
        '        if (isset($visto[$id])) {',
        '            $hay_ciclo = true;',
        '            break;',
        '        }',
        '        $visto[$id] = true;',
        '        $nodos[] = $actual;',
        '        $actual = $actual->adyacente($hd_enl);',
        '        $seg++;',
        '    }',
        '',
        '    if (empty($nodos)) {',
        '        return [\'reconstruido\' => false, \'cambios\' => 0, \'detalle\' => \'\'];',
        '    }',
        '    if (!$hay_ciclo) {',
        '        return [\'reconstruido\' => false, \'cambios\' => 0, \'detalle\' => \'\'];',
        '    }',
        '',
        '    // 2. Desenlazar todas las aristas del árbol.',
        '    foreach ($nodos as $nodo) {',
        '        $nodo->eliminar_adyacente($hd_enl);',
        '        $nodo->eliminar_adyacente($p_enl);',
        '    }',
        '    $contenedor->eliminar_adyacente($hmi_enl);',
        '',
        '    // 3. Reencadenar en el orden de visita.',
        '    $contenedor->_adyacente_en($nodos[0], $hmi_enl, true);',
        '    $nodos[0]->_adyacente_en($contenedor, $p_enl, true);',
        '    $cant = count($nodos);',
        '    for ($i = 1; $i < $cant; $i++) {',
        '        $nodos[$i - 1]->_adyacente_en($nodos[$i], $hd_enl, true);',
        '        $nodos[$i]->_adyacente_en($contenedor, $p_enl, true);',
        '    }',
        '',
        '    return [',
        '        \'reconstruido\' => true,',
        '        \'cambios\' => $cant + 1,',
        '        \'detalle\' => "ciclo roto: $cant nodos reencadenados",',
        '    ];',
        '}',
    ],
],

// ============================================================
// 3. Comandos.php: registrar el comando
// ============================================================
[
    'tipo' => 'reemplazar',
    'archivo' => 'Aplicacion/Reparacion/Comandos.php',
    'descripcion' => 'Registrar app:reparar_cancelaciones_arboles',
    'buscar' => [
        '    Controlador::registrar_comando(',
        '        \'app:reparar_cancelaciones_compartidos\',',
        '        function (string $token, array $args) {',
        '            require_once __DIR__ . \'/RepararCancelaciones.php\';',
        '            $res = reparar_cancelaciones_compartidos($token);',
        '            if (!empty($res[\'cambios\'])) {',
        '                guardar_ambos(ConfiguracionApli::NOMBRE_APP);',
        '            }',
        '            return $res;',
        '        },',
        '        null,',
        '        false // disponible en todos los entornos',
        '    );',
        '}',
    ],
    'reemplazar' => [
        '    Controlador::registrar_comando(',
        '        \'app:reparar_cancelaciones_compartidos\',',
        '        function (string $token, array $args) {',
        '            require_once __DIR__ . \'/RepararCancelaciones.php\';',
        '            $res = reparar_cancelaciones_compartidos($token);',
        '            if (!empty($res[\'cambios\'])) {',
        '                guardar_ambos(ConfiguracionApli::NOMBRE_APP);',
        '            }',
        '            return $res;',
        '        },',
        '        null,',
        '        false // disponible en todos los entornos',
        '    );',
        '',
        '    Controlador::registrar_comando(',
        '        \'app:reparar_cancelaciones_arboles\',',
        '        function (string $token, array $args) {',
        '            require_once __DIR__ . \'/RepararCancelaciones.php\';',
        '            $res = reparar_cancelaciones_arboles($token);',
        '            if (!empty($res[\'cambios\'])) {',
        '                guardar_ambos(ConfiguracionApli::NOMBRE_APP);',
        '            }',
        '            return $res;',
        '        },',
        '        null,',
        '        false // disponible en todos los entornos',
        '    );',
        '}',
    ],
],

// ============================================================
// 4. index.php: endpoint ?reparar_cancelaciones_arboles=1
// ============================================================
[
    'tipo' => 'reemplazar',
    'archivo' => 'index.php',
    'descripcion' => 'Endpoint ?reparar_cancelaciones_arboles=1',
    'buscar' => [
        '// ==== Eliminar huérfanos (v1.5piloto.81s) ====',
    ],
    'reemplazar' => [
        '// ==== Reparación de ciclos en árboles de cancelaciones (v1.5piloto.81v) ====',
        '// Recorre cada árbol de cancelaciones (default del dueño y',
        '// parametrizados de los compartidos). Si detecta ciclo,',
        '// desenlaza y reconstruye como cadena lineal.',
        '// Idempotente.',
        '// Uso: index.php?reparar_cancelaciones_arboles=1',
        'if (isset($_GET[\'reparar_cancelaciones_arboles\'])) {',
        '    header(\'Content-Type: text/plain; charset=utf-8\');',
        '    $res = Controlador::ejecutar_comando(\'app:reparar_cancelaciones_arboles\');',
        '',
        '    if (!is_array($res)) {',
        '        echo "ERROR: el comando app:reparar_cancelaciones_arboles no devolvió resultado.\\n";',
        '        exit;',
        '    }',
        '',
        '    echo "Reparación de ciclos en árboles de cancelaciones\\n";',
        '    echo "=================================================\\n\\n";',
        '    echo "Dueños procesados:       " . $res[\'duenos\'] . "\\n";',
        '    echo "Compartidos procesados:  " . $res[\'compartidos\'] . "\\n";',
        '    echo "Árboles revisados:       " . $res[\'arboles_revisados\'] . "\\n";',
        '    echo "Árboles reconstruidos:   " . $res[\'arboles_reconstruidos\'] . "\\n";',
        '    echo "Cambios totales:         " . $res[\'cambios\'] . "\\n";',
        '    echo "\\nDetalles:\\n";',
        '    foreach ($res[\'detalles\'] as $d) {',
        '        echo "  - $d\\n";',
        '    }',
        '    if ($res[\'cambios\'] > 0) {',
        '        echo "\\nGuardado.\\n";',
        '    }',
        '    echo "\\nListo.\\n";',
        '    exit;',
        '}',
        '',
        '// ==== Eliminar huérfanos (v1.5piloto.81s) ====',
    ],
],

];

// ============================================================
// Runner v2 (textual, ver prompt_sistema_scripts_v2.md §14)
// ============================================================

echo "=== Aplicador ===\n\n";

function detectar_eol(string $c): string { return (strpos($c, "\r\n") !== false) ? "\r\n" : "\n"; }
function normalizar_a_unix(string $c): string { return str_replace("\r\n", "\n", $c); }
function normalizar_a_original(string $c, string $e): string { return $e === "\n" ? $c : str_replace("\n", "\r\n", $c); }
function contar_ocurrencias(string $c, string $b): int {
    if ($b === '') return 0;
    $n = 0; $o = 0;
    while (($p = strpos($c, $b, $o)) !== false) { $n++; $o = $p + strlen($b); }
    return $n;
}

if (!isset($htmls_a_bumpear) || !is_array($htmls_a_bumpear)) {
    $htmls_a_bumpear = ['aplicacion_GET.html'];
}
if (!isset($version_nueva)) $version_nueva = '';
$version_nueva = trim((string)$version_nueva);
$bumpear = ($version_nueva !== '');

$creaciones = [];
$eliminaciones = [];
$reemplazos_por_archivo = [];

foreach ($cambios as $cambio) {
    $tipo = $cambio['tipo'] ?? 'reemplazar';
    if ($tipo === 'crear') { $creaciones[] = $cambio; continue; }
    if ($tipo === 'eliminar') { $eliminaciones[] = $cambio; continue; }
    if (!isset($cambio['archivo']) || !isset($cambio['buscar']) || !isset($cambio['reemplazar'])) {
        echo "[FALLO] Cambio mal formado.\n"; exit(1);
    }
    $reemplazos_por_archivo[$cambio['archivo']][] = $cambio;
}

$total_reemplazos = 0;
foreach ($reemplazos_por_archivo as $l) $total_reemplazos += count($l);
echo "[INFO] " . count($reemplazos_por_archivo) . " archivo(s) a reemplazar, "
    . count($creaciones) . " a crear, " . count($eliminaciones) . " a eliminar.\n\n";

$archivos_a_escribir = [];
$bloques_ok = 0;
$bloques_fallidos = [];

foreach ($reemplazos_por_archivo as $archivo_rel => $lista) {
    $ruta_abs = $raiz_proyecto . '/' . $archivo_rel;
    if (!file_exists($ruta_abs)) { $bloques_fallidos[] = "Archivo no encontrado: $archivo_rel"; continue; }
    $contenido_original = file_get_contents($ruta_abs);
    if ($contenido_original === false) { $bloques_fallidos[] = "No se pudo leer: $archivo_rel"; continue; }
    $eol = detectar_eol($contenido_original);
    $contenido = normalizar_a_unix($contenido_original);
    $contenido_antes = $contenido;
    $hubo_error = false;
    foreach ($lista as $cambio) {
        $buscar_str = implode("\n", $cambio['buscar']);
        $reemplazar_str = implode("\n", $cambio['reemplazar']);
        $n = contar_ocurrencias($contenido, $buscar_str);
        if ($n === 0) { $bloques_fallidos[] = "$archivo_rel: no encontrado - {$cambio['descripcion']}"; $hubo_error = true; continue; }
        if ($n > 1) { $bloques_fallidos[] = "$archivo_rel: ambiguo ($n) - {$cambio['descripcion']}"; $hubo_error = true; continue; }
        $contenido = str_replace($buscar_str, $reemplazar_str, $contenido);
        $bloques_ok++;
    }
    if (!$hubo_error && $contenido !== $contenido_antes) {
        $archivos_a_escribir[$ruta_abs] = [$contenido, $eol];
    }
}

if ($modo_estricto && !empty($bloques_fallidos)) {
    echo "=== ABORTADO ===\n";
    foreach ($bloques_fallidos as $f) echo "  [FALLO] $f\n";
    exit(1);
}

$archivos_bump_php_js = [];
$archivos_bump_js_css = [];
foreach ($archivos_a_escribir as $ruta_abs => $info) {
    $rel = substr($ruta_abs, strlen($raiz_proyecto) + 1);
    $ext = strtolower(pathinfo($ruta_abs, PATHINFO_EXTENSION));
    if ($ext === 'php' || $ext === 'js') $archivos_bump_php_js[] = $rel;
    if ($ext === 'js' || $ext === 'css') $archivos_bump_js_css[] = $rel;
}
foreach ($creaciones as $cr) {
    $ext = strtolower(pathinfo($cr['archivo'], PATHINFO_EXTENSION));
    if ($ext === 'php' || $ext === 'js') $archivos_bump_php_js[] = $cr['archivo'];
    if ($ext === 'js' || $ext === 'css') $archivos_bump_js_css[] = $cr['archivo'];
}

$bumps_atversion = 0;
$bumps_qv = 0;
$bumps_detalle = [];
$info_bumps = [];

if ($bumpear) {
    foreach (array_unique($archivos_bump_php_js) as $archivo_rel) {
        $ruta_abs = $raiz_proyecto . '/' . $archivo_rel;
        if (!file_exists($ruta_abs)) continue;
        if (isset($archivos_a_escribir[$ruta_abs])) {
            list($contenido, $eol) = $archivos_a_escribir[$ruta_abs];
        } else {
            $contenido_original = file_get_contents($ruta_abs);
            $eol = detectar_eol($contenido_original);
            $contenido = normalizar_a_unix($contenido_original);
        }
        $patron = '/(\*\s+@version\s+)(\S+)/';
        $viejo = '';
        $nuevo = preg_replace_callback($patron, function($m) use ($version_nueva, &$viejo) {
            $viejo = $m[2];
            return $m[1] . $version_nueva;
        }, $contenido, 1, $count);
        if ($count === 0) { $info_bumps[] = "$archivo_rel (sin @version)"; continue; }
        if ($viejo === $version_nueva) { continue; }
        $archivos_a_escribir[$ruta_abs] = [normalizar_a_unix($nuevo), $eol];
        $bumps_atversion++;
        $bumps_detalle[] = "$archivo_rel  @version $viejo -> $version_nueva";
    }

    foreach ($htmls_a_bumpear as $html_rel) {
        $html_abs = $raiz_proyecto . '/' . $html_rel;
        if (!file_exists($html_abs)) { $info_bumps[] = "$html_rel (no encontrado)"; continue; }
        if (isset($archivos_a_escribir[$html_abs])) {
            list($html, $eol) = $archivos_a_escribir[$html_abs];
        } else {
            $html_orig = file_get_contents($html_abs);
            $eol = detectar_eol($html_orig);
            $html = normalizar_a_unix($html_orig);
        }
        $html_antes = $html;
        foreach (array_unique($archivos_bump_js_css) as $archivo_rel) {
            $base = basename($archivo_rel);
            $base_esc = preg_quote($base, '/');
            $patron = '/(' . $base_esc . '\?v=)([^"\'\s>]+)/';
            $viejo_qv = '';
            $html = preg_replace_callback($patron, function($m) use ($version_nueva, &$viejo_qv) {
                $viejo_qv = $m[2];
                return $m[1] . $version_nueva;
            }, $html, 1, $c_qv);
            if ($c_qv > 0 && $viejo_qv !== $version_nueva) {
                $bumps_qv++;
                $bumps_detalle[] = "$html_rel  $base ?v= $viejo_qv -> $version_nueva";
            }
        }
        if ($html !== $html_antes) {
            $archivos_a_escribir[$html_abs] = [normalizar_a_unix($html), $eol];
        }
    }
}

$archivos_escritos = 0;
foreach ($archivos_a_escribir as $ruta_abs => $info) {
    list($contenido_unix, $eol) = $info;
    $contenido_final = normalizar_a_original($contenido_unix, $eol);
    if (file_put_contents($ruta_abs, $contenido_final) === false) {
        echo "[FALLO] No se pudo escribir: " . substr($ruta_abs, strlen($raiz_proyecto) + 1) . "\n";
        continue;
    }
    $archivos_escritos++;
    echo "[OK] " . substr($ruta_abs, strlen($raiz_proyecto) + 1) . "\n";
}

foreach ($creaciones as $creacion) {
    $ruta_abs = $raiz_proyecto . '/' . $creacion['archivo'];
    $dir_destino = dirname($ruta_abs);
    if (!is_dir($dir_destino)) mkdir($dir_destino, 0777, true);
    $contenido_nuevo = implode("\n", $creacion['contenido']);
    $ya_existia = file_exists($ruta_abs);
    if (file_put_contents($ruta_abs, $contenido_nuevo) === false) {
        echo "[FALLO] No se pudo crear: {$creacion['archivo']}\n"; continue;
    }
    $accion = $ya_existia ? 'sobrescrito' : 'creado';
    echo "[OK] {$creacion['archivo']} ($accion)\n";
}

foreach ($eliminaciones as $elim) {
    $ruta_abs = $raiz_proyecto . '/' . $elim['archivo'];
    if (!file_exists($ruta_abs)) { echo "[INFO] " . $elim['archivo'] . " no existía.\n"; continue; }
    if (unlink($ruta_abs)) echo "[OK] " . $elim['archivo'] . " (eliminado)\n";
    else echo "[FALLO] No se pudo eliminar: " . $elim['archivo'] . "\n";
}

if ($bumpear && (!empty($bumps_detalle) || !empty($info_bumps))) {
    echo "\n--- Bumps ---\n";
    foreach ($bumps_detalle as $d) echo "[BUMP] $d\n";
    foreach ($info_bumps as $i) echo "[INFO] $i\n";
}

echo "\n=== Resumen ===\n";
echo "Bloques aplicados: $bloques_ok\n";
echo "Archivos escritos: $archivos_escritos\n";
if ($bumpear) {
    echo "Bumps @version:    $bumps_atversion\n";
    echo "Bumps ?v=:         $bumps_qv\n";
}
if (!empty($bloques_fallidos)) {
    echo "Fallos: " . count($bloques_fallidos) . "\n";
    foreach ($bloques_fallidos as $f) echo "  - $f\n";
}
echo "\nListo.\n";
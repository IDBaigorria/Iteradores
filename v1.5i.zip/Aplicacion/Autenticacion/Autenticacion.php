<?php
/**
 * Autenticación de usuarios por código de acceso.
 *
 * @package   Iteradores
 * @since     1.5piloto.1
 * @version   1.5piloto.70
 */

use Iteradores\Configuracion\Conf;
use Iteradores\Nodos\Nodo;
include_once("./Configuracion/Configuracion.php");
include_once("./Nodos/Nodo.php");

/**
 * Autentica a un usuario mediante su código de acceso.
 *
 * @param string $codigo Código de acceso.
 * @return array|null Datos del usuario autenticado o null.
 */
function autenticar_por_codigo(string $codigo): ?array {
    $nombre_usuario = null;
    en_grafo_credenciales(function() use ($codigo, &$nombre_usuario) {
        $resultado = buscar_usuario_por_codigo($codigo);
        if ($resultado !== null) {
            $nombre_usuario = $resultado['nombre_usuario'];
        }
    });

    if ($nombre_usuario === null) {
        if (verificar_codigo_admin($codigo)) {
            $nombre_usuario = Conf::NOMBRE_ADMIN;
        } else {
            return null;
        }
    }

    // Leer datos visibles del usuario desde el grafo de la aplicación.
    $raiz_app = Nodo::nodo_por_id('usuarios');
    if (!$raiz_app) return null;
    $nodo_app = $raiz_app->adyacente($nombre_usuario);
    if (!$nodo_app) return null;

    $nodo_nivel = $nodo_app->adyacente('nivel');
    $nodo_nombre_real = $nodo_app->adyacente('nombre_real');

    $usuario = [
        'nombre_usuario' => $nombre_usuario,
        'nombre_real' => $nodo_nombre_real ? $nodo_nombre_real->dato() : $nombre_usuario,
        'nivel' => $nodo_nivel ? $nodo_nivel->dato() : 'terminal',
    ];

    $token = crear_sesion($nombre_usuario);
    $usuario['token_sesion'] = $token;

    return $usuario;
}

/**
 * Valida un token de sesión y devuelve el nombre de usuario y su nodo.
 *
 * @param string $token Token de sesión.
 * @return array|null Array con 'nombre_usuario' y 'nodo', o null si no es válido.
 */
function validar_token_sesion(string $token): ?array {
    $nombre_usuario = null;
    en_grafo_credenciales(function() use ($token, &$nombre_usuario) {
        $raiz = Nodo::nodo_por_id('sesiones');
        if (!$raiz) return;

        $nodo_sesion = $raiz->adyacente($token);
        if (!$nodo_sesion) return;

        $nodo_usuario = $nodo_sesion->adyacente('usuario');
        if (!$nodo_usuario) return;

        $nombre_usuario = $nodo_usuario->dato();
    });

    if ($nombre_usuario === null) return null;

    $raiz_usuarios = Nodo::nodo_por_id('usuarios');
    if (!$raiz_usuarios) return null;

    $nodo_usuario_real = $raiz_usuarios->adyacente($nombre_usuario);
    if (!$nodo_usuario_real) return null;

    return [
        'nombre_usuario' => $nombre_usuario,
        'nodo' => $nodo_usuario_real,
    ];
}

/**
 * Autentica a un usuario mediante su nombre y contraseña.
 *
 * @param string $nombre_usuario Nombre de usuario.
 * @param string $contrasena Contraseña en texto plano.
 * @return array|null Datos del usuario autenticado o null.
 */
function autenticar_por_usuario(string $nombre_usuario, string $contrasena): ?array {
    $verificado = false;
    en_grafo_credenciales(function() use ($nombre_usuario, $contrasena, &$verificado) {
        $raiz_usuarios = Nodo::nodo_por_id('usuarios');
        if (!$raiz_usuarios) {
            password_verify($contrasena, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');
            return;
        }

        $nodo_usuario = $raiz_usuarios->adyacente($nombre_usuario);
        if (!$nodo_usuario) {
            password_verify($contrasena, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');
            return;
        }

        $nodo_contrasena = $nodo_usuario->adyacente('contrasena');
        if (!$nodo_contrasena) {
            password_verify($contrasena, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');
            return;
        }

        if (!password_verify($contrasena, $nodo_contrasena->dato())) {
            return;
        }

        $verificado = true;
    });

    if (!$verificado) return null;

    // Leer datos visibles del usuario desde el grafo de la aplicación.
    $raiz_app = Nodo::nodo_por_id('usuarios');
    if (!$raiz_app) return null;
    $nodo_app = $raiz_app->adyacente($nombre_usuario);
    if (!$nodo_app) return null;

    $nodo_nivel = $nodo_app->adyacente('nivel');
    $nodo_nombre_real = $nodo_app->adyacente('nombre_real');

    $usuario = [
        'nombre_usuario' => $nombre_usuario,
        'nombre_real' => $nodo_nombre_real ? $nodo_nombre_real->dato() : $nombre_usuario,
        'nivel' => $nodo_nivel ? $nodo_nivel->dato() : 'terminal',
    ];

    $token = crear_sesion($nombre_usuario);
    $usuario['token_sesion'] = $token;

    return $usuario;
}

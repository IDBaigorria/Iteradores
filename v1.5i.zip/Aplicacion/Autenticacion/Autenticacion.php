<?php
/**
 * Autenticación de usuarios por código de acceso.
 *
 * @package   Iteradores
 * @version   1.5piloto.1
 */

/**
 * Autentica a un usuario mediante su código de acceso.
 *
 * @param string $codigo Código de acceso.
 * @return array|null Datos del usuario autenticado o null.
 */
function autenticar_por_codigo(string $codigo): ?array {
    // Primero intentar con usuario normal
    $usuario = buscar_usuario_por_codigo($codigo);
    if ($usuario) {
        return $usuario;
    }

    // Si no existe, verificar si es el código maestro de admin
    if (verificar_codigo_admin($codigo)) {
        // Devolver un usuario admin ficticio (no persistido)
        return [
            'nombre_usuario' => 'admin',
            'nombre_real' => 'Administrador',
            'nivel' => 'admin',
        ];
    }

    return null;
}
<?php
/**
 * Gestión de ventas persistentes.
 *
 * @package   Iteradores
 * @since     1.5piloto.13
 */

use Iteradores\Nodos\Nodo;
use Iteradores\Controlador\Controlador;
use Iteradores\Configuracion\Conf;
include_once("./Configuracion/Configuracion.php");
include_once("./Nodos/Nodo.php");
include_once("./Controlador/Controlador.php");

/**
 * Obtiene el contenedor de ventas de un dueño, creándolo si no existe.
 */
function obtener_contenedor_ventas_dueno(string $nombre_dueno) {
    $raiz_usuarios = Nodo::nodo_por_id('usuarios');
    if (!$raiz_usuarios) return null;

    $nodo_dueno = $raiz_usuarios->adyacente($nombre_dueno);
    if (!$nodo_dueno) return null;

    $nodo_ventas = $nodo_dueno->adyacente('ventas');
    if (!$nodo_ventas) {
        $nodo_ventas = Nodo::crear_con_dato('');
        $nodo_dueno->_adyacente_en($nodo_ventas, 'ventas');
        // Crear cabeza de lista circular
        $cabeza = Nodo::crear_con_dato('');
        $nodo_ventas->_adyacente_en($cabeza, 'cabeza');
        $cabeza->_adyacente_en($cabeza, 'primer'); // apunta a sí mismo inicialmente
    }
    return $nodo_ventas;
}

/**
 * Obtiene la cabeza de la lista circular de ventas de un dueño.
 */
function obtener_cabeza_ventas_dueno(string $nombre_dueno) {
    $contenedor = obtener_contenedor_ventas_dueno($nombre_dueno);
    if (!$contenedor) return null;
    return $contenedor->adyacente('cabeza');
}

/**
 * Crea un nodo pasajero si no existe, basado en DNI.
 */
function obtener_o_crear_pasajero(string $dni, array $datos_pasajero): ?Nodo {
    $dni = trim($dni);
    if (empty($dni)) return null;

    $raiz_pasajeros = Nodo::nodo_por_id('pasajeros');
    if (!$raiz_pasajeros) {
        $raiz_pasajeros = Nodo::crear_con_id('pasajeros');
    }

    $nodo_pasajero = $raiz_pasajeros->adyacente($dni);
    if (!$nodo_pasajero) {
        $nodo_pasajero = Nodo::crear_con_dato($dni);
        $raiz_pasajeros->_adyacente_en($nodo_pasajero, $dni);
    }

    // Actualizar datos si se proporcionan
    $campos = ['nombre', 'email', 'celular', 'celular_emergencia'];
    foreach ($campos as $campo) {
        if (isset($datos_pasajero[$campo]) && $datos_pasajero[$campo] !== '') {
            $nodo_campo = $nodo_pasajero->adyacente($campo);
            if ($nodo_campo) $nodo_campo->_dato($datos_pasajero[$campo]);
            else $nodo_pasajero->_adyacente_en(Nodo::crear_con_dato($datos_pasajero[$campo]), $campo);
        }
    }

    return $nodo_pasajero;
}

/**
 * Actualiza los contadores de un micro (ocupación, seleccionados, vendidos) basado en los estados reales de sus asientos.
 */
function actualizar_contadores_micro(Nodo $nodo_micro): void {
    $nodo_copia = $nodo_micro->adyacente('vehiculo_copia');
    if (!$nodo_copia) return;

    $total = 0;
    $seleccionados = 0;
    $vendidos = 0;
    $nodo_asientos = $nodo_copia->adyacente('asientos');
    if ($nodo_asientos) {
        for ($i = 1; $i <= 2; $i++) {
            $piso = $nodo_asientos->adyacente("piso_$i");
            if (!$piso) continue;
            $cabeza = $piso->adyacente('asientos');
            if (!$cabeza) continue;
            $actual = $cabeza->adyacente('primer');
            $contador_seguridad = 0;
            while ($actual && $actual->id() !== $cabeza->id() && $contador_seguridad < 1000) {
                $estado = $actual->adyacente('estado');
                if ($estado) {
                    $estado_str = $estado->dato();
                    if ($estado_str === 'seleccionado') $seleccionados++;
                    elseif ($estado_str === 'vendido' || $estado_str === 'no disponible') $vendidos++;
                    $total++;
                }
                $actual = $actual->adyacente('siguiente');
                $contador_seguridad++;
            }
        }
    }

    $nodo_micro->adyacente('ocupacion')?->_dato((string)$total);
    $nodo_micro->adyacente('seleccionados')?->_dato((string)$seleccionados);
    $nodo_micro->adyacente('vendidos')?->_dato((string)$vendidos);
}

/**
 * Confirma la venta actual de una terminal, creando una venta persistente.
 *
 * @param string $nombre_terminal Nombre de la terminal.
 * @param string $metodo_pago 'efectivo' o 'transferencia'.
 * @param int    $cuotas Número de cuotas (1-3, solo efectivo).
 * @param int    $pago_inicial Número de cuotas pagadas ahora (0-3).
 * @param string $comprador_dni DNI del comprador (puede ser uno de los pasajeros).
 * @param array  $pasajeros_por_asiento Array asociativo: [posicion => ['dni'=>..., 'nombre'=>..., 'email'=>..., 'celular'=>..., 'celular_emergencia'=>...]]
 * @return array Resultado con éxito o error.
 */
function confirmar_venta_actual(string $nombre_terminal, string $metodo_pago, int $cuotas, int $pago_inicial, string $comprador_dni, array $pasajeros_por_asiento): array {
    $raiz_usuarios = Nodo::nodo_por_id('usuarios');
    if (!$raiz_usuarios) return ['exito' => false, 'error' => 'No hay usuarios registrados'];

    $nodo_terminal = $raiz_usuarios->adyacente($nombre_terminal);
    if (!$nodo_terminal) return ['exito' => false, 'error' => 'Terminal no encontrada'];

    $venta_actual = $nodo_terminal->adyacente('venta_actual');
    if (!$venta_actual) return ['exito' => false, 'error' => 'No hay venta actual'];

    // Obtener micro y viaje de la venta actual
    $nodo_nombre_micro = $venta_actual->adyacente('micro');
    $nodo_nombre_viaje = $venta_actual->adyacente('viaje');
    if (!$nodo_nombre_micro || !$nodo_nombre_viaje) {
        return ['exito' => false, 'error' => 'Venta actual incompleta'];
    }

    $nombre_micro = $nodo_nombre_micro->dato();
    $nombre_viaje = $nodo_nombre_viaje->dato();

    // Obtener dueño desde la terminal
    $nodo_dueno = $nodo_terminal->adyacente('dueno');
    if (!$nodo_dueno) return ['exito' => false, 'error' => 'La terminal no tiene dueño asignado'];
    $nombre_dueno = $nodo_dueno->dato();

    // Obtener viaje y micro
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'No se encontraron viajes del dueño'];

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    $nodo_micros = $nodo_viaje->adyacente('micros');
    if (!$nodo_micros) return ['exito' => false, 'error' => 'No hay micros en el viaje'];

    $nodo_micro = $nodo_micros->adyacente($nombre_micro);
    if (!$nodo_micro) return ['exito' => false, 'error' => 'Micro no encontrado'];

    // Validar método de pago y cuotas
    $metodo_pago = strtolower($metodo_pago);
    if (!in_array($metodo_pago, ['efectivo', 'transferencia'])) {
        return ['exito' => false, 'error' => 'Método de pago inválido'];
    }
    if ($metodo_pago === 'transferencia') {
        $cuotas = 1; // forzar 1 cuota
        $pago_inicial = 1; // paga todo
    } else {
        if ($cuotas < 1 || $cuotas > 3) {
            return ['exito' => false, 'error' => 'Cantidad de cuotas inválida (1-3)'];
        }
        if ($pago_inicial < 0 || $pago_inicial > $cuotas) {
            return ['exito' => false, 'error' => 'Cuotas pagadas ahora inválidas'];
        }
    }

    // Recorrer lista circular de asientos-en-venta de la venta actual
    $cabeza_venta_actual = $venta_actual->adyacente('asientos');
    if (!$cabeza_venta_actual) return ['exito' => false, 'error' => 'Venta actual sin asientos'];

    $asientos_seleccionados = [];
    $actual_venta = $cabeza_venta_actual->adyacente('primer');
    $contador_seguridad = 0;
    while ($actual_venta && $actual_venta->id() !== $cabeza_venta_actual->id() && $contador_seguridad < 100) {
        $asiento_real = $actual_venta->adyacente('asiento');
        if ($asiento_real) {
            $asientos_seleccionados[] = $asiento_real;
        }
        $actual_venta = $actual_venta->adyacente('siguiente');
        $contador_seguridad++;
    }

    if (empty($asientos_seleccionados)) {
        return ['exito' => false, 'error' => 'No hay asientos seleccionados'];
    }

    // Obtener monto del micro
    $nodo_monto = $nodo_micro->adyacente('monto');
    $monto_por_asiento = $nodo_monto ? (float)$nodo_monto->dato() : 0;
    $total = $monto_por_asiento * count($asientos_seleccionados);

    // Calcular monto pagado inicial
    $monto_pagado = 0;
    if ($metodo_pago === 'efectivo') {
        if ($cuotas > 0) {
            $monto_pagado = ($total / $cuotas) * $pago_inicial;
        }
    } else { // transferencia
        $monto_pagado = $total;
    }

    // Crear nodo venta persistente
    $id_venta = 'venta_' . time();
    $nodo_venta = Nodo::crear_con_dato($id_venta);
    $nodo_venta->_adyacente_en($nodo_terminal, 'terminal');
    $nodo_venta->_adyacente_en($nodo_viaje, 'viaje');
    $nodo_venta->_adyacente_en($nodo_micro, 'micro');
    $nodo_venta->_adyacente_en(Nodo::crear_con_dato((string)time()), 'fecha_hora');
    $nodo_venta->_adyacente_en(Nodo::crear_con_dato($metodo_pago), 'metodo_pago');
    $nodo_venta->_adyacente_en(Nodo::crear_con_dato((string)$total), 'total');
    $nodo_venta->_adyacente_en(Nodo::crear_con_dato((string)$cuotas), 'cuotas');
    $nodo_venta->_adyacente_en(Nodo::crear_con_dato((string)$monto_pagado), 'pagado');

    // Obtener o crear comprador
    $comprador_datos = [];
    // Si el comprador es uno de los pasajeros, obtener sus datos
    if (!empty($comprador_dni)) {
        // Buscar en pasajeros_por_asiento
        foreach ($pasajeros_por_asiento as $pasajero) {
            if (isset($pasajero['dni']) && $pasajero['dni'] === $comprador_dni) {
                $comprador_datos = $pasajero;
                break;
            }
        }
        if (empty($comprador_datos)) {
            // Si no está en asientos, crear con datos mínimos
            $comprador_datos = ['nombre' => '', 'email' => '', 'celular' => '', 'celular_emergencia' => ''];
        }
    }
    $nodo_comprador = obtener_o_crear_pasajero($comprador_dni, $comprador_datos);
    if ($nodo_comprador) {
        $nodo_venta->_adyacente_en($nodo_comprador, 'comprador');
    }

    // Crear lista circular de asientos-en-venta persistente
    $cabeza_venta_persistente = Nodo::crear_con_dato('');
    $nodo_venta->_adyacente_en($cabeza_venta_persistente, 'asientos');

    $primer_nodo = null;
    $anterior_nodo = null;

    // Procesar cada asiento
    $indice_asiento = 0;
    foreach ($asientos_seleccionados as $asiento_real) {
        // Obtener datos del pasajero para este asiento
        $datos_pasajero = $pasajeros_por_asiento[$indice_asiento] ?? [];
        $dni_pasajero = $datos_pasajero['dni'] ?? '';
        if (empty($dni_pasajero)) {
            return ['exito' => false, 'error' => 'Falta DNI para el asiento ' . ($indice_asiento + 1)];
        }

        // Obtener o crear pasajero
        $nodo_pasajero = obtener_o_crear_pasajero($dni_pasajero, $datos_pasajero);
        if (!$nodo_pasajero) {
            return ['exito' => false, 'error' => 'No se pudo crear el pasajero para el asiento ' . ($indice_asiento + 1)];
        }

        // Cambiar estado del asiento real
        $estado = $asiento_real->adyacente('estado');
        if ($estado) $estado->_dato('vendido');
        else $asiento_real->_adyacente_en(Nodo::crear_con_dato('vendido'), 'estado');

        // Eliminar seleccionado_por
        $asiento_real->eliminar_adyacente('seleccionado_por');

        // Enlazar pasajero y venta al asiento real
        $asiento_real->eliminar_adyacente('pasajero');
        $asiento_real->_adyacente_en($nodo_pasajero, 'pasajero');
        $asiento_real->eliminar_adyacente('venta');
        $asiento_real->_adyacente_en($nodo_venta, 'venta');

        // Crear nodo asiento-en-venta persistente
        $nodo_asiento_venta = Nodo::crear_con_dato('');
        $nodo_asiento_venta->_adyacente_en($asiento_real, 'asiento');
        $nodo_asiento_venta->_adyacente_en($nodo_pasajero, 'pasajero');

        // Agregar a lista circular
        if ($anterior_nodo) {
            $anterior_nodo->_adyacente_en($nodo_asiento_venta, 'siguiente');
        } else {
            $primer_nodo = $nodo_asiento_venta;
        }
        $anterior_nodo = $nodo_asiento_venta;

        $indice_asiento++;
    }

    // Cerrar lista circular persistente
    if ($anterior_nodo) {
        $anterior_nodo->_adyacente_en($cabeza_venta_persistente, 'siguiente');
    }
    if ($primer_nodo) {
        $cabeza_venta_persistente->_adyacente_en($primer_nodo, 'primer');
    }

    // Actualizar contadores del micro
    actualizar_contadores_micro($nodo_micro);
    // Actualizar contadores del viaje
    actualizar_contadores_viaje($nombre_viaje, $nombre_dueno);

    // Actualizar montos de terminal
    if ($metodo_pago === 'efectivo') {
        $nodo_efectivo = $nodo_terminal->adyacente('efectivo');
        if (!$nodo_efectivo) {
            $nodo_efectivo = Nodo::crear_con_dato('0');
            $nodo_terminal->_adyacente_en($nodo_efectivo, 'efectivo');
        }
        $nuevo_efectivo = (float)$nodo_efectivo->dato() + $monto_pagado;
        $nodo_efectivo->_dato((string)$nuevo_efectivo);
    } else { // transferencia
        $nodo_banco = $nodo_terminal->adyacente('banco');
        if (!$nodo_banco) {
            return ['exito' => false, 'error' => 'La terminal no tiene datos bancarios'];
        }
        $monto_banco_actual = (float)$nodo_banco->dato();
        $nodo_banco->_dato((string)($monto_banco_actual + $monto_pagado));
    }

    // Registrar venta en lista circular del dueño
    $cabeza_ventas_dueno = obtener_cabeza_ventas_dueno($nombre_dueno);
    if (!$cabeza_ventas_dueno) {
        return ['exito' => false, 'error' => 'No se pudo obtener contenedor de ventas del dueño'];
    }

    // Insertar al principio de la lista circular
    $primer_actual = $cabeza_ventas_dueno->adyacente('primer');
    $nodo_venta->_adyacente_en($primer_actual ?: $cabeza_ventas_dueno, 'siguiente');
    $cabeza_ventas_dueno->_adyacente_en($nodo_venta, 'primer');

    // Eliminar venta actual de la terminal
    $nodo_terminal->eliminar_adyacente('venta_actual');
    // Eliminar nodos huérfanos de la venta actual (opcional, no implementado profundamente)

    Controlador::guardar(Conf::NOMBRE_APP);

    return [
        'exito' => true,
        'id_venta' => $id_venta,
        'total' => (string)$total,
        'pagado' => (string)$monto_pagado,
        'asientos' => count($asientos_seleccionados),
    ];
}

/**
 * Lista ventas de un dueño (recorriendo su lista circular).
 */
function listar_ventas_por_dueno(string $nombre_dueno): array {
    $cabeza = obtener_cabeza_ventas_dueno($nombre_dueno);
    if (!$cabeza) return [];

    $ventas = [];
    $actual = $cabeza->adyacente('primer');
    $contador_seguridad = 0;
    while ($actual && $actual->id() !== $cabeza->id() && $contador_seguridad < 1000) {
        $ventas[] = formatear_venta_resumida($actual);
        $actual = $actual->adyacente('siguiente');
        $contador_seguridad++;
    }
    return $ventas;
}

/**
 * Lista ventas de una terminal (filtra las del dueño).
 */
function listar_ventas_por_terminal(string $nombre_terminal): array {
    $raiz_usuarios = Nodo::nodo_por_id('usuarios');
    if (!$raiz_usuarios) return [];

    $nodo_terminal = $raiz_usuarios->adyacente($nombre_terminal);
    if (!$nodo_terminal) return [];

    $nodo_dueno = $nodo_terminal->adyacente('dueno');
    if (!$nodo_dueno) return [];

    $nombre_dueno = $nodo_dueno->dato();
    $ventas_dueno = listar_ventas_por_dueno($nombre_dueno);
    $ventas_terminal = array_filter($ventas_dueno, function($venta) use ($nombre_terminal) {
        return $venta['terminal'] === $nombre_terminal;
    });

    return array_values($ventas_terminal);
}

/**
 * Devuelve un resumen formateado de una venta.
 */
function formatear_venta_resumida(Nodo $nodo_venta): array {
    $id_venta = $nodo_venta->dato();
    $nodo_terminal = $nodo_venta->adyacente('terminal');
    $nodo_viaje = $nodo_venta->adyacente('viaje');
    $nodo_micro = $nodo_venta->adyacente('micro');
    $nodo_total = $nodo_venta->adyacente('total');
    $nodo_fecha = $nodo_venta->adyacente('fecha_hora');

    $nombre_terminal = $nodo_terminal ? $nodo_terminal->dato() : '';
    $nombre_viaje = $nodo_viaje ? $nodo_viaje->dato() : '';
    $nombre_micro = $nodo_micro ? ($nodo_micro->adyacente('patente') ? $nodo_micro->adyacente('patente')->dato() : '') : '';
    $total = $nodo_total ? $nodo_total->dato() : '0';
    $fecha = $nodo_fecha ? date('Y-m-d H:i:s', (int)$nodo_fecha->dato()) : '';

    // Contar asientos
    $cantidad_asientos = 0;
    $cabeza_asientos = $nodo_venta->adyacente('asientos');
    if ($cabeza_asientos) {
        $actual = $cabeza_asientos->adyacente('primer');
        $seguridad = 0;
        while ($actual && $actual->id() !== $cabeza_asientos->id() && $seguridad < 100) {
            $cantidad_asientos++;
            $actual = $actual->adyacente('siguiente');
            $seguridad++;
        }
    }

    return [
        'id_venta' => $id_venta,
        'terminal' => $nombre_terminal,
        'viaje' => $nombre_viaje,
        'micro' => $nombre_micro,
        'total' => $total,
        'fecha' => $fecha,
        'cantidad_asientos' => $cantidad_asientos,
    ];
}

/**
 * Obtiene el detalle completo de una venta por su ID (búsqueda en todos los dueños).
 */
function obtener_venta_por_id(string $id_venta): ?array {
    $raiz_usuarios = Nodo::nodo_por_id('usuarios');
    if (!$raiz_usuarios) return null;

    foreach ($raiz_usuarios->adyacentes() as $nombre_dueno => $nodo_dueno) {
        $nodo_nivel = $nodo_dueno->adyacente('nivel');
        if (!$nodo_nivel || $nodo_nivel->dato() !== 'dueno') continue;

        $cabeza = obtener_cabeza_ventas_dueno($nombre_dueno);
        if (!$cabeza) continue;

        $actual = $cabeza->adyacente('primer');
        $seguridad = 0;
        while ($actual && $actual->id() !== $cabeza->id() && $seguridad < 1000) {
            if ($actual->dato() === $id_venta) {
                return formatear_venta_completa($actual);
            }
            $actual = $actual->adyacente('siguiente');
            $seguridad++;
        }
    }
    return null;
}

/**
 * Formatea una venta con todos sus detalles (asientos, pasajeros, etc.).
 */
function formatear_venta_completa(Nodo $nodo_venta): array {
    $datos = formatear_venta_resumida($nodo_venta);
    $datos['metodo_pago'] = $nodo_venta->adyacente('metodo_pago') ? $nodo_venta->adyacente('metodo_pago')->dato() : '';
    $datos['cuotas'] = $nodo_venta->adyacente('cuotas') ? $nodo_venta->adyacente('cuotas')->dato() : '1';
    $datos['pagado'] = $nodo_venta->adyacente('pagado') ? $nodo_venta->adyacente('pagado')->dato() : '0';

    $nodo_comprador = $nodo_venta->adyacente('comprador');
    if ($nodo_comprador) {
        $datos['comprador'] = [
            'dni' => $nodo_comprador->dato(),
            'nombre' => $nodo_comprador->adyacente('nombre') ? $nodo_comprador->adyacente('nombre')->dato() : '',
            'email' => $nodo_comprador->adyacente('email') ? $nodo_comprador->adyacente('email')->dato() : '',
            'celular' => $nodo_comprador->adyacente('celular') ? $nodo_comprador->adyacente('celular')->dato() : '',
            'celular_emergencia' => $nodo_comprador->adyacente('celular_emergencia') ? $nodo_comprador->adyacente('celular_emergencia')->dato() : '',
        ];
    }

    // Asientos con pasajeros
    $asientos = [];
    $cabeza_asientos = $nodo_venta->adyacente('asientos');
    if ($cabeza_asientos) {
        $actual = $cabeza_asientos->adyacente('primer');
        $seguridad = 0;
        while ($actual && $actual->id() !== $cabeza_asientos->id() && $seguridad < 100) {
            $nodo_asiento_real = $actual->adyacente('asiento');
            $nodo_pasajero = $actual->adyacente('pasajero');
            $asiento_info = [
                'numero' => $nodo_asiento_real ? $nodo_asiento_real->dato() : '',
                'fila' => $nodo_asiento_real && $nodo_asiento_real->adyacente('fila') ? $nodo_asiento_real->adyacente('fila')->dato() : '',
                'columna' => $nodo_asiento_real && $nodo_asiento_real->adyacente('columna') ? $nodo_asiento_real->adyacente('columna')->dato() : '',
            ];
            if ($nodo_pasajero) {
                $asiento_info['pasajero'] = [
                    'dni' => $nodo_pasajero->dato(),
                    'nombre' => $nodo_pasajero->adyacente('nombre') ? $nodo_pasajero->adyacente('nombre')->dato() : '',
                    'email' => $nodo_pasajero->adyacente('email') ? $nodo_pasajero->adyacente('email')->dato() : '',
                    'celular' => $nodo_pasajero->adyacente('celular') ? $nodo_pasajero->adyacente('celular')->dato() : '',
                    'celular_emergencia' => $nodo_pasajero->adyacente('celular_emergencia') ? $nodo_pasajero->adyacente('celular_emergencia')->dato() : '',
                ];
            }
            $asientos[] = $asiento_info;
            $actual = $actual->adyacente('siguiente');
            $seguridad++;
        }
    }
    $datos['asientos'] = $asientos;

    return $datos;
}

/**
 * Cancela una venta: libera asientos, revierte montos y elimina la venta.
 */
function cancelar_venta(string $id_venta): array {
    // Buscar la venta en todos los dueños
    $raiz_usuarios = Nodo::nodo_por_id('usuarios');
    if (!$raiz_usuarios) return ['exito' => false, 'error' => 'No hay usuarios'];

    foreach ($raiz_usuarios->adyacentes() as $nombre_dueno => $nodo_dueno) {
        $nodo_nivel = $nodo_dueno->adyacente('nivel');
        if (!$nodo_nivel || $nodo_nivel->dato() !== 'dueno') continue;

        $cabeza = obtener_cabeza_ventas_dueno($nombre_dueno);
        if (!$cabeza) continue;

        // Buscar nodo venta y su anterior en la lista circular
        $anterior = $cabeza;
        $actual = $cabeza->adyacente('primer');
        $seguridad = 0;
        while ($actual && $actual->id() !== $cabeza->id() && $seguridad < 1000) {
            if ($actual->dato() === $id_venta) {
                // Liberar asientos
                $cabeza_asientos = $actual->adyacente('asientos');
                if ($cabeza_asientos) {
                    $asiento_venta_actual = $cabeza_asientos->adyacente('primer');
                    $seguridad_asientos = 0;
                    while ($asiento_venta_actual && $asiento_venta_actual->id() !== $cabeza_asientos->id() && $seguridad_asientos < 100) {
                        $nodo_asiento_real = $asiento_venta_actual->adyacente('asiento');
                        if ($nodo_asiento_real) {
                            $nodo_asiento_real->adyacente('estado')?->_dato('libre');
                            $nodo_asiento_real->eliminar_adyacente('seleccionado_por');
                            $nodo_asiento_real->eliminar_adyacente('pasajero');
                            $nodo_asiento_real->eliminar_adyacente('venta');
                        }
                        $asiento_venta_actual = $asiento_venta_actual->adyacente('siguiente');
                        $seguridad_asientos++;
                    }
                }

                // Revertir montos de terminal
                $nodo_terminal = $actual->adyacente('terminal');
                if ($nodo_terminal) {
                    $metodo_pago = $actual->adyacente('metodo_pago') ? $actual->adyacente('metodo_pago')->dato() : '';
                    $monto_pagado = $actual->adyacente('pagado') ? (float)$actual->adyacente('pagado')->dato() : 0;
                    if ($metodo_pago === 'efectivo') {
                        $nodo_efectivo = $nodo_terminal->adyacente('efectivo');
                        if ($nodo_efectivo) {
                            $nuevo = (float)$nodo_efectivo->dato() - $monto_pagado;
                            $nodo_efectivo->_dato((string)max(0, $nuevo));
                        }
                    } else {
                        $nodo_banco = $nodo_terminal->adyacente('banco');
                        if ($nodo_banco) {
                            $nuevo = (float)$nodo_banco->dato() - $monto_pagado;
                            $nodo_banco->_dato((string)max(0, $nuevo));
                        }
                    }
                }

                // Actualizar contadores del micro y viaje
                $nodo_micro = $actual->adyacente('micro');
                $nodo_viaje = $actual->adyacente('viaje');
                if ($nodo_micro) actualizar_contadores_micro($nodo_micro);
                if ($nodo_viaje && $nodo_micro) {
                    $nombre_viaje = $nodo_viaje->dato();
                    $nombre_dueno_actual = $nodo_dueno->dato();
                    actualizar_contadores_viaje($nombre_viaje, $nombre_dueno_actual);
                }

                // Eliminar venta de la lista circular
                $siguiente = $actual->adyacente('siguiente');
                $anterior->_adyacente_en($siguiente ?: $cabeza, 'siguiente');
                if ($cabeza->adyacente('primer')->id() === $actual->id()) {
                    $cabeza->_adyacente_en($siguiente ?: $cabeza, 'primer');
                }

                // Limpiar enlaces del nodo venta (opcional)
                // Se deja que el recolector de basura del framework lo maneje, o se elimina manualmente
                // Nodo::eliminar($actual);

                Controlador::guardar(Conf::NOMBRE_APP);
                return ['exito' => true];
            }
            $anterior = $actual;
            $actual = $actual->adyacente('siguiente');
            $seguridad++;
        }
    }

    return ['exito' => false, 'error' => 'Venta no encontrada'];
}
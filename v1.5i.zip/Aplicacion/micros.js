/***
 * Funciones de empresas, vehículos y editor de asientos.
 * @version 1.5piloto.77v
 */

// Variable global para el editor de asientos
let editor_pisos_actuales = [];

// Fase B3.3d: nombre del dueño cuya pestaña Micros se está
// gestionando. Se usa para mandar `nombre_dueno` en cada POST
// de vehiculos/*. Para admin/soporte es el elegido en el
// selector; para dueño es él mismo.
let dueno_micros_seleccionado = '';

function _obtener_nombre_dueno_micros() {
    if (es_admin_o_soporte()) {
        const select = document.getElementById('selector_dueno_micros');
        return dueno_micros_seleccionado || (select ? select.value : '') || '';
    }
    if (usuario_actual && usuario_actual.nivel === 'dueno') {
        return usuario_actual.nombre_usuario;
    }
    return '';
}

async function cargar_datos_micros() {
    // Limpiar selects
    $("#selector_dueno_micros").innerHTML = '';
    $("#selector_empresa_micros").innerHTML = '';
    $("#selector_vehiculo_micros").innerHTML = '';
    $("#croquis_pisos_micros").innerHTML = '';

    // Ocultar paneles por defecto
    $("#panel_selector_dueno_micros").style.display = 'none';
    $("#panel_empresas_micros").style.display = 'none';
    $("#panel_vehiculos_micros").style.display = 'none';
    $("#panel_croquis_micros").style.display = 'none';

    if (!usuario_actual) return;

    if (es_admin_o_soporte()) {
        $("#panel_selector_dueno_micros").style.display = 'block';
        await cargar_duenos_en_select_micros();
    } else if (usuario_actual.nivel === 'dueno') {
        dueno_micros_seleccionado = usuario_actual.nombre_usuario;
        await cargar_empresas_de_dueno(usuario_actual.nombre_usuario);
        $("#panel_empresas_micros").style.display = 'block';
    }
}

async function cargar_duenos_en_select_micros() {
    try {
        const respuesta = await fetch("index.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({ accion: "administrador/listar_duenos" })
        });
        const datos = await respuesta.json();
        if (datos.exito) {
            const select = $("#selector_dueno_micros");
            select.innerHTML = '<option value="">Seleccione dueño...</option>';
            datos.duenos.forEach(dueno => {
                const opcion = document.createElement('option');
                opcion.value = dueno.nombre_usuario;
                opcion.textContent = dueno.nombre_real ? `${dueno.nombre_real} (${dueno.nombre_usuario})` : dueno.nombre_usuario;
                select.appendChild(opcion);
            });
            select.onchange = async () => {
                const nombre_dueno = select.value;
                dueno_micros_seleccionado = nombre_dueno;
                if (nombre_dueno) {
                    await cargar_empresas_de_dueno(nombre_dueno);
                    $("#panel_empresas_micros").style.display = 'block';
                } else {
                    $("#panel_empresas_micros").style.display = 'none';
                }
            };
        }
    } catch (e) { console.error(e); }
}

async function cargar_empresas_de_dueno(nombre_dueno) {
    try {
        const respuesta = await fetch("index.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({ accion: "empresas/listar", nombre_dueno })
        });
        const datos = await respuesta.json();
        if (datos.exito) {
            const select = $("#selector_empresa_micros");
            select.innerHTML = '<option value="">Seleccione empresa...</option>';
            datos.empresas.forEach(empresa => {
                const opcion = document.createElement('option');
                opcion.value = empresa.nombre_empresa;
                opcion.textContent = empresa.nombre;
                select.appendChild(opcion);
            });
            select.onchange = async () => {
                const nombre_empresa = select.value;
                if (nombre_empresa) {
                    await cargar_vehiculos_de_empresa(nombre_empresa);
                    $("#panel_vehiculos_micros").style.display = 'block';
                } else {
                    $("#panel_vehiculos_micros").style.display = 'none';
                    $("#panel_croquis_micros").style.display = 'none';
                }
            };
        }
    } catch (e) { console.error(e); }
}

async function cargar_vehiculos_de_empresa(nombre_empresa) {
    const nombre_dueno = _obtener_nombre_dueno_micros();
    try {
        const respuesta = await fetch("index.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({ accion: "vehiculos/listar", nombre_empresa, nombre_dueno })
        });
        const datos = await respuesta.json();
        if (datos.exito) {
            const select = $("#selector_vehiculo_micros");
            select.innerHTML = '<option value="">Seleccione vehículo...</option>';
            datos.vehiculos.forEach(vehiculo => {
                const opcion = document.createElement('option');
                opcion.value = String(vehiculo.nombre_vehiculo);
                opcion.textContent = vehiculo.nombre;
                select.appendChild(opcion);
            });

            if (datos.vehiculos.length > 0) {
                select.selectedIndex = 1;
                vehiculo_seleccionado_micros = datos.vehiculos[0];
                mostrar_croquis_vehiculo(vehiculo_seleccionado_micros);
                mostrar_panel_datos_vehiculo(vehiculo_seleccionado_micros); 
                $("#panel_croquis_micros").style.display = 'block';
                $("#area_croquis_estatico_micros").classList.remove("hidden");
                $("#panel_edicion_vehiculo_micros").classList.add("hidden");
            } else {
                vehiculo_seleccionado_micros = null;
                $("#panel_croquis_micros").style.display = 'none';
                mostrar_panel_datos_vehiculo(null);
            }

            select.onchange = async () => {
                const seleccionado = String(select.value);
                const vehiculo = datos.vehiculos.find(v => String(v.nombre_vehiculo) === seleccionado);
                if (vehiculo) {
                    vehiculo_seleccionado_micros = vehiculo;
                    mostrar_croquis_vehiculo(vehiculo);
                    mostrar_panel_datos_vehiculo(vehiculo);
                    $("#panel_croquis_micros").style.display = 'block';
                    $("#area_croquis_estatico_micros").classList.remove("hidden");
                    $("#panel_edicion_vehiculo_micros").classList.add("hidden");
                } else {
                    vehiculo_seleccionado_micros = null;
                    $("#panel_croquis_micros").style.display = 'none';
                    mostrar_panel_datos_vehiculo(null);
                }
            };
        }
    } catch (e) {
        console.error(e);
    }
}

function actualizar_foto_vehiculo(ruta, es_editor = false) {
    if (es_editor) {
        const img = $("#foto_vehiculo_editor_img");
        const placeholder = $("#foto_vehiculo_editor_placeholder");
        const boton_subir = $("#boton_subir_foto");
        const boton_cambiar = $("#boton_cambiar_foto");
        if (ruta) {
            img.src = ruta;
            img.style.display = 'block';
            placeholder.style.display = 'none';
            boton_subir.style.display = 'none';
            boton_cambiar.style.display = 'inline-block';
        } else {
            img.style.display = 'none';
            placeholder.style.display = 'block';
            boton_subir.style.display = 'inline-block';
            boton_cambiar.style.display = 'none';
        }
    } else {
        const img = $("#foto_vehiculo_estatica");
        const placeholder = $("#foto_vehiculo_estatica_placeholder");
        if (ruta) {
            img.src = ruta;
            img.style.display = 'block';
            placeholder.style.display = 'none';
        } else {
            img.style.display = 'none';
            placeholder.style.display = 'block';
        }
    }
}

function mostrar_croquis_vehiculo(vehiculo) {
    const contenedor = $("#croquis_pisos_micros");
    contenedor.innerHTML = '';

    const configuracion = vehiculo.configuracion;
    if (!configuracion || !configuracion.pisos || configuracion.pisos.length === 0) {
        const num_asientos = parseInt(vehiculo.asientos) || 44;
        const filas = Math.ceil(num_asientos / 4);
        // Croquis simple omitido por brevedad
    } else {
        configuracion.pisos.forEach((piso, index) => {
            const titulo = document.createElement('div');
            titulo.className = 'section-title';
            titulo.textContent = `Piso ${index + 1}`;
            contenedor.appendChild(titulo);

            const busDiv = document.createElement('div');
            busDiv.className = 'bus';
            busDiv.innerHTML = `<div class="bus-front">FRENTE · CONDUCTOR</div>`;

            for (let fila = 1; fila <= piso.filas; fila++) {
                const filaDiv = document.createElement('div');
                filaDiv.className = 'seat-row';
                for (let col = 1; col <= piso.columnas; col++) {
                    const asiento = piso.asientos.find(a => parseInt(a.fila) === fila && parseInt(a.columna) === col);
                    if (asiento) {
                        const seat = document.createElement('div');
                        seat.className = 'seat';
                        seat.textContent = asiento.numero.padStart(2, '0');
                        filaDiv.appendChild(seat);
                    } else {
                        const empty = document.createElement('div');
                        empty.className = 'aisle';
                        filaDiv.appendChild(empty);
                    }
                }
                busDiv.appendChild(filaDiv);
            }

            busDiv.innerHTML += `<div class="bus-back">PARTE TRASERA</div>`;
            contenedor.appendChild(busDiv);
        });
    }
}

// Eventos de empresa y vehículo
//
// Fase 8.5, v76c: el alta de empresa y de vehículo pasa a
// modal genérico. Los formularios embebidos se eliminaron
// del HTML.
$("#boton_agregar_empresa_micros").addEventListener("click", () => {
    const html = `
        <div class="form-grid">
            <div class="field">
                <label>Nombre de empresa (identificador) *</label>
                <input type="text" id="modal_nueva_empresa_nombre">
            </div>
            <div class="field">
                <label>Nombre visible</label>
                <input type="text" id="modal_nueva_empresa_nombre_real">
            </div>
        </div>
        <div class="actions" style="margin-top:15px">
            <button class="btn primary" id="modal_btn_guardar_empresa">Guardar</button>
            <button class="btn" id="modal_btn_cancelar_empresa">Cancelar</button>
        </div>
    `;
    abrir_modal_generico('Nueva empresa', html);

    const contenedor = document.getElementById('modal_generico_contenido');
    contenedor.querySelector('#modal_btn_cancelar_empresa').addEventListener('click', cerrar_modal_generico);
    contenedor.querySelector('#modal_btn_guardar_empresa').addEventListener('click', _guardar_empresa_desde_modal);
});

async function _guardar_empresa_desde_modal() {
    const nombre_dueno = es_admin_o_soporte() ? $("#selector_dueno_micros").value : usuario_actual.nombre_usuario;
    if (!nombre_dueno) {
        mostrar_aviso("Seleccione un dueño", 'error');
        return;
    }
    const nombre_empresa = (document.getElementById('modal_nueva_empresa_nombre')?.value || '').trim();
    const nombre_real = (document.getElementById('modal_nueva_empresa_nombre_real')?.value || '').trim();
    if (!nombre_empresa) {
        mostrar_aviso("Nombre de empresa obligatorio", 'error');
        return;
    }
    const datos = {
        accion: "empresas/agregar",
        nombre_dueno,
        nombre_empresa,
        nombre_real
    };
    const respuesta = await fetch("index.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams(datos)
    });
    const resultado = await respuesta.json();
    if (resultado.exito) {
        mostrar_aviso("Empresa agregada", 'exito');
        cerrar_modal_generico();
        await cargar_empresas_de_dueno(nombre_dueno);
    } else {
        mostrar_aviso(resultado.error || "Error al agregar empresa", 'error');
    }
}

// Eventos de vehículo
//
// Fase 8.5, v76c: el alta de vehículo pasa a modal genérico.
// Se conserva el flujo post-alta (seleccionar el vehículo y
// abrir el editor de asientos automáticamente).
$("#boton_agregar_vehiculo_micros").addEventListener("click", () => {
    const html = `
        <div class="form-grid">
            <div class="field">
                <label>Patente (identificador) *</label>
                <input type="text" id="modal_nuevo_vehiculo_nombre">
            </div>
            <div class="field">
                <label>Nombre visible</label>
                <input type="text" id="modal_nuevo_vehiculo_nombre_real">
            </div>
        </div>
        <div class="actions" style="margin-top:15px">
            <button class="btn primary" id="modal_btn_guardar_vehiculo">Guardar</button>
            <button class="btn" id="modal_btn_cancelar_vehiculo">Cancelar</button>
        </div>
    `;
    abrir_modal_generico('Nuevo vehículo', html);

    const contenedor = document.getElementById('modal_generico_contenido');
    contenedor.querySelector('#modal_btn_cancelar_vehiculo').addEventListener('click', cerrar_modal_generico);
    contenedor.querySelector('#modal_btn_guardar_vehiculo').addEventListener('click', _guardar_vehiculo_desde_modal);
});

async function _guardar_vehiculo_desde_modal() {
    const nombre_empresa = $("#selector_empresa_micros").value;
    if (!nombre_empresa) {
        mostrar_aviso("Seleccione una empresa", 'error');
        return;
    }
    const nombre_vehiculo = (document.getElementById('modal_nuevo_vehiculo_nombre')?.value || '').trim();
    const nombre_real = (document.getElementById('modal_nuevo_vehiculo_nombre_real')?.value || '').trim();
    if (!nombre_vehiculo) {
        mostrar_aviso("Patente obligatoria", 'error');
        return;
    }
    const datos = {
        accion: "vehiculos/agregar",
        nombre_empresa,
        nombre_vehiculo,
        nombre_real,
        nombre_dueno: _obtener_nombre_dueno_micros()
    };
    const respuesta = await fetch("index.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams(datos)
    });
    const resultado = await respuesta.json();
    if (resultado.exito) {
        mostrar_aviso("Vehículo agregado. Configure los asientos.", 'exito');
        cerrar_modal_generico();
        await cargar_vehiculos_de_empresa(nombre_empresa);
        const select = $("#selector_vehiculo_micros");
        select.value = datos.nombre_vehiculo;
        select.dispatchEvent(new Event('change'));
        setTimeout(() => {
            if (vehiculo_seleccionado_micros && vehiculo_seleccionado_micros.nombre_vehiculo === datos.nombre_vehiculo) {
                iniciar_editor_vehiculo();
            }
        }, 300);
    } else {
        mostrar_aviso(resultado.error || "Error al agregar vehículo", 'error');
    }
}

// Editor de asientos
function iniciar_editor_vehiculo() {
    if (!vehiculo_seleccionado_micros) {
        mostrar_aviso("Seleccione un vehículo primero", 'error');
        return;
    }

    $("#area_croquis_estatico_micros").classList.add("hidden");
    $("#panel_edicion_vehiculo_micros").classList.remove("hidden");

    const configuracion = vehiculo_seleccionado_micros.configuracion;
    let numPisos = 1;
    if (configuracion && Array.isArray(configuracion.pisos) && configuracion.pisos.length > 0) {
        numPisos = configuracion.pisos.length;
    }
    $("#editor_num_pisos").value = String(numPisos);

    editor_pisos_actuales = [];
    if (configuracion && configuracion.pisos) {
        for (let i = 0; i < configuracion.pisos.length; i++) {
            editor_pisos_actuales.push({
                filas: configuracion.pisos[i].filas,
                columnas: configuracion.pisos[i].columnas,
                asientos: configuracion.pisos[i].asientos.map(a => ({
                    fila: parseInt(a.fila),
                    columna: parseInt(a.columna),
                    numero: a.numero
                }))
            });
        }
    } else {
        editor_pisos_actuales.push({ filas: 12, columnas: 5, asientos: [] });
    }

    generar_editor_pisos();
    actualizar_foto_vehiculo(vehiculo_seleccionado_micros.foto, true);
}

function generar_editor_pisos() {
    const select = $("#editor_num_pisos");
    if (!select) return;
    const numPisos = Math.max(1, parseInt(select.value, 10) || 1);

    while (editor_pisos_actuales.length < numPisos) {
        editor_pisos_actuales.push({ filas: 12, columnas: 5, asientos: [] });
    }
    editor_pisos_actuales.length = numPisos;

    const contenedor = $("#editor_pisos_container");
    contenedor.innerHTML = '';

    editor_pisos_actuales.forEach((piso, idxPiso) => {
        const pisoDiv = document.createElement('div');
        pisoDiv.className = 'editor-piso';
        pisoDiv.innerHTML = `<h4>Piso ${idxPiso + 1}</h4>
            <div class="form-grid" style="margin-bottom:8px;">
                <div class="field"><label>Filas</label><input type="number" class="input-filas" value="${piso.filas}" min="1"></div>
                <div class="field"><label>Columnas</label><input type="number" class="input-columnas" value="${piso.columnas}" min="1"></div>
            </div>
            <div class="cuadricula-editor" data-piso="${idxPiso}"></div>`;
        contenedor.appendChild(pisoDiv);

        const inputFilas = pisoDiv.querySelector('.input-filas');
        const inputColumnas = pisoDiv.querySelector('.input-columnas');
        inputFilas.addEventListener('change', () => {
            piso.filas = parseInt(inputFilas.value, 10) || 1;
            renderizar_cuadricula_editor(pisoDiv, idxPiso);
        });
        inputColumnas.addEventListener('change', () => {
            piso.columnas = parseInt(inputColumnas.value, 10) || 1;
            renderizar_cuadricula_editor(pisoDiv, idxPiso);
        });

        renderizar_cuadricula_editor(pisoDiv, idxPiso);
    });
}

function renderizar_cuadricula_editor(contenedorPiso, idxPiso) {
    const piso = editor_pisos_actuales[idxPiso];
    const cuadricula = contenedorPiso.querySelector('.cuadricula-editor');
    cuadricula.innerHTML = '';

    for (let f = 1; f <= piso.filas; f++) {
        const filaDiv = document.createElement('div');
        filaDiv.className = 'seat-row';
        for (let c = 1; c <= piso.columnas; c++) {
            const celda = document.createElement('div');
            celda.className = 'celda-editor';
            celda.dataset.fila = f;
            celda.dataset.columna = c;
            celda.dataset.piso = idxPiso;

            const asiento = piso.asientos.find(a => a.fila === f && a.columna === c);
            if (asiento) {
                celda.classList.add('asiento');
                celda.textContent = asiento.numero;
            } else {
                celda.classList.add('vacio');
            }

            celda.addEventListener('click', () => alternar_asiento(celda, idxPiso, f, c));
            celda.addEventListener('dblclick', () => editar_numero_asiento(celda, idxPiso, f, c));

            filaDiv.appendChild(celda);
        }
        cuadricula.appendChild(filaDiv);
    }
}

function alternar_asiento(celda, idxPiso, fila, columna) {
    const piso = editor_pisos_actuales[idxPiso];
    const idx = piso.asientos.findIndex(a => a.fila === fila && a.columna === columna);
    if (idx >= 0) {
        piso.asientos.splice(idx, 1);
        celda.classList.remove('asiento');
        celda.classList.add('vacio');
        celda.textContent = '';
    } else {
        const nuevoNumero = generar_numero_provisional(idxPiso);
        piso.asientos.push({ fila, columna, numero: nuevoNumero });
        celda.classList.add('asiento');
        celda.classList.remove('vacio');
        celda.textContent = nuevoNumero;
    }
}

function editar_numero_asiento(celda, idxPiso, fila, columna) {
    const piso = editor_pisos_actuales[idxPiso];
    const asiento = piso.asientos.find(a => a.fila === fila && a.columna === columna);
    if (!asiento) return;

    const nuevoNumero = prompt("Número de asiento:", asiento.numero);
    if (nuevoNumero !== null && nuevoNumero.trim() !== '') {
        asiento.numero = nuevoNumero.trim();
        celda.textContent = nuevoNumero.trim();
    }
}

/**
 * Genera el siguiente número provisional considerando el máximo global
 * de todos los pisos hasta el actual (inclusive). Esto evita que el piso 2
 * reinicie en 1 cuando el piso 1 ya tiene asientos numerados.
 */
function generar_numero_provisional(idxPiso) {
    let max = 0;
    for (let i = 0; i <= idxPiso; i++) {
        if (!editor_pisos_actuales[i]) continue;
        editor_pisos_actuales[i].asientos.forEach(a => {
            const num = parseInt(a.numero);
            if (!isNaN(num) && num > max) max = num;
        });
    }
    return String(max + 1);
}

/**
 * Valida que no haya números de asiento repetidos entre todos los pisos.
 * Devuelve un arreglo de duplicados detectados.
 */
function validar_numeros_asientos() {
    const vistos = new Map();   // numero -> { piso, fila, columna }
    const duplicados = [];

    editor_pisos_actuales.forEach((piso, idxPiso) => {
        piso.asientos.forEach(a => {
            const numero = String(a.numero).trim();
            if (numero === '') return;
            if (vistos.has(numero)) {
                duplicados.push({
                    numero,
                    primero: vistos.get(numero),
                    segundo: { piso: idxPiso + 1, fila: a.fila, columna: a.columna }
                });
            } else {
                vistos.set(numero, { piso: idxPiso + 1, fila: a.fila, columna: a.columna });
            }
        });
    });

    return duplicados;
}

/**
 * Muestra el modal con los números duplicados y ofrece reiniciar la numeración.
 */
function mostrar_aviso_numeros_duplicados(duplicados) {
    let html = '<p>Hay números de asiento repetidos entre pisos. Corregilos antes de guardar:</p>';
    html += '<ul>';
    duplicados.forEach(d => {
        html += `<li>Número <strong>${d.numero}</strong>: piso ${d.primero.piso} (F${d.primero.fila}, C${d.primero.columna}) y piso ${d.segundo.piso} (F${d.segundo.fila}, C${d.segundo.columna})</li>`;
    });
    html += '</ul>';
    html += '<p>Podés corregirlos manualmente (doble clic en cada celda) o reiniciar la numeración para que se reasignen secuencialmente.</p>';
    html += '<div class="actions" style="margin-top:15px;">';
    html += '<button class="btn primary" id="btn_reiniciar_numeracion">Reiniciar numeración</button>';
    html += '<button class="btn" id="btn_cancelar_duplicados">Cancelar</button>';
    html += '</div>';

    abrir_modal_generico('Números de asiento duplicados', html);

    document.getElementById('btn_reiniciar_numeracion').addEventListener('click', () => {
        reiniciar_numeracion_asientos();
        cerrar_modal_generico();
        mostrar_aviso('Numeración reiniciada. Guardando...', 'info');
        guardar_configuracion();
    });

    document.getElementById('btn_cancelar_duplicados').addEventListener('click', cerrar_modal_generico);
}

/**
 * Renumera todos los asientos secuencialmente, piso por piso, respetando
 * el orden de filas y columnas dentro de cada piso.
 */
function reiniciar_numeracion_asientos() {
    let contador = 1;
    editor_pisos_actuales.forEach((piso) => {
        // Ordenar por fila y luego por columna para que la numeración sea predecible
        piso.asientos.sort((a, b) => {
            if (a.fila !== b.fila) return a.fila - b.fila;
            return a.columna - b.columna;
        });
        piso.asientos.forEach(a => {
            a.numero = String(contador);
            contador++;
        });
    });
    // Refrescar la cuadrícula visual del editor
    document.querySelectorAll('.cuadricula-editor').forEach((cuadricula, idx) => {
        renderizar_cuadricula_editor(cuadricula.parentElement, idx);
    });
}

async function guardar_configuracion() {
    // Validar números duplicados antes de guardar
    const duplicados = validar_numeros_asientos();
    if (duplicados.length > 0) {
        mostrar_aviso_numeros_duplicados(duplicados);
        return;
    }

    const numPisos = parseInt($("#editor_num_pisos").value);
    const configuracion = { pisos: [] };
    for (let i = 0; i < numPisos; i++) {
        const piso = editor_pisos_actuales[i];
        configuracion.pisos.push({
            filas: piso.filas,
            columnas: piso.columnas,
            asientos: piso.asientos.map(a => ({
                fila: String(a.fila),
                columna: String(a.columna),
                numero: String(a.numero)
            }))
        });
    }

    const nombre_empresa = $("#selector_empresa_micros").value;
    const nombre_vehiculo = vehiculo_seleccionado_micros.nombre_vehiculo;

    const datos = {
        accion: "vehiculos/actualizar_configuracion",
        nombre_empresa,
        nombre_vehiculo,
        configuracion: JSON.stringify(configuracion),
        nombre_dueno: _obtener_nombre_dueno_micros()
    };

    const respuesta = await fetch("index.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams(datos)
    });
    const resultado = await respuesta.json();
    if (resultado.exito) {
        if (vehiculo_seleccionado_micros) {
            vehiculo_seleccionado_micros.configuracion = configuracion;
            const total_asientos = configuracion.pisos.reduce((total, piso) => total + piso.asientos.length, 0);
            vehiculo_seleccionado_micros.asientos = String(total_asientos);
            mostrar_panel_datos_vehiculo(vehiculo_seleccionado_micros);
        }
        cancelar_editor();
        mostrar_aviso("Configuración actualizada", 'exito');
    } else {
        mostrar_aviso(resultado.error || "Error al guardar configuración", 'error');
    }
}

function cancelar_editor() {
    $("#panel_edicion_vehiculo_micros").classList.add("hidden");
    $("#area_croquis_estatico_micros").classList.remove("hidden");
    if (vehiculo_seleccionado_micros) {
        mostrar_croquis_vehiculo(vehiculo_seleccionado_micros);
    }
}

// Eventos de edición
$("#boton_modificar_vehiculo_micros").addEventListener("click", iniciar_editor_vehiculo);
$("#editor_num_pisos").addEventListener("change", generar_editor_pisos);
$("#boton_guardar_configuracion").addEventListener("click", guardar_configuracion);
$("#boton_cancelar_configuracion").addEventListener("click", cancelar_editor);

// Botón "Reiniciar asientos": elimina todos los asientos de todos los pisos
$("#boton_reiniciar_asientos").addEventListener("click", () => {
    editor_pisos_actuales.forEach(piso => {
        piso.asientos = [];
    });
    document.querySelectorAll('.cuadricula-editor').forEach((cuadricula, idx) => {
        renderizar_cuadricula_editor(cuadricula.parentElement, idx);
    });
    mostrar_aviso("Asientos reiniciados", 'info');
});

// Botón "Reiniciar numeración de asientos": renumera los asientos existentes
/*$("#boton_reiniciar_numeracion").addEventListener("click", () => {
    reiniciar_numeracion_asientos();
    mostrar_aviso("Numeración reiniciada", 'info');
});*/

// Subir foto
$("#boton_subir_foto").addEventListener("click", () => {
    $("#input_foto_vehiculo").click();
});

$("#boton_cambiar_foto").addEventListener("click", () => {
    $("#input_foto_vehiculo").click();
});

$("#input_foto_vehiculo").addEventListener("change", async (e) => {
    const archivo = e.target.files[0];
    if (!archivo) return;
    const nombre_empresa = $("#selector_empresa_micros").value;
    const nombre_vehiculo = vehiculo_seleccionado_micros?.nombre_vehiculo;
    if (!nombre_vehiculo) {
        mostrar_aviso("Seleccione un vehículo primero", 'error');
        return;
    }
    const formData = new FormData();
    formData.append('accion', 'vehiculos/subir_foto');
    formData.append('nombre_empresa', nombre_empresa);
    formData.append('nombre_vehiculo', nombre_vehiculo);
    formData.append('nombre_dueno', _obtener_nombre_dueno_micros());
    formData.append('foto', archivo);

    const respuesta = await fetch("index.php", {
        method: "POST",
        body: formData
    });
    const resultado = await respuesta.json();
    if (resultado.exito) {
        if (vehiculo_seleccionado_micros) {
            vehiculo_seleccionado_micros.foto = resultado.foto;
            mostrar_panel_datos_vehiculo(vehiculo_seleccionado_micros);
        }
        actualizar_foto_vehiculo(resultado.foto, true);
        mostrar_aviso("Foto actualizada", 'exito');
    } else {
        mostrar_aviso(resultado.error || "Error al subir foto", 'error');
    }
});

function mostrar_panel_datos_vehiculo(vehiculo) {
    const panel = $("#panel_datos_vehiculo");
    if (!vehiculo) {
        panel.classList.add("hidden");
        return;
    }

    // Nombre visible
    $("#datos_vehiculo_nombre").textContent = vehiculo.nombre || vehiculo.nombre_vehiculo;
    // Patente
    $("#datos_vehiculo_patente").textContent = vehiculo.nombre_vehiculo;

    // Estado: configurado si hay al menos un asiento cargado
    const tiene_config = vehiculo.configuracion
        && Array.isArray(vehiculo.configuracion.pisos)
        && vehiculo.configuracion.pisos.some(p => p.asientos && p.asientos.length > 0);
    const estado_el = $("#datos_vehiculo_estado");
    if (tiene_config) {
        estado_el.textContent = "✓ Listo para usar";
        estado_el.className = "estado-configurado";
    } else {
        estado_el.textContent = "⚠ Requiere configuración";
        estado_el.className = "estado-sin-configurar";
    }

    // Capacidad total
    $("#datos_vehiculo_capacidad").textContent = vehiculo.asientos || '0';

    // Asientos por piso (solo si hay más de un piso)
    const pisos_div = $("#datos_vehiculo_pisos");
    pisos_div.innerHTML = '';
    const pisos = vehiculo.configuracion && vehiculo.configuracion.pisos ? vehiculo.configuracion.pisos : [];
    if (pisos.length > 1) {
        pisos.forEach((piso, idx) => {
            const cantidad = piso.asientos ? piso.asientos.length : 0;
            const div = document.createElement('div');
            div.className = 'dato-linea';
            div.innerHTML = `<strong>Piso ${idx + 1}:</strong> <span>${cantidad} asientos</span>`;
            pisos_div.appendChild(div);
        });
    }

    // Foto (miniatura)
    const img = $("#foto_vehiculo_miniatura");
    const placeholder = $("#foto_vehiculo_miniatura_placeholder");
    if (vehiculo.foto) {
        img.src = vehiculo.foto;
        img.style.display = 'block';
        placeholder.style.display = 'none';
    } else {
        img.style.display = 'none';
        placeholder.style.display = 'block';
    }

    panel.classList.remove("hidden");
}
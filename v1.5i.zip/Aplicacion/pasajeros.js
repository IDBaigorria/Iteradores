/***
 * Funciones del panel de pasajeros/clientes.
 * @version 1.5piloto.19
 */

let pasajeros_actuales = [];
let pasajero_seleccionado_dni = null;

async function cargar_pasajeros() {
    const respuesta = await fetch("index.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ accion: "pasajeros/listar" })
    });
    const datos = await respuesta.json();
    if (datos.exito) {
        pasajeros_actuales = datos.pasajeros;
        renderizar_tabla_pasajeros(pasajeros_actuales);
    } else {
        mostrar_aviso(datos.error || "Error al cargar pasajeros", 'error');
    }
}

function renderizar_tabla_pasajeros(pasajeros) {
    const tabla = document.getElementById('tabla_pasajeros');
    tabla.innerHTML = '';
    pasajeros.forEach(pasajero => {
        const fila = document.createElement('tr');
        fila.innerHTML = `
            <td>${pasajero.nombre}</td>
            <td>${pasajero.dni}</td>
            <td>${pasajero.email || '—'}</td>
            <td>${pasajero.celular || '—'}</td>
            <td>${pasajero.celular_emergencia || '—'}</td>
            <td><button class="btn editar_pasajero" data-dni="${pasajero.dni}">Editar</button></td>
        `;
        tabla.appendChild(fila);
        fila.querySelector('.editar_pasajero').addEventListener('click', () => cargar_detalle_pasajero(pasajero.dni));
    });
}

document.getElementById('buscar_pasajero').addEventListener('input', function() {
    const termino = this.value.trim().toLowerCase();
    const filtrados = termino === '' ? pasajeros_actuales : pasajeros_actuales.filter(p => 
        p.nombre.toLowerCase().includes(termino) || p.dni.includes(termino)
    );
    renderizar_tabla_pasajeros(filtrados);
});

async function cargar_detalle_pasajero(dni) {
    const respuesta = await fetch("index.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ accion: "pasajeros/obtener", dni })
    });
    const datos = await respuesta.json();
    if (datos.exito) {
        pasajero_seleccionado_dni = dni;
        const p = datos.pasajero;
        document.getElementById('pasajero_nombre').value = p.nombre;
        document.getElementById('pasajero_dni').value = p.dni;
        document.getElementById('pasajero_email').value = p.email || '';
        document.getElementById('pasajero_celular').value = p.celular || '';
        document.getElementById('pasajero_emergencia').value = p.celular_emergencia || '';

        // Pasajes
        const contenedorPasajes = document.getElementById('pasajes_pasajero');
        contenedorPasajes.innerHTML = '';
        if (p.ventas && p.ventas.length > 0) {
            p.ventas.forEach(venta => {
                const div = document.createElement('div');
                div.className = 'sale-card';
                div.innerHTML = `<strong>${venta.viaje}</strong><br><span class="small">Venta ${venta.id_venta} · ${venta.fecha} · Total: $${venta.total}</span>`;
                contenedorPasajes.appendChild(div);
            });
        } else {
            contenedorPasajes.innerHTML = '<p>Sin pasajes registrados</p>';
        }

        // Botón ficha de salud
        const contenedorFichaBotones = document.querySelector('#detalle_pasajero .ficha-salud-botones');
        if (contenedorFichaBotones) {
            contenedorFichaBotones.innerHTML = '';
            const botonFicha = document.createElement('button');
            botonFicha.className = 'btn';
            botonFicha.textContent = p.ficha_salud ? 'Ver ficha de salud' : 'Anexar ficha de salud';
            botonFicha.addEventListener('click', () => mostrar_ficha_salud_edicion(dni, p.ficha_salud));
            contenedorFichaBotones.appendChild(botonFicha);
        }

        document.getElementById('detalle_pasajero').classList.remove('hidden');const detalle = document.getElementById('detalle_pasajero');
        detalle.classList.remove('hidden');
        detalle.style.display = 'block'; // Fuerza mostrar aunque el CSS lo oculte
    } else {
        mostrar_aviso(datos.error || 'Pasajero no encontrado', 'error');
    }
}

function mostrar_ficha_salud_edicion(dni, fichaSalud) {
    const contenedor = document.querySelector('#detalle_pasajero .ficha-salud-contenedor');
    if (!contenedor) return;

    if (!fichaSalud) {
        fichaSalud = { enfermedades: [], medicamentos: [], impedimentos: [] };
    }

    contenedor.innerHTML = `
        <h3>Datos de salud</h3>
        <div class="seccion-salud">
            <label>¿Padece alguna enfermedad crónica o tiene secuelas de alguna que ha tenido?</label>
            <input type="checkbox" class="check_enfermedad" ${fichaSalud.enfermedades.length ? 'checked' : ''}>
            <div class="enfermedades_container" style="${fichaSalud.enfermedades.length ? '' : 'display:none;'}"></div>
        </div>
        <div class="seccion-salud">
            <label>¿Está medicado en tratamiento médico o psiquiátrico?</label>
            <input type="checkbox" class="check_medicamento" ${fichaSalud.medicamentos.length ? 'checked' : ''}>
            <div class="medicamentos_container" style="${fichaSalud.medicamentos.length ? '' : 'display:none;'}"></div>
        </div>
        <div class="seccion-salud">
            <label>¿Posee algún impedimento físico?</label>
            <input type="checkbox" class="check_impedimento" ${fichaSalud.impedimentos.length ? 'checked' : ''}>
            <div class="impedimentos_container" style="${fichaSalud.impedimentos.length ? '' : 'display:none;'}"></div>
        </div>
        <button class="btn primary" id="guardar_ficha_salud">Guardar ficha</button>
    `;

    fichaSalud.enfermedades.forEach(item => agregarInputSalud(contenedor.querySelector('.enfermedades_container'), 'enfermedad', dni, item));
    fichaSalud.medicamentos.forEach(item => agregarInputSalud(contenedor.querySelector('.medicamentos_container'), 'medicamento', dni, item));
    fichaSalud.impedimentos.forEach(item => agregarInputSalud(contenedor.querySelector('.impedimentos_container'), 'impedimento', dni, item));

    contenedor.querySelectorAll('.check_enfermedad, .check_medicamento, .check_impedimento').forEach(check => {
        check.addEventListener('change', function() {
            const tipo = this.classList.contains('check_enfermedad') ? 'enfermedad' :
                          this.classList.contains('check_medicamento') ? 'medicamento' : 'impedimento';
            const cont = contenedor.querySelector(`.${tipo}s_container`);
            cont.style.display = this.checked ? 'block' : 'none';
            if (this.checked && cont.children.length === 0) {
                agregarInputSalud(cont, tipo, dni);
            }
        });
    });

    contenedor.querySelector('#guardar_ficha_salud').addEventListener('click', async () => {
        const ficha = {
            enfermedades: [],
            medicamentos: [],
            impedimentos: []
        };
        contenedor.querySelectorAll('.salud_enfermedad').forEach(input => ficha.enfermedades.push(input.value.trim()));
        contenedor.querySelectorAll('.salud_medicamento').forEach(input => ficha.medicamentos.push(input.value.trim()));
        contenedor.querySelectorAll('.salud_impedimento').forEach(input => ficha.impedimentos.push(input.value.trim()));

        const respuesta = await fetch("index.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({
                accion: "pasajeros/guardar_ficha",
                dni: dni,
                ficha: JSON.stringify(ficha)
            })
        });
        const resultado = await respuesta.json();
        if (resultado.exito) {
            mostrar_aviso("Ficha de salud guardada", 'exito');
            cargar_detalle_pasajero(dni);
        } else {
            mostrar_aviso(resultado.error || "Error al guardar ficha", 'error');
        }
    });
}

function agregarInputSalud(contenedor, tipo, index, valorInicial = '') {
    const div = document.createElement('div');
    div.className = 'input_salud';
    div.style.marginBottom = '5px';

    const input = document.createElement('input');
    input.type = 'text';
    input.className = `salud_${tipo}`;
    input.dataset.index = index;
    input.placeholder = tipo === 'enfermedad' ? '¿Cuál?' : (tipo === 'medicamento' ? 'Nombre del medicamento' : '¿Cuál?');
    input.value = valorInicial;

    const boton = document.createElement('button');
    boton.type = 'button';
    boton.className = 'btn small';
    boton.textContent = 'Agregar otra';
    boton.dataset.index = index;
    boton.dataset.tipo = tipo;

    let esAgregar = true;
    boton.addEventListener('click', () => {
        if (esAgregar) {
            agregarInputSalud(contenedor, tipo, index);
            boton.textContent = 'Quitar';
            boton.className = 'btn small danger';
            esAgregar = false;
        } else {
            div.remove();
        }
    });

    div.appendChild(input);
    div.appendChild(boton);
    contenedor.appendChild(div);
}

document.getElementById('boton_guardar_pasajero').addEventListener('click', async () => {
    if (!pasajero_seleccionado_dni) {
        mostrar_aviso("Seleccione un pasajero", 'error');
        return;
    }
    const datos = {
        accion: "pasajeros/actualizar",
        dni: pasajero_seleccionado_dni,
        nombre: document.getElementById('pasajero_nombre').value.trim(),
        email: document.getElementById('pasajero_email').value.trim(),
        celular: document.getElementById('pasajero_celular').value.trim(),
        celular_emergencia: document.getElementById('pasajero_emergencia').value.trim(),
    };
    const respuesta = await fetch("index.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams(datos)
    });
    const resultado = await respuesta.json();
    if (resultado.exito) {
        mostrar_aviso("Pasajero actualizado", 'exito');
        cargar_pasajeros();
    } else {
        mostrar_aviso(resultado.error || "Error al actualizar", 'error');
    }
});
<?php
/**
 * Gestión de sesiones de usuario.
 *
 * @package   Iteradores
 * @since     1.5piloto.1
 * @version   1.5piloto.75
 */

use Iteradores\Nodos\Nodo;
use Iteradores\Controlador\Controlador;
use Iteradores\Configuracion\Conf;
include_once("./Configuracion/Configuracion.php");
include_once("./Nodos/Nodo.php");
include_once("./Controlador/Controlador.php");
include_once("./Aplicacion/FuncionesAuxiliares.php");


/**
 * Elimina todas las sesiones activas de un usuario.
 *
 * @param string $nombre_usuario Nombre del usuario.
 * @return void
 */
function eliminar_sesiones_de_usuario(string $nombre_usuario): void {
    en_grafo_credenciales(function() use ($nombre_usuario) {
        $raiz = Nodo::nodo_por_id('sesiones');
        if (!$raiz) return;

        $sesiones = $raiz->adyacentes();
        if (!$sesiones) return;

        foreach ($sesiones as $token => $nodo_sesion) {
            $nodo_usuario = $nodo_sesion->adyacente('usuario');
            if ($nodo_usuario && $nodo_usuario->dato() === $nombre_usuario) {
                $raiz->eliminar_adyacente($token);
                // Fase 2, v75: destruir los campos del nodo
                // sesión (usuario, creado_en). Antes quedaban
                // huérfanos (~2 nodos por sesión eliminada).
                _destruir_campos_simples($nodo_sesion);
                Nodo::eliminar($nodo_sesion);
            }
        }
    });
}

/**
 * Crea una nueva sesión para un usuario, eliminando antes las anteriores.
 *
 * @param string $nombre_usuario Nombre del usuario.
 * @return string Token de sesión generado.
 */
function crear_sesion(string $nombre_usuario): string {
    return en_grafo_credenciales(function() use ($nombre_usuario) {
        eliminar_sesiones_de_usuario($nombre_usuario);

        $raiz_sesiones = Nodo::nodo_por_id('sesiones');
        if (!$raiz_sesiones) {
            $raiz_sesiones = Nodo::crear_con_id('sesiones');
        }

        $token = bin2hex(random_bytes(16));
        $nodo_sesion = Nodo::crear_con_dato('');
        $nodo_sesion->_adyacente_en(Nodo::crear_con_dato($nombre_usuario), 'usuario');
        $nodo_sesion->_adyacente_en(Nodo::crear_con_dato((string)time()), 'creado_en');

        $raiz_sesiones->_adyacente_en($nodo_sesion, $token);

        return $token;
    });
}

/**
 * Lista todas las sesiones activas.
 *
 * @return array Lista de sesiones.
 */
function listar_sesiones(): array {
    return en_grafo_credenciales(function() {
        $raiz = Nodo::nodo_por_id('sesiones');
        if (!$raiz) return [];

        $adyacentes = $raiz->adyacentes();
        if (!$adyacentes) return [];

        $sesiones = [];
        foreach ($adyacentes as $token => $nodo_sesion) {
            $nodo_usuario = $nodo_sesion->adyacente('usuario');
            $nodo_creado = $nodo_sesion->adyacente('creado_en');
            $timestamp = $nodo_creado ? (int)$nodo_creado->dato() : 0;
            $sesiones[] = [
                'token' => $token,
                'usuario' => $nodo_usuario ? $nodo_usuario->dato() : 'desconocido',
                'creado_en' => $timestamp > 0 ? date('Y-m-d H:i:s', $timestamp) : '',
            ];
        }
        return $sesiones;
    });
}

/**
 * Cierra una sesión (la elimina).
 *
 * @param string $token Token de sesión.
 * @return bool Verdadero si se eliminó correctamente.
 */
function cerrar_sesion(string $token): bool {
    return en_grafo_credenciales(function() use ($token) {
        $raiz = Nodo::nodo_por_id('sesiones');
        if (!$raiz) return false;

        $nodo_sesion = $raiz->adyacente($token);
        if (!$nodo_sesion) return false;

        $raiz->eliminar_adyacente($token);
        // Fase 2, v75: destruir los campos del nodo sesión
        // (usuario, creado_en).
        _destruir_campos_simples($nodo_sesion);
        Nodo::eliminar($nodo_sesion);
        return true;
    });
}

/**
 * Lista las sesiones activas de un conjunto de usuarios.
 *
 * @param array $nombres_usuarios Lista de nombres de usuario.
 * @return array Lista de sesiones filtradas.
 */
function listar_sesiones_de_usuarios(array $nombres_usuarios): array {
    if (empty($nombres_usuarios)) return [];

    return en_grafo_credenciales(function() use ($nombres_usuarios) {
        $raiz = Nodo::nodo_por_id('sesiones');
        if (!$raiz) return [];

        $adyacentes = $raiz->adyacentes();
        if (!$adyacentes) return [];

        $sesiones = [];
        foreach ($adyacentes as $token => $nodo_sesion) {
            $nodo_usuario = $nodo_sesion->adyacente('usuario');
            if (!$nodo_usuario) continue;
            $nombre_usuario = $nodo_usuario->dato();
            if (in_array($nombre_usuario, $nombres_usuarios, true)) {
                $nodo_creado = $nodo_sesion->adyacente('creado_en');
                $timestamp = $nodo_creado ? (int)$nodo_creado->dato() : 0;
                $sesiones[] = [
                    'token' => $token,
                    'usuario' => $nombre_usuario,
                    'creado_en' => $timestamp > 0 ? date('Y-m-d H:i:s', $timestamp) : '',
                ];
            }
        }
        return $sesiones;
    });
}
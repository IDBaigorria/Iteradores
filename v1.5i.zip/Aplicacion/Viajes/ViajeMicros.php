<?php
/**
 * Funciones de gestión de micros dentro de viajes.
 *
 * @package   Iteradores
 * @since     1.5piloto.8
 * @version   1.5piloto.78h
 */

use Iteradores\Nodos\Nodo;
use Iteradores\Controlador\Controlador;
use Iteradores\Configuracion\Conf;
include_once("./Configuracion/Configuracion.php");
include_once("./Nodos/Nodo.php");
include_once("./Controlador/Controlador.php");
include_once("./Aplicacion/Compartidos.php");

/**
 * Clona la estructura completa de un vehículo original para asociarla a un viaje.
 */
function clonar_vehiculo($nodo_vehiculo_original) {
    $patente = $nodo_vehiculo_original->dato();
    $nodo_copia = Nodo::crear_con_dato($patente);

    $nodo_nombre = $nodo_vehiculo_original->adyacente('nombre');
    if ($nodo_nombre) {
        $nodo_copia->_adyacente_en(Nodo::crear_con_dato($nodo_nombre->dato()), 'nombre');
    }

    $nodo_foto = $nodo_vehiculo_original->adyacente('foto');
    if ($nodo_foto) {
        $nodo_copia->_adyacente_en(Nodo::crear_con_dato($nodo_foto->dato()), 'foto');
    }

    $nodo_asientos_original = $nodo_vehiculo_original->adyacente('asientos');
    if ($nodo_asientos_original) {
        $nodo_asientos_copia = Nodo::crear_con_dato($nodo_asientos_original->dato());

        for ($i = 1; $i <= 2; $i++) {
            $piso_original = $nodo_asientos_original->adyacente("piso_$i");
            if (!$piso_original) continue;

            $nodo_piso_copia = Nodo::crear_con_dato('');

            $filas = $piso_original->adyacente('filas');
            $columnas = $piso_original->adyacente('columnas');
            if ($filas) $nodo_piso_copia->_adyacente_en(Nodo::crear_con_dato($filas->dato()), 'filas');
            if ($columnas) $nodo_piso_copia->_adyacente_en(Nodo::crear_con_dato($columnas->dato()), 'columnas');

            $cabeza_original = $piso_original->adyacente('asientos');
            if ($cabeza_original) {
                $cabeza_copia = Nodo::crear_con_dato('');
                $nodo_piso_copia->_adyacente_en($cabeza_copia, 'asientos');

                $actual = $cabeza_original->adyacente('primer');
                $primer_copia = null;
                $anterior_copia = null;
                while ($actual && $actual->id() !== $cabeza_original->id()) {
                    $nodo_asiento_copia = Nodo::crear_con_dato($actual->dato());

                    $fila = $actual->adyacente('fila');
                    $columna = $actual->adyacente('columna');
                    if ($fila) $nodo_asiento_copia->_adyacente_en(Nodo::crear_con_dato($fila->dato()), 'fila');
                    if ($columna) $nodo_asiento_copia->_adyacente_en(Nodo::crear_con_dato($columna->dato()), 'columna');

                    $nodo_asiento_copia->_adyacente_en(Nodo::crear_con_dato('libre'), 'estado');

                    if ($anterior_copia) {
                        $anterior_copia->_adyacente_en($nodo_asiento_copia, 'siguiente');
                    } else {
                        $primer_copia = $nodo_asiento_copia;
                    }
                    $anterior_copia = $nodo_asiento_copia;

                    $actual = $actual->adyacente('siguiente');
                }

                if ($anterior_copia) $anterior_copia->_adyacente_en($cabeza_copia, 'siguiente');
                if ($primer_copia) $cabeza_copia->_adyacente_en($primer_copia, 'primer');
            }

            $nodo_asientos_copia->_adyacente_en($nodo_piso_copia, "piso_$i");
        }

        $nodo_copia->_adyacente_en($nodo_asientos_copia, 'asientos');
    }

    return $nodo_copia;
}

/**
 * Agrega un micro a un viaje, clonando el vehículo original.
 */
function agregar_micro_a_viaje(string $nombre_viaje, string $nombre_empresa, string $nombre_vehiculo, string $nombre_dueno, string $monto = '0', ?Nodo $nodo_contexto = null): array {
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno, $nodo_contexto);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    // Fase 1c.2: si viene contexto (terminal → compartido),
    // navegar desde ahí. El compartido tiene un contenedor
    // `empresas` con las empresas referenciadas por los viajes
    // autorizados. Sin contexto (dueño, admin), navegar por la
    // raíz `us_<dueno>` como antes.
    if ($nodo_contexto) {
        $nodo_empresas = $nodo_contexto->adyacente('empresas');
    } else {
        $nodo_dueno = Nodo::nodo_por_id('us_' . $nombre_dueno);
        if (!$nodo_dueno) return ['exito' => false, 'error' => 'Dueño no encontrado'];
        $nodo_empresas = $nodo_dueno->adyacente('empresas');
    }
    if (!$nodo_empresas) return ['exito' => false, 'error' => 'El dueño no tiene empresas'];

    $nodo_empresa = $nodo_empresas->adyacente($nombre_empresa);
    if (!$nodo_empresa) return ['exito' => false, 'error' => 'Empresa no encontrada'];

    $nodo_vehiculos = $nodo_empresa->adyacente('vehiculos');
    if (!$nodo_vehiculos) return ['exito' => false, 'error' => 'La empresa no tiene vehículos'];

    $nodo_vehiculo = $nodo_vehiculos->adyacente($nombre_vehiculo);
    if (!$nodo_vehiculo) return ['exito' => false, 'error' => 'Vehículo no encontrado'];

    // Validar monto antes de cualquier creación de nodos.
    $monto = (string) $monto;
    if (!is_numeric($monto) || (float)$monto < 0) {
        return ['exito' => false, 'error' => 'Monto inválido'];
    }

    // Validar que el vehículo tenga asientos configurados.
    // Un micro sin asientos no se puede usar: no se pueden
    // seleccionar ni vender asientos. El frontend ya filtra
    // los vehículos sin configurar del select, pero se
    // refuerza acá por si algo se saltea.
    $nodo_asientos_orig = $nodo_vehiculo->adyacente('asientos');
    $tiene_asientos = false;
    if ($nodo_asientos_orig) {
        for ($i = 1; $i <= 2; $i++) {
            $piso = $nodo_asientos_orig->adyacente("piso_$i");
            if (!$piso) continue;
            $cabeza = $piso->adyacente('asientos');
            if ($cabeza && $cabeza->adyacente('primer')) {
                $tiene_asientos = true;
                break;
            }
        }
    }
    if (!$tiene_asientos) {
        return ['exito' => false, 'error' => 'El vehículo "' . $nombre_vehiculo . '" no tiene asientos configurados'];
    }

    // Validar que el vehículo no esté ya agregado al viaje.
    // Los micros se diferencian por la patente del vehículo
    // original; dos copias del mismo vehículo son duplicados.
    // Comparación case-insensitive, igual que subir_foto_vehiculo.
    $nodo_micros = $nodo_viaje->adyacente('micros');
    if ($nodo_micros) {
        $micros_existentes = (array) $nodo_micros->adyacentes();
        foreach ($micros_existentes as $nodo_micro_existente) {
            $copia = $nodo_micro_existente->adyacente('vehiculo_copia');
            if ($copia && strcasecmp($copia->dato(), $nombre_vehiculo) === 0) {
                return ['exito' => false, 'error' => 'Ese vehículo ya está agregado a este viaje'];
            }
        }
    }

    // Clonar el vehículo.
    $nodo_copia = clonar_vehiculo($nodo_vehiculo);

    // Crear el nodo micro.
    $nodo_micro = Nodo::crear_con_dato('');
    $nodo_micro->_adyacente_en($nodo_empresa, 'empresa');
    $nodo_micro->_adyacente_en($nodo_copia, 'vehiculo_copia');
    $nodo_micro->_adyacente_en(Nodo::crear_con_dato($monto), 'monto');
    $nodo_micro->_adyacente_en(Nodo::crear_con_dato('0'), 'ocupacion');
    $nodo_micro->_adyacente_en(Nodo::crear_con_dato('0'), 'seleccionados');
    $nodo_micro->_adyacente_en(Nodo::crear_con_dato('0'), 'vendidos');
    $nodo_micro->_adyacente_en(Nodo::crear_con_dato('0'), 'reservados');
    $nodo_micro->_adyacente_en(Nodo::crear_con_dato('0'), 'disponibles');
    $nodo_micro->_adyacente_en($nodo_viaje, 'viaje');

    // Nombre del micro: max(existentes) + 1.
    // No se usa count+1 porque si se elimina un micro del medio,
    // el próximo nombre calculado puede colisionar con uno ya
    // existente (ej: micro_1, micro_3 tras borrar micro_2;
    // count+1 daría micro_3, que ya existe).
    if (!$nodo_micros) {
        $nodo_micros = Nodo::crear_con_dato('');
        $nodo_viaje->_adyacente_en($nodo_micros, 'micros');
    }
    $adyacentes_micros = (array) $nodo_micros->adyacentes();
    $max_indice = 0;
    foreach (array_keys($adyacentes_micros) as $clave) {
        if (preg_match('/^micro_(\d+)$/', (string)$clave, $m)) {
            $n = (int)$m[1];
            if ($n > $max_indice) $max_indice = $n;
        }
    }
    $nombre_micro = 'micro_' . ($max_indice + 1);

    // Chequear el resultado del enlace. Con max+1 no debería
    // colisionar, pero por defensa: si _adyacente_en falla
    // silenciosamente, el nodo del micro queda huérfano y el
    // micro nunca aparece en el viaje.
    $nodo_micros->_adyacente_en($nodo_micro, $nombre_micro);
    if (!$nodo_micros->adyacente($nombre_micro)) {
        return ['exito' => false, 'error' => 'No se pudo asignar un nombre libre al micro (colisión con ' . $nombre_micro . ')'];
    }

    actualizar_contadores_micro($nodo_micro);
    actualizar_contadores_viaje($nombre_viaje, $nombre_dueno);

    // Fase B2.4.3 (v77q): si el viaje ya estaba autorizado
    // a alguna terminal, la empresa del micro nuevo tiene
    // que aparecer en el `empresas` del compartido. Se
    // sincroniza cada terminal autorizada del viaje.
    // Idempotente: si el viaje y la empresa ya estaban, no
    // hace nada.
    $nodo_tas = $nodo_viaje->adyacente('terminales_autorizadas');
    if ($nodo_tas) {
        foreach ((array)$nodo_tas->adyacentes() as $nombre_terminal => $nodo_tv) {
            $nombre_terminal = (string)$nombre_terminal;
            if ($nombre_terminal === '') continue;
            _sincronizar_terminal_en_compartido_del_viaje($nodo_viaje, $nombre_terminal, $nombre_dueno);
        }
    }

    guardar_ambos(ConfiguracionApli::NOMBRE_APP);
    return ['exito' => true, 'nombre_micro' => $nombre_micro];
}

/**
 * Elimina un micro de un viaje.
 *
 * A partir de v1.5piloto.74s (Fase 2 del plan de optimización
 * del grafo): destruye el micro completo (copia de vehículo,
 * pisos, asientos, campos) en lugar de solo desenlazarlo del
 * contenedor. Reutiliza `_destruir_micro` de `Viaje.php`
 * (agregada en v74r). Antes de esta versión, cada eliminación
 * de un micro dejaba ~100 nodos huérfanos.
 *
 * @param string $nombre_viaje
 * @param string $nombre_micro
 * @param string $nombre_dueno
 * @return array
 */
function eliminar_micro_de_viaje(string $nombre_viaje, string $nombre_micro, string $nombre_dueno, ?Nodo $nodo_contexto = null): array {
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno, $nodo_contexto);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    $nodo_micros = $nodo_viaje->adyacente('micros');
    if (!$nodo_micros) return ['exito' => false, 'error' => 'No hay micros'];

    $nodo_micro = $nodo_micros->adyacente($nombre_micro);
    if (!$nodo_micro) return ['exito' => false, 'error' => 'Micro no encontrado'];

    // Fase 2: destruir el micro completo. Primero desenlazar
    // del contenedor del viaje, después destruir el subárbol
    // (copia de vehículo, pisos, asientos, campos).
    $nodo_micros->eliminar_adyacente($nombre_micro);
    _destruir_micro($nodo_micro);

    actualizar_contadores_viaje($nombre_viaje, $nombre_dueno, $nodo_contexto);
    guardar_ambos(ConfiguracionApli::NOMBRE_APP);
    return ['exito' => true];
}

/**
 * Actualiza el monto de un micro.
 */
function actualizar_monto_micro(string $nombre_viaje, string $nombre_micro, string $monto, string $nombre_dueno, ?Nodo $nodo_contexto = null): array {
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno, $nodo_contexto);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    $nodo_micros = $nodo_viaje->adyacente('micros');
    if (!$nodo_micros) return ['exito' => false, 'error' => 'No hay micros'];

    $nodo_micro = $nodo_micros->adyacente($nombre_micro);
    if (!$nodo_micro) return ['exito' => false, 'error' => 'Micro no encontrado'];

    $nodo_monto = $nodo_micro->adyacente('monto');
    if ($nodo_monto) {
        $nodo_monto->_dato($monto);
    } else {
        $nodo_micro->_adyacente_en(Nodo::crear_con_dato($monto), 'monto');
    }

    guardar_ambos(ConfiguracionApli::NOMBRE_APP);
    return ['exito' => true];
}

/**
 * Obtiene la información completa de un micro para mostrarla en el pasaje.
 */
function obtener_micro_de_viaje(string $nombre_viaje, string $nombre_micro, string $nombre_dueno, ?Nodo $nodo_contexto = null): array {
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno, $nodo_contexto);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    $nodo_micros = $nodo_viaje->adyacente('micros');
    if (!$nodo_micros) return ['exito' => false, 'error' => 'No hay micros'];

    $nodo_micro = $nodo_micros->adyacente($nombre_micro);
    if (!$nodo_micro) return ['exito' => false, 'error' => 'Micro no encontrado'];

    $empresa = $nodo_micro->adyacente('empresa') ? $nodo_micro->adyacente('empresa')->dato() : '';
    $nodo_copia_tmp = $nodo_micro->adyacente('vehiculo_copia');
    $patente = $nodo_copia_tmp ? $nodo_copia_tmp->dato() : ($nodo_micro->adyacente('patente') ? $nodo_micro->adyacente('patente')->dato() : '');    
    $monto = $nodo_micro->adyacente('monto') ? $nodo_micro->adyacente('monto')->dato() : '0';

    // Contadores calculados al vuelo, para no depender de que los nodos del
    // micro estén al día. Misma fuente que usa el listado de viajes.
    $contadores_micro = contar_contadores_micro($nodo_micro);
    $ocupacion = (string)$contadores_micro['ocupacion'];
    $seleccionados = (string)$contadores_micro['seleccionados'];
    $vendidos = (string)$contadores_micro['vendidos'];
    $reservados = (string)$contadores_micro['reservados'];

    $nodo_copia = $nodo_micro->adyacente('vehiculo_copia');
    if (!$nodo_copia) return ['exito' => false, 'error' => 'No existe copia del vehículo'];

    $nombre = $nodo_copia->adyacente('nombre') ? $nodo_copia->adyacente('nombre')->dato() : '';
    $foto = $nodo_copia->adyacente('foto') ? $nodo_copia->adyacente('foto')->dato() : '';

    $configuracion = ['pisos' => []];
    $nodo_asientos_copia = $nodo_copia->adyacente('asientos');
    if ($nodo_asientos_copia) {
        for ($i = 1; $i <= 2; $i++) {
            $piso = $nodo_asientos_copia->adyacente("piso_$i");
            if ($piso) {
                $config_piso = obtener_configuracion_piso_con_estado($piso);
                if ($config_piso) {
                    $configuracion['pisos'][] = $config_piso;
                }
            }
        }
    }

    return [
        'exito' => true,
        'micro' => [
            'nombre_micro' => $nombre_micro,
            'empresa' => $empresa,
            'patente' => $patente,
            'monto' => $monto,
            'ocupacion' => $ocupacion,
            'seleccionados' => $seleccionados,
            'vendidos' => $vendidos,
            'reservados' => $reservados,
            'nombre' => $nombre,
            'foto' => $foto,
            'configuracion' => $configuracion
        ]
    ];
}

/**
 * Actualiza los contadores totales del viaje (ocupación, disponibles, seleccionados, vendidos, reservados).
 */
function actualizar_contadores_viaje(string $nombre_viaje, string $nombre_dueno, ?Nodo $nodo_contexto = null): void {
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno, $nodo_contexto);
    if (!$nodo_viajes) return;

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return;

    $total_ocupacion = 0;
    $total_seleccionados = 0;
    $total_vendidos = 0;
    $total_reservados = 0;
    $total_disponibles = 0;

    $nodo_micros = $nodo_viaje->adyacente('micros');
    if ($nodo_micros) {
        $adyacentes_micros = (array) $nodo_micros->adyacentes();
        foreach ($adyacentes_micros as $nodo_micro) {
            $total_ocupacion += (int)($nodo_micro->adyacente('ocupacion') ? $nodo_micro->adyacente('ocupacion')->dato() : 0);
            $total_seleccionados += (int)($nodo_micro->adyacente('seleccionados') ? $nodo_micro->adyacente('seleccionados')->dato() : 0);
            $total_vendidos += (int)($nodo_micro->adyacente('vendidos') ? $nodo_micro->adyacente('vendidos')->dato() : 0);
            $total_reservados += (int)($nodo_micro->adyacente('reservados') ? $nodo_micro->adyacente('reservados')->dato() : 0);
        }
    }

    $total_disponibles = $total_ocupacion - $total_vendidos - $total_seleccionados - $total_reservados;

    $nodo_viaje->adyacente('ocupacion')?->_dato((string)$total_ocupacion);
    $nodo_viaje->adyacente('seleccionados')?->_dato((string)$total_seleccionados);
    $nodo_viaje->adyacente('vendidos')?->_dato((string)$total_vendidos);
    $nodo_viaje->adyacente('reservados')?->_dato((string)$total_reservados);
    $nodo_viaje->adyacente('disponibles')?->_dato((string)$total_disponibles);
}


/**
 * Cuenta los contadores de un micro recorriendo los asientos del vehículo copia.
 *
 * Devuelve un array con los 5 contadores:
 *   ocupacion, seleccionados, vendidos, reservados, disponibles.
 *
 * No escribe nada en los nodos. Se usa desde:
 *  - actualizar_contadores_micro (para persistir los valores)
 *  - obtener_micro_de_viaje (para devolver los valores al frontend sin depender
 *    de que los nodos del micro estén al día)
 *
 * @param Nodo $nodo_micro
 * @return array
 */
function contar_contadores_micro(Nodo $nodo_micro): array {
    $nodo_copia = $nodo_micro->adyacente('vehiculo_copia');
    if (!$nodo_copia) {
        return [
            'ocupacion' => 0,
            'seleccionados' => 0,
            'vendidos' => 0,
            'reservados' => 0,
            'disponibles' => 0,
        ];
    }

    $total = 0;
    $seleccionados = 0;
    $vendidos = 0;
    $reservados = 0;

    $nodo_asientos = $nodo_copia->adyacente('asientos');
    if ($nodo_asientos) {
        for ($i = 1; $i <= 2; $i++) {
            $piso = $nodo_asientos->adyacente("piso_$i");
            if (!$piso) continue;
            $cabeza = $piso->adyacente('asientos');
            if (!$cabeza) continue;
            $actual = $cabeza->adyacente('primer');
            $contador_seguridad = 0;
            while ($actual && $actual->id() !== $cabeza->id() && $contador_seguridad < 1000) {
                $estado = $actual->adyacente('estado');
                if ($estado) {
                    $estado_str = $estado->dato();
                    if ($estado_str === 'seleccionado') {
                        $seleccionados++;
                    } elseif ($estado_str === 'vendido' || $estado_str === 'no disponible') {
                        $vendidos++;
                    } elseif ($estado_str === 'reservado') {
                        $reservados++;
                    }
                    $total++;
                }
                $actual = $actual->adyacente('siguiente');
                $contador_seguridad++;
            }
        }
    }

    $disponibles = max(0, $total - $vendidos - $seleccionados - $reservados);

    return [
        'ocupacion' => $total,
        'seleccionados' => $seleccionados,
        'vendidos' => $vendidos,
        'reservados' => $reservados,
        'disponibles' => $disponibles,
    ];
}

/**
 * Actualiza los contadores de un micro (ocupación, seleccionados, vendidos, reservados).
 */
function actualizar_contadores_micro(Nodo $nodo_micro): void {
    $nodo_copia = $nodo_micro->adyacente('vehiculo_copia');
    if (!$nodo_copia) return;

    // Asegurar que existan los nodos de contadores
    foreach (['ocupacion', 'seleccionados', 'vendidos', 'reservados', 'disponibles'] as $campo) {
        if (!$nodo_micro->adyacente($campo)) {
            $nodo_micro->_adyacente_en(Nodo::crear_con_dato('0'), $campo);
        }
    }

    $c = contar_contadores_micro($nodo_micro);

    $nodo_micro->adyacente('ocupacion')?->_dato((string)$c['ocupacion']);
    $nodo_micro->adyacente('seleccionados')?->_dato((string)$c['seleccionados']);
    $nodo_micro->adyacente('vendidos')?->_dato((string)$c['vendidos']);
    $nodo_micro->adyacente('reservados')?->_dato((string)$c['reservados']);
    $nodo_micro->adyacente('disponibles')?->_dato((string)$c['disponibles']);
}
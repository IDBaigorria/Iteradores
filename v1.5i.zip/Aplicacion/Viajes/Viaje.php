<?php
/**
 * Núcleo de gestión de viajes.
 *
 * @package   Iteradores
 * @since     1.5piloto.8
 * @version   1.5piloto.76w
 */

use Iteradores\Nodos\Nodo;
use Iteradores\Controlador\Controlador;
use Iteradores\Configuracion\Conf;
include_once("./Configuracion/Configuracion.php");
include_once("./Nodos/Nodo.php");
include_once("./Controlador/Controlador.php");
include_once("./miscelaneas/Arbol.php");
include_once("./Aplicacion/FuncionesAuxiliares.php");

/**
 * Texto por defecto de la declaración jurada del pasajero mayor de 18 años
 * (Anexo I). Se usa cuando el viaje todavía no tiene una declaración guardada.
 */
const TEXTO_DJ_MAYOR_DEFAULT = <<<'HTML'
ANEXO I
DECLARACIÓN JURADA DEL PASAJERO MAYOR DE 18 AÑOS

VIAJE TURÍSTICO / RELIGIOSO

Quien suscribe, ..........................................................................................................................

DNI ..........................................................., domiciliado/a en ....................................................................................................................,

localidad de ...................................................................................................................., participará del viaje turístico/religioso denominado

{{NOMBRE_VIAJE}}

a realizarse en {{DESTINO_VIAJE}},

el/los día/días {{FECHA_VIAJE}}

Declaro que he sido informado/a de las características del viaje, las actividades previstas, el medio de transporte, los lugares de alojamiento y demás servicios comprendidos.

Asimismo, dejo constancia de cualquier información de salud, indicación o circunstancia que considere necesario comunicar a los responsables del viaje:

....................................................................................................................................................................................

....................................................................................................................................................................................

....................................................................................................................................................................................

Obra Social / Prepaga: ............................................................................................................

N.º de afiliado: ........................................................................................................................

Teléfonos de contacto en caso de urgencia:

........................................................................................................................................................

........................................................................................................................................................

DATOS DE SALUD

Autorizo que la información de salud proporcionada en este formulario pueda ser registrada y digitalizada exclusivamente para facilitar la organización y asistencia durante el viaje.

Dicha información tendrá acceso limitado a las personas responsables que necesiten conocerla y podrá ser comunicada a profesionales o servicios de salud cuando resulte necesario ante una situación de asistencia.

La información será conservada durante el tiempo necesario para dichas finalidades y conforme a la normativa aplicable.

CONSENTIMIENTO PARA EL TRATAMIENTO DE DATOS DE SALUD

De conformidad con lo dispuesto por el artículo 7 de la Ley 25.326 de Protección de Datos Personales, presto mi consentimiento expreso y por escrito para el tratamiento de los datos de salud consignados en este formulario.

☐ SÍ, PRESTÓ MI CONSENTIMIENTO al tratamiento de mis datos de salud en los términos del artículo 7 de la Ley 25.326.
   (tildar o marcar con una X)

Asimismo, autorizo, en caso de necesidad y urgencia, a que se solicite asistencia médica y se adopten las indicaciones que los profesionales de la salud consideren necesarias, en los términos del artículo 9 de la Ley 26.529 de Derechos del Paciente, procurando que se me informe de ello a la brevedad posible.

Declaro que los datos consignados son verdaderos y que comunicaré cualquier circunstancia que considere relevante para mi seguridad o asistencia durante el viaje.

<br>

Firma: ..............................................................................................................

Aclaración: ........................................................................................................

DNI: ...................................................................................................................

Fecha: ....../....../............

El titular de los datos puede ejercer los derechos de acceso, rectificación, supresión y oposición previstos en la Ley 25.326 contactando al organizador del viaje.
HTML;

/**
 * Texto por defecto de la declaración jurada del pasajero menor de 18 años
 * (Anexo II). Se usa cuando el viaje todavía no tiene una declaración guardada.
 */
const TEXTO_DJ_MENOR_DEFAULT = <<<'HTML'
ANEXO II
AUTORIZACIÓN Y DECLARACIÓN DEL PASAJERO MENOR DE 18 AÑOS

VIAJE TURÍSTICO / RELIGIOSO

Por la presente, quien suscribe ....................................................................................................................,

DNI ..........................................................., en carácter de:

☐ Padre  ☐ Madre  ☐ Tutor/a  ☐ Responsable
   (tildar o marcar con una X)

autorizo al/la menor ....................................................................................................................,

DNI ..........................................................., a participar del viaje turístico/religioso denominado

{{NOMBRE_VIAJE}}

a realizarse en {{DESTINO_VIAJE}},

el/los día/días {{FECHA_VIAJE}}

Declaro haber sido informado/a de las características del viaje, las actividades previstas, el medio de transporte, los lugares de alojamiento y demás servicios comprendidos.

SALUD

Dejo constancia de cualquier información de salud, indicación o circunstancia que considere necesario que conozcan los responsables del viaje:

....................................................................................................................................................................................

....................................................................................................................................................................................

....................................................................................................................................................................................

Obra Social / Prepaga: ............................................................................................................

N.º de afiliado: ........................................................................................................................

Teléfonos de contacto en caso de urgencia:

........................................................................................................................................................

........................................................................................................................................................

Autorizo que la información de salud proporcionada en este formulario pueda ser registrada y digitalizada exclusivamente para facilitar la organización y asistencia del menor durante el viaje.

Dicha información tendrá acceso limitado a las personas responsables que necesiten conocerla y podrá ser comunicada a profesionales o servicios de salud cuando resulte necesario ante una situación de asistencia.

La información será conservada durante el tiempo necesario para dichas finalidades y conforme a la normativa aplicable.

CONSENTIMIENTO PARA EL TRATAMIENTO DE DATOS DE SALUD DEL MENOR

De conformidad con lo dispuesto por el artículo 7 de la Ley 25.326 de Protección de Datos Personales, en mi carácter de padre, madre, tutor/a o responsable legal del menor, presto consentimiento expreso y por escrito para el tratamiento de los datos de salud del menor consignados en este formulario.

☐ SÍ, PRESTÓ MI CONSENTIMIENTO al tratamiento de los datos de salud del menor en los términos del artículo 7 de la Ley 25.326.
   (tildar o marcar con una X)

Asimismo, autorizo, en caso de necesidad y urgencia, a que se solicite asistencia médica para el/la menor y se adopten las indicaciones que los profesionales de la salud consideren necesarias, en los términos del artículo 9 de la Ley 26.529 de Derechos del Paciente, procurando que se me informe de ello a la brevedad posible.

Declaro que los datos consignados son verdaderos y que informaré cualquier circunstancia que considere relevante para la seguridad o asistencia del/la menor durante el viaje.

<br>

Firma del padre, madre, tutor/a o responsable:
....................................................................................................................

Aclaración: ........................................................................................................

DNI: ...................................................................................................................

Teléfono: ............................................................................................................

Fecha: ....../....../............

El titular de los datos (o su representante legal) puede ejercer los derechos de acceso, rectificación, supresión y oposición previstos en la Ley 25.326 contactando al organizador del viaje.
HTML;

/**
 * Devuelve el nodo desde el que un terminal debe navegar
 * para acceder al subgrafo de su dueño.
 *
 * A partir de v76r (Fase B2.2.1 del modelo topológico).
 * Antes de la Fase B2.3 (repuntado), el enlace `dueno` del
 * terminal apunta al nodo real del dueño. Después del
 * repuntado, apuntará al contenedor `compartido_con_<terminal>`.
 *
 * En ambos casos, el nodo devuelto tiene el mismo dato
 * (nombre del dueño) y los mismos sub-contenedores (`viajes`,
 * `empresas`, `ventas`, `pasajeros`, `cancelaciones`,
 * `terminales`), así el código del terminal puede navegar
 * por `adyacente()` sin saber si está viendo el grafo
 * completo o solo lo compartido.
 *
 * @param string $nombre_terminal
 * @return Nodo|null
 */
function _contexto_terminal(string $nombre_terminal) {
    $raiz = Nodo::nodo_por_id('usuarios');
    if (!$raiz) return null;
    $nodo_terminal = $raiz->adyacente($nombre_terminal);
    if (!$nodo_terminal) return null;
    return $nodo_terminal->adyacente('dueno');
}

/**
 * Obtiene el contenedor de viajes de un dueño, creándolo si no existe.
 *
 * A partir de v76r (Fase B2.2.1 del modelo topológico): acepta
 * un `?Nodo $nodo_contexto` opcional. Si viene, navega desde
 * ahí en lugar de resolver `usuarios → dueño`. Es el mecanismo
 * por el que un terminal accede a sus viajes compartidos sin
 * pasar por la raíz `usuarios`.
 *
 * @param string    $nombre_dueno
 * @param Nodo|null $nodo_contexto
 * @return Nodo|null
 */
function obtener_contenedor_viajes_dueno(string $nombre_dueno, ?Nodo $nodo_contexto = null) {
    if ($nodo_contexto === null) {
        $raiz_usuarios = Nodo::nodo_por_id('usuarios');
        if (!$raiz_usuarios) return null;

        $nodo_contexto = $raiz_usuarios->adyacente($nombre_dueno);
    }
    if (!$nodo_contexto) return null;

    $nodo_viajes = $nodo_contexto->adyacente('viajes');
    if (!$nodo_viajes) {
        $nodo_viajes = Nodo::crear_con_dato('');
        $nodo_contexto->_adyacente_en($nodo_viajes, 'viajes');
    }
    return $nodo_viajes;
}

/**
 * Lista viajes de un dueño.
 */
function listar_viajes_de_dueno(string $nombre_dueno): array {
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return [];

    $adyacentes = (array) $nodo_viajes->adyacentes();
    if (!$adyacentes) return [];

    // Fase 3, v76a: precalcular el índice de ventas por viaje
    // UNA VEZ. Antes, formatear_viaje recorría todo el contenedor
    // de ventas del dueño por cada viaje (O(V × W)).
    $indice_ventas = _construir_indice_ventas_por_viaje($nombre_dueno);

    $viajes = [];
    foreach ($adyacentes as $nombre_viaje => $nodo_viaje) {
        $viajes[] = formatear_viaje($nombre_viaje, $nodo_viaje, null, $indice_ventas);
    }
    return $viajes;
}

/**
 * Lista viajes autorizados para una terminal.
 */
function listar_viajes_de_terminal(string $nombre_terminal): array {
    $raiz_usuarios = Nodo::nodo_por_id('usuarios');
    if (!$raiz_usuarios) return [];

    $nodo_terminal = $raiz_usuarios->adyacente($nombre_terminal);
    if (!$nodo_terminal) return [];

    $nodo_dueno = $nodo_terminal->adyacente('dueno');
    if (!$nodo_dueno) return [];

    $nombre_dueno = $nodo_dueno->dato();

    // Fase B2.2.1 del modelo topológico: pasar el nodo del
    // dueño (o, tras el repuntado de B2.3, el compartido del
    // terminal) como contexto, en lugar de resolver
    // `usuarios → dueño` otra vez. Así el terminal navega por
    // el subgrafo correcto sin depender de la raíz global.
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno, $nodo_dueno);
    if (!$nodo_viajes) return [];

    // Fase 3, v76a: precalcular el índice de ventas por viaje
    // UNA VEZ, con el terminal como filtro. Antes, formatear_viaje
    // recorría todo el contenedor de ventas del dueño por cada
    // viaje (O(V × W)).
    // Fase B2.2.2 (v76s): pasar el contexto del terminal
    // (hoy el nodo del dueño, tras B2.3 el compartido).
    $indice_ventas = _construir_indice_ventas_por_viaje($nombre_dueno, $nombre_terminal, $nodo_dueno);

    $viajes_autorizados = [];
    $adyacentes = (array) $nodo_viajes->adyacentes();
    foreach ($adyacentes as $nombre_viaje => $nodo_viaje) {
        $viaje = formatear_viaje($nombre_viaje, $nodo_viaje, $nombre_terminal, $indice_ventas);
        if (in_array($nombre_terminal, $viaje['terminales_autorizadas'])) {
            $viajes_autorizados[] = $viaje;
        }
    }
    return $viajes_autorizados;
}

/**
 * Formatea los datos de un viaje, incluyendo micros, terminales y opciones.
 * Si se pasa $nombre_terminal, se calcula 'vendidos_aqui' por micro para esa terminal.
 *
 * El campo 'reservados' del viaje se calcula siempre sumando los reservados
 * de cada micro, para no depender de que el nodo persistido del viaje esté
 * actualizado (viajes creados antes de la v1.5piloto.27 pueden tener el nodo
 * 'reservados' en "0" o inexistente).
 */
function formatear_viaje(string $nombre_viaje, $nodo_viaje, ?string $nombre_terminal = null, ?array $indice_ventas = null): array {
    $datos = [];
    $datos['nombre_viaje'] = $nombre_viaje;
    $datos['dueno'] = $nodo_viaje->adyacente('dueno') ? $nodo_viaje->adyacente('dueno')->dato() : '';
    $datos['nombre'] = $nodo_viaje->adyacente('nombre') ? $nodo_viaje->adyacente('nombre')->dato() : '';
    $datos['fecha'] = $nodo_viaje->adyacente('fecha') ? $nodo_viaje->adyacente('fecha')->dato() : '';
    $datos['fecha_visible'] = formatear_fecha_visible($datos['fecha']);
    $datos['hora'] = $nodo_viaje->adyacente('hora') ? $nodo_viaje->adyacente('hora')->dato() : '';
    $datos['origen'] = $nodo_viaje->adyacente('origen') ? $nodo_viaje->adyacente('origen')->dato() : '';
    $datos['destino'] = $nodo_viaje->adyacente('destino') ? $nodo_viaje->adyacente('destino')->dato() : '';
    // Los contadores se calculan al final del loop de micros, sumando los de cada micro.
    // Así no dependemos de que los nodos del viaje estén al día: cualquier
    // desfase entre el nodo del viaje y el estado real de los micros se
    // evita calculándolos siempre al vuelo.
    $datos['ocupacion'] = '0';
    $datos['disponibles'] = '0';
    $datos['seleccionados'] = '0';
    $datos['vendidos'] = '0';
    $datos['reservados'] = '0';

    // Paradas intermedias (lista tipo árbol hmi/hd).
    // A partir de v1.5piloto.34 cada parada se devuelve como objeto
    // {nombre, hora_estimada}. La hora estimada es opcional.
    $paradas = [];
    $nodo_paradas = $nodo_viaje->adyacente('paradas_intermedias');
    if ($nodo_paradas) {
        $actual_parada = hmi($nodo_paradas);
        $seg = 0;
        while ($actual_parada && $seg < 100) {
            $nodo_hora = $actual_parada->adyacente('hora_estimada');
            $paradas[] = [
                'nombre' => $actual_parada->dato(),
                'hora_estimada' => $nodo_hora ? $nodo_hora->dato() : '',
            ];
            $actual_parada = hd($actual_parada);
            $seg++;
        }
    }
    $datos['paradas_intermedias'] = $paradas;

    // Determinar si el viaje está activo
    $fecha = $datos['fecha'];
    if ($fecha === 'a confirmar' || $fecha === '') {
        $datos['activo'] = '1';
    } else {
        $hoy = date('Y-m-d');
        $datos['activo'] = (strtotime($fecha) >= strtotime($hoy)) ? '1' : '0';
    }

    // Verificar si tiene ventas.
    // Fase 3, v76a: si viene el índice precalculado, usarlo.
    // Si no, computar al vuelo (fallback para llamadores que no
    // pasan el índice, como los llamados puntuales).
    if ($indice_ventas !== null) {
        $tiene_ventas_bool = !empty($indice_ventas['tiene_ventas'][$nombre_viaje]);
    } else {
        $tiene_ventas_bool = viaje_tiene_ventas($datos['dueno'], $nombre_viaje);
    }
    $datos['tiene_ventas'] = $tiene_ventas_bool ? '1' : '0';

    // Calcular ventas por micro de la terminal actual (si corresponde).
    // Fase 3, v76a: si viene el índice precalculado, usarlo.
    // Si no, computar al vuelo (fallback).
    $vendidos_por_micro = [];
    if ($nombre_terminal !== null) {
        if ($indice_ventas !== null) {
            $vendidos_por_micro = $indice_ventas['vendidos_por_micro'][$nombre_viaje][$nombre_terminal] ?? [];
        } else {
            $vendidos_por_micro = _calcular_vendidos_por_micro_de_viaje($datos['dueno'], $nombre_viaje, $nombre_terminal);
        }
    }

    // Pre-cargar el contenedor de empresas del dueño (para resolver nombres visibles)
    $raiz_usuarios = Nodo::nodo_por_id('usuarios');
    $nodo_dueno_iter = $raiz_usuarios ? $raiz_usuarios->adyacente($datos['dueno']) : null;
    $nodo_empresas = $nodo_dueno_iter ? $nodo_dueno_iter->adyacente('empresas') : null;

    // Micros
    $micros = [];
    $total_reservados_micros = 0;
    $total_seleccionados_micros = 0;
    $total_vendidos_micros = 0;
    $total_ocupacion_micros = 0;
    $nodo_micros = $nodo_viaje->adyacente('micros');
    if ($nodo_micros) {
        $adyacentes_micros = (array) $nodo_micros->adyacentes();
        foreach ($adyacentes_micros as $nombre_micro => $nodo_micro) {
            // Identificador de empresa: puede venir como nodo enlazado (micros nuevos)
            // o como nodo suelto cuyo dato es el string (micros viejos).
            $identificador_empresa = '';
            $nodo_empresa_enlazada = $nodo_micro->adyacente('empresa');
            if ($nodo_empresa_enlazada) {
                $identificador_empresa = $nodo_empresa_enlazada->dato();
            }

            // Nombre visible: buscar siempre la empresa real en el contenedor del dueño
            // usando el identificador. Esto funciona para micros nuevos y viejos.
            $nombre_empresa = $identificador_empresa;
            if ($identificador_empresa !== '' && $nodo_empresas) {
                $nodo_empresa_real = $nodo_empresas->adyacente($identificador_empresa);
                if ($nodo_empresa_real && $nodo_empresa_real->adyacente('nombre')) {
                    $nombre_empresa = $nodo_empresa_real->adyacente('nombre')->dato();
                }
            }

            // Patente: preferentemente desde vehiculo_copia (config nueva), fallback al enlace viejo
            $patente = '';
            $nodo_copia = $nodo_micro->adyacente('vehiculo_copia');
            if ($nodo_copia) {
                $patente = $nodo_copia->dato();
            } else {
                $nodo_patente = $nodo_micro->adyacente('patente');
                if ($nodo_patente) $patente = $nodo_patente->dato();
            }

            // Nombre visible del vehículo (desde la copia clonada)
            $nombre_vehiculo = $patente;
            if ($nodo_copia && $nodo_copia->adyacente('nombre')) {
                $nombre_vehiculo = $nodo_copia->adyacente('nombre')->dato();
            }

            // Contadores calculados al vuelo desde los asientos reales del micro.
            // No dependemos de los nodos 'seleccionados', 'vendidos', etc. del
            // micro, que pueden estar desactualizados si alguna operación no
            // llamó a actualizar_contadores_micro.
            $c_micro = contar_contadores_micro($nodo_micro);

            $total_reservados_micros += $c_micro['reservados'];
            $total_seleccionados_micros += $c_micro['seleccionados'];
            $total_vendidos_micros += $c_micro['vendidos'];
            $total_ocupacion_micros += $c_micro['ocupacion'];

            $micros[] = [
                'nombre_micro' => $nombre_micro,
                'empresa' => $identificador_empresa,
                'patente' => $patente,
                'nombre_empresa' => $nombre_empresa,
                'nombre_vehiculo' => $nombre_vehiculo,
                'monto' => $nodo_micro->adyacente('monto') ? $nodo_micro->adyacente('monto')->dato() : '0',
                'ocupacion' => (string)$c_micro['ocupacion'],
                'seleccionados' => (string)$c_micro['seleccionados'],
                'vendidos' => (string)$c_micro['vendidos'],
                'reservados' => (string)$c_micro['reservados'],
                'disponibles' => (string)$c_micro['disponibles'],
                'vendidos_aqui' => ($nombre_terminal !== null) ? (string)($vendidos_por_micro[$nodo_micro->id()] ?? 0) : null,
            ];
        }
    }
    $datos['micros'] = $micros;

    // Contadores del viaje: siempre la suma de los contadores de cada micro.
    // Fórmula de disponibles consistente con el micro: los seleccionados y los
    // reservados siguen restando, porque mientras lo están no pueden venderse
    // desde otra terminal ni ser reservados de nuevo.
    $datos['ocupacion'] = (string)$total_ocupacion_micros;
    $datos['seleccionados'] = (string)$total_seleccionados_micros;
    $datos['vendidos'] = (string)$total_vendidos_micros;
    $datos['reservados'] = (string)$total_reservados_micros;
    $datos['disponibles'] = (string)max(
        0,
        $total_ocupacion_micros - $total_vendidos_micros - $total_seleccionados_micros - $total_reservados_micros
    );

    // Terminales autorizadas
    // NOTA v1.5piloto.31: las claves del contenedor siguen siendo los nombres de las terminales,
    // pero los nodos destino son ahora "Nodo TerminalViaje" (nodo intermedio), no el Nodo Usuario
    // terminal directamente. Acá solo devolvemos la lista de nombres, que es lo que consume el front.
    $terminales = [];
    $nodo_terminales = $nodo_viaje->adyacente('terminales_autorizadas');
    if ($nodo_terminales) {
        $adyacentes_terminales = (array) $nodo_terminales->adyacentes();
        foreach ($adyacentes_terminales as $nombre_terminal_iter => $nodo_terminal) {
            $terminales[] = $nombre_terminal_iter;
        }
    }
    $datos['terminales_autorizadas'] = $terminales;

    // Opciones avanzadas (definida en ViajeOpciones.php)
    $datos['opciones_avanzadas'] = obtener_opciones_avanzadas_viaje($datos['dueno'], $nombre_viaje);
    return $datos;
}

/**
 * Verifica si un viaje tiene ventas registradas.
 */
function viaje_tiene_ventas(string $nombre_dueno, string $nombre_viaje): bool {
    $raiz_usuarios = Nodo::nodo_por_id('usuarios');
    if (!$raiz_usuarios) return false;

    $nodo_dueno = $raiz_usuarios->adyacente($nombre_dueno);
    if (!$nodo_dueno) return false;

    $contenedor_ventas = $nodo_dueno->adyacente('ventas');
    if (!$contenedor_ventas) return false;

    $actual = hmi($contenedor_ventas);
    while ($actual) {
        $nodo_viaje_venta = $actual->adyacente('viaje');
        if ($nodo_viaje_venta && $nodo_viaje_venta->dato() === $nombre_viaje) {
            return true;
        }
        $actual = hd($actual);
    }
    return false;
}

/**
 * Calcula las ventas por micro de una terminal para un viaje.
 *
 * Recorre todo el contenedor de ventas del dueño y devuelve un
 * mapa micro_id => cantidad de asientos vendidos por esa terminal
 * en ese viaje. Solo cuenta las ventas cuya terminal y viaje
 * coinciden.
 *
 * Es el cómputo original que hacía formatear_viaje inline. Se
 * extrajo a un helper en v76a (Fase 3) para que el fallback
 * (cuando formatear_viaje se llama sin índice precalculado)
 * use el mismo código que la variante con índice.
 *
 * @param string $nombre_dueno
 * @param string $nombre_viaje
 * @param string $nombre_terminal
 * @return array<int|string, int> micro_id => cantidad
 */
function _calcular_vendidos_por_micro_de_viaje(string $nombre_dueno, string $nombre_viaje, string $nombre_terminal): array {
    $vendidos_por_micro = [];
    $contenedor_ventas = obtener_contenedor_ventas_dueno($nombre_dueno);
    if (!$contenedor_ventas) return $vendidos_por_micro;
    $venta_iter = hmi($contenedor_ventas);
    $seg = 0;
    while ($venta_iter && $seg < 2000) {
        $nodo_terminal_venta = $venta_iter->adyacente('terminal');
        $nodo_micro_venta = $venta_iter->adyacente('micro');
        $nodo_viaje_venta = $venta_iter->adyacente('viaje');

        if ($nodo_terminal_venta && $nodo_terminal_venta->dato() === $nombre_terminal
            && $nodo_viaje_venta && $nodo_viaje_venta->dato() === $nombre_viaje
            && $nodo_micro_venta) {
            $micro_id = $nodo_micro_venta->id();
            $cabeza = $venta_iter->adyacente('asientos');
            $cantidad = 0;
            if ($cabeza) {
                $asiento = $cabeza->adyacente('primer');
                $seg2 = 0;
                while ($asiento && $seg2 < 100) {
                    $cantidad++;
                    $asiento = $asiento->adyacente('siguiente');
                    $seg2++;
                }
            }
            $vendidos_por_micro[$micro_id] = ($vendidos_por_micro[$micro_id] ?? 0) + $cantidad;
        }
        $venta_iter = hd($venta_iter);
        $seg++;
    }
    return $vendidos_por_micro;
}

/**
 * Construye el índice de ventas por viaje de un dueño,
 * recorriendo el contenedor de ventas UNA SOLA VEZ.
 *
 * Devuelve un array con dos partes:
 *
 *   [
 *     'tiene_ventas' => [nombre_viaje => bool],
 *     'vendidos_por_micro' => [
 *       nombre_viaje => [nombre_terminal => [micro_id => int]]
 *     ]
 *   ]
 *
 * La parte `vendidos_por_micro` solo se llena si se pasa
 * $nombre_terminal. Si es null, se omite (los llamadores que
 * no necesitan ese dato evitan el costo).
 *
 * Se usa desde listar_viajes_de_dueno y listar_viajes_de_terminal
 * para pasar el índice a formatear_viaje, y así evitar
 * recorrer el contenedor de ventas por cada viaje (O(V × W)).
 * Fase 3 del plan de optimización del grafo, v76a.
 *
 * @param string      $nombre_dueno
 * @param string|null $nombre_terminal
 * @return array
 */
function _construir_indice_ventas_por_viaje(string $nombre_dueno, ?string $nombre_terminal = null, ?Nodo $nodo_contexto = null): array {
    $indice = [
        'tiene_ventas' => [],
        'vendidos_por_micro' => [],
    ];
    $contenedor_ventas = obtener_contenedor_ventas_dueno($nombre_dueno, $nodo_contexto);
    if (!$contenedor_ventas) return $indice;

    // Fase B2.3.2 (v76w): nombres de enlace calculados a partir
    // del contexto. Si el contexto no es un compartido marcado,
    // devuelve null y usa los default.
    $nombres = _nombres_arbol_para_contexto($nodo_contexto, $nombre_terminal ?? '');

    $venta_iter = hmi($contenedor_ventas, $nombres);
    $seg = 0;
    while ($venta_iter && $seg < 2000) {
        $nodo_viaje_venta = $venta_iter->adyacente('viaje');
        if ($nodo_viaje_venta) {
            $nombre_viaje = $nodo_viaje_venta->dato();
            $indice['tiene_ventas'][$nombre_viaje] = true;

            if ($nombre_terminal !== null) {
                $nodo_terminal_venta = $venta_iter->adyacente('terminal');
                $nodo_micro_venta = $venta_iter->adyacente('micro');
                if ($nodo_terminal_venta && $nodo_terminal_venta->dato() === $nombre_terminal
                    && $nodo_micro_venta) {
                    $micro_id = $nodo_micro_venta->id();
                    $cabeza = $venta_iter->adyacente('asientos');
                    $cantidad = 0;
                    if ($cabeza) {
                        $asiento = $cabeza->adyacente('primer');
                        $seg2 = 0;
                        while ($asiento && $seg2 < 100) {
                            $cantidad++;
                            $asiento = $asiento->adyacente('siguiente');
                            $seg2++;
                        }
                    }
                    if (!isset($indice['vendidos_por_micro'][$nombre_viaje])) {
                        $indice['vendidos_por_micro'][$nombre_viaje] = [];
                    }
                    if (!isset($indice['vendidos_por_micro'][$nombre_viaje][$nombre_terminal])) {
                        $indice['vendidos_por_micro'][$nombre_viaje][$nombre_terminal] = [];
                    }
                    $indice['vendidos_por_micro'][$nombre_viaje][$nombre_terminal][$micro_id] =
                        ($indice['vendidos_por_micro'][$nombre_viaje][$nombre_terminal][$micro_id] ?? 0) + $cantidad;
                }
            }
        }
        $venta_iter = hd($venta_iter, $nombres);
        $seg++;
    }
    return $indice;
}

/**
 * Guarda la lista de paradas intermedias en el nodo viaje.
 * Reemplaza por completo la lista actual.
 *
 * A partir de v1.5piloto.31:
 * - Reutiliza los nodos parada existentes cuando el nombre coincide, para no
 *   romper el enlace `punto_subida_bajada` de los Nodos TerminalViaje.
 * - Rechaza la operación si alguna parada que está siendo referenciada por algún
 *   TerminalViaje (vía `punto_subida_bajada`) quedaría fuera de la nueva lista.
 *
 * A partir de v1.5piloto.34:
 * - Acepta elementos como string (retrocompatible) o como array
 *   {nombre, hora_estimada}. La hora se valida contra /^\d{2}:\d{2}$/;
 *   si no cumple, se guarda vacío.
 * - Escribe el enlace `hora_estimada` en el nodo parada cuando corresponda.
 *
 * @param Nodo $nodo_viaje Nodo del viaje.
 * @param array $paradas Lista de paradas (strings u objetos {nombre, hora_estimada}).
 * @return array Resultado con 'exito' => true, o 'exito' => false + 'error'.
 */
function _guardar_paradas_intermedias(Nodo $nodo_viaje, array $paradas): array {
    // 1. Normalizar la lista nueva.
    //    Array asociativo nombre => hora (string). Si hay repetidos, gana el último.
    $paradas_normalizadas = [];
    foreach ($paradas as $p) {
        if (is_array($p)) {
            $nombre = trim((string)($p['nombre'] ?? ''));
            $hora = trim((string)($p['hora_estimada'] ?? ''));
        } else {
            $nombre = trim((string)$p);
            $hora = '';
        }
        if ($nombre === '') continue;
        // Validar formato HH:MM. Si no cumple, se guarda vacío.
        if ($hora !== '' && !preg_match('/^\d{2}:\d{2}$/', $hora)) {
            $hora = '';
        }
        $paradas_normalizadas[$nombre] = $hora;
    }

    $nombres_nuevos = array_keys($paradas_normalizadas);

    // 2. Validar que ninguna parada en uso quede fuera del set nuevo
    $nodo_terminales = $nodo_viaje->adyacente('terminales_autorizadas');
    if ($nodo_terminales) {
        $adyacentes = (array) $nodo_terminales->adyacentes();
        foreach ($adyacentes as $nombre_terminal => $nodo_tv) {
            // Saltar nodos viejos sin migrar (formato anterior a v1.5piloto.31)
            if (!$nodo_tv->adyacente('terminal')) continue;

            $nodo_punto = $nodo_tv->adyacente('punto_subida_bajada');
            if (!$nodo_punto) continue;

            $nombre_parada = $nodo_punto->dato();
            if (!isset($paradas_normalizadas[$nombre_parada])) {
                return [
                    'exito' => false,
                    'error' => "No se puede eliminar la parada \"$nombre_parada\" porque está siendo usada como punto de subida/bajada por la terminal \"$nombre_terminal\". Primero hay que liberar esa configuración."
                ];
            }
        }
    }

    // 3. Indexar los nodos parada existentes por su dato (para reutilizarlos)
    $nodos_existentes = [];
    $nodo_paradas = $nodo_viaje->adyacente('paradas_intermedias');
    if ($nodo_paradas) {
        $actual = hmi($nodo_paradas);
        $seg = 0;
        while ($actual && $seg < 500) {
            $nodos_existentes[$actual->dato()] = $actual;
            $actual = hd($actual);
            $seg++;
        }
        // Vaciar la lista (los nodos en sí quedan vivos hasta que se reutilicen o queden huérfanos)
        while ($hijo = hmi($nodo_paradas)) {
            eliminar_hmi($nodo_paradas);
        }
    } else {
        $nodo_paradas = Nodo::crear_con_dato('');
        $nodo_viaje->_adyacente_en($nodo_paradas, 'paradas_intermedias');
    }

    // 4. Reinsertar en orden (usando _hmi, que agrega al inicio, por eso invertimos)
    $nombres_invertidos = array_reverse($nombres_nuevos);
    foreach ($nombres_invertidos as $nombre_parada) {
        $hora = $paradas_normalizadas[$nombre_parada];

        if (isset($nodos_existentes[$nombre_parada])) {
            $nodo_parada = $nodos_existentes[$nombre_parada];
            // Actualizar la hora estimada del nodo reutilizado
            $nodo_hora = $nodo_parada->adyacente('hora_estimada');
            if ($hora === '') {
                // Fase 2, v75a: destruir la hoja `hora_estimada`
                // en lugar de solo desenlazarla.
                if ($nodo_hora) {
                    $nodo_parada->eliminar_adyacente('hora_estimada');
                    Nodo::eliminar($nodo_hora);
                }
            } else {
                if ($nodo_hora) $nodo_hora->_dato($hora);
                else $nodo_parada->_adyacente_en(Nodo::crear_con_dato($hora), 'hora_estimada');
            }
        } else {
            $nodo_parada = Nodo::crear_con_dato($nombre_parada);
            if ($hora !== '') {
                $nodo_parada->_adyacente_en(Nodo::crear_con_dato($hora), 'hora_estimada');
            }
        }
        _hmi($nodo_paradas, $nodo_parada);
    }

    // 5. Destruir las paradas viejas que NO se reutilizaron.
    //    Las que se reutilizaron conservan su identidad (id()),
    //    que es lo que importa para que los TerminalViaje que
    //    apuntan a ellas sigan funcionando. Las que no se
    //    reutilizaron quedaron fuera de la lista nueva y, si
    //    no se destruyen, quedan huérfanas. Fase 2, v74u.
    foreach ($nodos_existentes as $nombre_viejo => $nodo_viejo) {
        if (!isset($paradas_normalizadas[$nombre_viejo])) {
            _destruir_parada($nodo_viejo);
        }
    }

    return ['exito' => true];
}

/**
 * Agrega un nuevo viaje.
 */
function agregar_viaje(array $datos): array {
    $nombre_dueno = $datos['nombre_dueno'] ?? '';
    $nombre_viaje = $datos['nombre_viaje'] ?? '';
    if (empty($nombre_dueno) || empty($nombre_viaje)) {
        return ['exito' => false, 'error' => 'Dueño y nombre de viaje son obligatorios'];
    }

    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    if ($nodo_viajes->adyacente($nombre_viaje)) {
        return ['exito' => false, 'error' => 'Ya existe un viaje con ese nombre'];
    }

    $nodo_viaje = Nodo::crear_con_dato($nombre_viaje);
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($nombre_dueno), 'dueno');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['nombre'] ?? ''), 'nombre');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['fecha'] ?? ''), 'fecha');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['hora'] ?? ''), 'hora');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['origen'] ?? ''), 'origen');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['destino'] ?? ''), 'destino');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'ocupacion');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'disponibles');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'seleccionados');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'vendidos');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'reservados');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato(''), 'micros');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato(''), 'terminales_autorizadas');

    // Guardar paradas intermedias si las hay
    $paradas = [];
    if (isset($datos['paradas_intermedias'])) {
        if (is_array($datos['paradas_intermedias'])) {
            $paradas = $datos['paradas_intermedias'];
        } elseif (is_string($datos['paradas_intermedias'])) {
            $paradas = json_decode($datos['paradas_intermedias'], true) ?: [];
        }
    }
    if (!empty($paradas)) {
        $resultado_paradas = _guardar_paradas_intermedias($nodo_viaje, $paradas);
        if (!$resultado_paradas['exito']) {
            return $resultado_paradas;
        }
    }

    $nodo_viajes->_adyacente_en($nodo_viaje, $nombre_viaje);
    guardar_ambos(ConfiguracionApli::NOMBRE_APP);
    return ['exito' => true];
}

/**
 * Edita los datos básicos de un viaje.
 */
function editar_viaje(string $nombre_viaje, array $datos): array {
    $nombre_dueno = $datos['nombre_dueno'] ?? '';
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    foreach (['nombre', 'fecha', 'hora', 'origen', 'destino'] as $campo) {
        if (isset($datos[$campo])) {
            $nodo_campo = $nodo_viaje->adyacente($campo);
            if ($nodo_campo) $nodo_campo->_dato($datos[$campo]);
            else $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos[$campo]), $campo);
        }
    }

    // Guardar paradas intermedias si se enviaron
    if (isset($datos['paradas_intermedias'])) {
        $paradas = $datos['paradas_intermedias'];
        if (is_string($paradas)) {
            $paradas = json_decode($paradas, true) ?: [];
        }
        $resultado_paradas = _guardar_paradas_intermedias($nodo_viaje, is_array($paradas) ? $paradas : []);
        if (!$resultado_paradas['exito']) {
            return $resultado_paradas;
        }
    }

    guardar_ambos(ConfiguracionApli::NOMBRE_APP);
    return ['exito' => true];
}

/**
 * Elimina un viaje.
 *
 * A partir de v1.5piloto.74r (Fase 2 del plan de optimización
 * del grafo): destruye el subárbol completo del viaje (micros,
 * copias de vehículo, asientos, TerminalViaje, paradas, DJs,
 * opciones avanzadas) en lugar de dejarlo huérfano. Antes de
 * esta versión solo se desenlazaba el viaje del contenedor
 * del dueño, dejando huérfanos ~250 nodos por micro.
 *
 * No elimina viajes con ventas: eso está chequeado antes.
 *
 * @param string $nombre_viaje
 * @param string $nombre_dueno
 * @return array
 */
function eliminar_viaje(string $nombre_viaje, string $nombre_dueno): array {
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    // Verificar si tiene ventas
    if (viaje_tiene_ventas($nombre_dueno, $nombre_viaje)) {
        return ['exito' => false, 'error' => 'No se pueden eliminar viajes con ventas ya realizadas'];
    }

    // Fase 2: destruir el subárbol completo del viaje.
    // Ver §8.6 del prompt del piloto para el contexto y las
    // reglas de destrucción.
    _destruir_viaje_completo($nodo_viaje);
    $nodo_viajes->eliminar_adyacente($nombre_viaje);
    Nodo::eliminar($nodo_viaje);

    guardar_ambos(ConfiguracionApli::NOMBRE_APP);
    return ['exito' => true];
}

/**
 * Autoriza una terminal (punto de venta) en un viaje.
 *
 * A partir de v1.5piloto.31, cada autorización crea un Nodo TerminalViaje
 * (nodo intermedio, dato vacío) que contiene el enlace `terminal` hacia el
 * Nodo Usuario terminal, y cuelga del contenedor `terminales_autorizadas`
 * con el nombre de la terminal como clave.
 *
 * @param string $nombre_viaje     Identificador del viaje.
 * @param string $nombre_terminal  Nombre de usuario de la terminal.
 * @param string $nombre_dueno     Nombre de usuario del dueño.
 * @return array Resultado.
 */
function agregar_terminal_autorizada(string $nombre_viaje, string $nombre_terminal, string $nombre_dueno): array {
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    // Verificar que exista el Nodo Usuario terminal
    $raiz_usuarios = Nodo::nodo_por_id('usuarios');
    if (!$raiz_usuarios) return ['exito' => false, 'error' => 'No hay usuarios'];

    $nodo_usuario_terminal = $raiz_usuarios->adyacente($nombre_terminal);
    if (!$nodo_usuario_terminal) {
        return ['exito' => false, 'error' => 'La terminal no existe'];
    }

    // Obtener o crear el contenedor
    $nodo_terminales = $nodo_viaje->adyacente('terminales_autorizadas');
    if (!$nodo_terminales) {
        $nodo_terminales = Nodo::crear_con_dato('');
        $nodo_viaje->_adyacente_en($nodo_terminales, 'terminales_autorizadas');
    }

    if ($nodo_terminales->adyacente($nombre_terminal)) {
        return ['exito' => false, 'error' => 'La terminal ya está autorizada'];
    }

    // Crear nodo intermedio TerminalViaje
    $nodo_terminal_viaje = Nodo::crear_con_dato('');
    $nodo_terminal_viaje->_adyacente_en($nodo_usuario_terminal, 'terminal');
    $nodo_terminal_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'cambiar_punto_predeterminado');

    $nodo_terminales->_adyacente_en($nodo_terminal_viaje, $nombre_terminal);

    guardar_ambos(ConfiguracionApli::NOMBRE_APP);
    return ['exito' => true];
}

/**
 * Quita una terminal autorizada de un viaje.
 *
 * A partir de v1.5piloto.74u (Fase 2 del plan de optimización
 * del grafo): destruye el TerminalViaje completo (con sus
 * campos: terminal, cambiar_punto_predeterminado, overrides
 * de pago) en lugar de dejarlo huérfano. Reutiliza
 * `_destruir_terminal_viaje` de Viaje.php (v74r).
 *
 * @param string $nombre_viaje     Identificador del viaje.
 * @param string $nombre_terminal  Nombre de usuario de la terminal.
 * @param string $nombre_dueno     Nombre de usuario del dueño.
 * @return array Resultado.
 */
function eliminar_terminal_autorizada(string $nombre_viaje, string $nombre_terminal, string $nombre_dueno): array {
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    $nodo_terminales = $nodo_viaje->adyacente('terminales_autorizadas');
    if (!$nodo_terminales) return ['exito' => false, 'error' => 'No hay terminales'];

    $nodo_terminal_viaje = $nodo_terminales->adyacente($nombre_terminal);
    if (!$nodo_terminal_viaje) {
        return ['exito' => false, 'error' => 'La terminal no está autorizada'];
    }

    // Fase 2: desenlazar del contenedor y destruir el TerminalViaje
    // completo. _destruir_terminal_viaje se encarga de desenlazar
    // `terminal` (referencia externa) y `punto_subida_bajada`
    // (referencia a un nodo parada del viaje, que sigue vivo).
    $nodo_terminales->eliminar_adyacente($nombre_terminal);
    _destruir_terminal_viaje($nodo_terminal_viaje);

    guardar_ambos(ConfiguracionApli::NOMBRE_APP);
    return ['exito' => true];
}

/**
 * Obtiene las opciones configuradas para la combinación viaje + terminal.
 *
 * A partir de v1.5piloto.31 incluye las opciones de punto de subida/bajada.
 * A partir de v1.5piloto.32 incluye las condiciones de pago (override).
 *
 * Los campos de condiciones de pago devuelven cadena vacía si no están
 * configurados en el nodo intermedio, para distinguir "sin override" de
 * "override en 0". El frontend usa esa cadena vacía para saber que debe
 * usar la configuración del viaje.
 *
 * @param string $nombre_dueno     Nombre de usuario del dueño.
 * @param string $nombre_viaje     Identificador del viaje.
 * @param string $nombre_terminal  Nombre de usuario de la terminal.
 * @return array
 */
function obtener_opciones_terminal_viaje(string $nombre_dueno, string $nombre_viaje, string $nombre_terminal): array {
    $defaults = [
        'cambiar_punto_predeterminado' => '0',
        'punto_subida_bajada' => '',
        // Condiciones de pago: vacío = sin override (usar config del viaje)
        'permite_efectivo' => '',
        'cuotas_efectivo_max' => '',
        'permite_transferencia' => '',
        'cuotas_transferencia_max' => '',
    ];

    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return $defaults;

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return $defaults;

    $nodo_terminales = $nodo_viaje->adyacente('terminales_autorizadas');
    if (!$nodo_terminales) return $defaults;

    $nodo_terminal_viaje = $nodo_terminales->adyacente($nombre_terminal);
    if (!$nodo_terminal_viaje) return $defaults;

    $opciones = $defaults;

    $nodo_cambiar = $nodo_terminal_viaje->adyacente('cambiar_punto_predeterminado');
    if ($nodo_cambiar) $opciones['cambiar_punto_predeterminado'] = $nodo_cambiar->dato();

    $nodo_punto = $nodo_terminal_viaje->adyacente('punto_subida_bajada');
    if ($nodo_punto) $opciones['punto_subida_bajada'] = $nodo_punto->dato();

    $campos_pago = [
        'permite_efectivo',
        'cuotas_efectivo_max',
        'permite_transferencia',
        'cuotas_transferencia_max',
    ];
    foreach ($campos_pago as $campo) {
        $nodo_campo = $nodo_terminal_viaje->adyacente($campo);
        if ($nodo_campo) $opciones[$campo] = $nodo_campo->dato();
    }

    return $opciones;
}

/**
 * Guarda las opciones configuradas para la combinación viaje + terminal.
 *
 * A partir de v1.5piloto.32 acepta los 4 campos de condiciones de pago.
 * La convención es:
 * - Si `permite_efectivo`, `permite_transferencia`, `cuotas_efectivo_max` y
 *   `cuotas_transferencia_max` vienen todos vacíos, se eliminan los 4 enlaces
 *   del nodo intermedio (sin override).
 * - Si vienen con valor, se escriben los 4 en el nodo intermedio.
 *
 * Se permite que el terminal deshabilite un método con `permite_X = "0"`.
 * No se permite deshabilitar ambos: en ese caso se devuelve error.
 *
 * @param string $nombre_dueno     Nombre de usuario del dueño.
 * @param string $nombre_viaje     Identificador del viaje.
 * @param string $nombre_terminal  Nombre de usuario de la terminal.
 * @param array  $opciones         Datos a guardar.
 * @return array Resultado.
 */
function guardar_opciones_terminal_viaje(string $nombre_dueno, string $nombre_viaje, string $nombre_terminal, array $opciones, bool $aplicar_retroactivo = false): array {
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    $nodo_terminales = $nodo_viaje->adyacente('terminales_autorizadas');
    if (!$nodo_terminales) return ['exito' => false, 'error' => 'El viaje no tiene terminales autorizadas'];

    $nodo_terminal_viaje = $nodo_terminales->adyacente($nombre_terminal);
    if (!$nodo_terminal_viaje) {
        return ['exito' => false, 'error' => 'La terminal no está autorizada en este viaje'];
    }

    // Snapshot de la config de cobro de las ventas de esta terminal,
    // antes de tocar el override.
    $snapshot_ventas = _snapshot_config_ventas_de_terminal($nombre_dueno, $nombre_viaje, $nombre_terminal);
    $config_antes = _config_pago_resuelta_para_viaje_terminal($nombre_dueno, $nombre_viaje, $nombre_terminal);

    // === Punto de subida/bajada ===
    $cambiar = ($opciones['cambiar_punto_predeterminado'] ?? '0') === '1' ? '1' : '0';
    $punto = trim((string)($opciones['punto_subida_bajada'] ?? ''));

    $nodo_cambiar = $nodo_terminal_viaje->adyacente('cambiar_punto_predeterminado');
    if ($nodo_cambiar) $nodo_cambiar->_dato($cambiar);
    else $nodo_terminal_viaje->_adyacente_en(Nodo::crear_con_dato($cambiar), 'cambiar_punto_predeterminado');

    if ($cambiar === '1' && $punto !== '') {
        // Buscar el nodo parada existente
        $nodo_parada_encontrado = null;
        $nodo_paradas = $nodo_viaje->adyacente('paradas_intermedias');
        if ($nodo_paradas) {
            $actual = hmi($nodo_paradas);
            $seg = 0;
            while ($actual && $seg < 100) {
                if ($actual->dato() === $punto) {
                    $nodo_parada_encontrado = $actual;
                    break;
                }
                $actual = hd($actual);
                $seg++;
            }
        }
        if (!$nodo_parada_encontrado) {
            return ['exito' => false, 'error' => 'La parada seleccionada no existe en el viaje'];
        }
        $nodo_punto = $nodo_terminal_viaje->adyacente('punto_subida_bajada');
        if ($nodo_punto) {
            $nodo_terminal_viaje->_adyacente_en($nodo_parada_encontrado, 'punto_subida_bajada', true);
        } else {
            $nodo_terminal_viaje->_adyacente_en($nodo_parada_encontrado, 'punto_subida_bajada');
        }
    } else {
        $nodo_terminal_viaje->eliminar_adyacente('punto_subida_bajada');
    }

    // === Condiciones de pago (override) ===
    $campos_pago = ['permite_efectivo', 'cuotas_efectivo_max', 'permite_transferencia', 'cuotas_transferencia_max'];
    $todos_vacios = true;
    foreach ($campos_pago as $campo) {
        if (isset($opciones[$campo]) && trim((string)$opciones[$campo]) !== '') {
            $todos_vacios = false;
            break;
        }
    }

    if ($todos_vacios) {
        // Sin override: eliminar los 4 enlaces si existían
        foreach ($campos_pago as $campo) {
            $nodo_terminal_viaje->eliminar_adyacente($campo);
        }
    } else {
        // Hay override. Sanitizar y validar.
        $permite_efectivo = ($opciones['permite_efectivo'] ?? '1') === '1' ? '1' : '0';
        $permite_transferencia = ($opciones['permite_transferencia'] ?? '1') === '1' ? '1' : '0';

        if ($permite_efectivo === '0' && $permite_transferencia === '0') {
            return ['exito' => false, 'error' => 'Debe permitirse al menos un método de pago'];
        }

        $cuotas_efectivo_max = _clipear_cuotas($opciones['cuotas_efectivo_max'] ?? '3');
        $cuotas_transferencia_max = _clipear_cuotas($opciones['cuotas_transferencia_max'] ?? '1');

        _actualizar_o_crear_campo($nodo_terminal_viaje, 'permite_efectivo', $permite_efectivo);
        _actualizar_o_crear_campo($nodo_terminal_viaje, 'cuotas_efectivo_max', $cuotas_efectivo_max);
        _actualizar_o_crear_campo($nodo_terminal_viaje, 'permite_transferencia', $permite_transferencia);
        _actualizar_o_crear_campo($nodo_terminal_viaje, 'cuotas_transferencia_max', $cuotas_transferencia_max);
    }

    // A partir de v74: si la config efectiva de pago de las ventas
    // de esta terminal cambió en algún permite_*, migrar las ventas
    // viejas y (si el flag está activo) aplicar retroactivo a las
    // que ya tienen opciones_cobro.
    $config_despues = _config_pago_resuelta_para_viaje_terminal($nombre_dueno, $nombre_viaje, $nombre_terminal);
    $cambio_permite_terminal = ($config_antes['permite_efectivo'] !== $config_despues['permite_efectivo']
        || $config_antes['permite_transferencia'] !== $config_despues['permite_transferencia']);
    if ($cambio_permite_terminal) {
        _aplicar_retroactivo_a_ventas_de_terminal($nombre_dueno, $nombre_viaje, $nombre_terminal, $snapshot_ventas, $aplicar_retroactivo);
    }

    guardar_ambos(ConfiguracionApli::NOMBRE_APP);
    return ['exito' => true];
}
/**
 * Guarda un viaje (alta o edición) junto con sus opciones avanzadas.
 */
function guardar_viaje_completo(array $datos): array {
    $nombre_dueno = $datos['nombre_dueno'] ?? '';
    $nombre_viaje = $datos['nombre_viaje'] ?? '';
    if (empty($nombre_dueno) || empty($nombre_viaje)) {
        return ['exito' => false, 'error' => 'Dueño y nombre de viaje son obligatorios'];
    }

    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    $es_alta = !$nodo_viajes->adyacente($nombre_viaje);
    if ($es_alta) {
        // Crear viaje nuevo
        $nodo_viaje = Nodo::crear_con_dato($nombre_viaje);
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($nombre_dueno), 'dueno');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['nombre'] ?? ''), 'nombre');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['fecha'] ?? ''), 'fecha');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['hora'] ?? ''), 'hora');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['origen'] ?? ''), 'origen');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['destino'] ?? ''), 'destino');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'ocupacion');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'disponibles');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'seleccionados');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'vendidos');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'reservados');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato(''), 'micros');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato(''), 'terminales_autorizadas');
        $nodo_viajes->_adyacente_en($nodo_viaje, $nombre_viaje);
    } else {
        // Editar viaje existente
        $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
        foreach (['nombre', 'fecha', 'hora', 'origen', 'destino'] as $campo) {
            if (isset($datos[$campo])) {
                $nodo_campo = $nodo_viaje->adyacente($campo);
                if ($nodo_campo) $nodo_campo->_dato($datos[$campo]);
                else $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos[$campo]), $campo);
            }
        }
    }

    // Guardar paradas intermedias
    $paradas = [];
    if (isset($datos['paradas_intermedias'])) {
        if (is_array($datos['paradas_intermedias'])) {
            $paradas = $datos['paradas_intermedias'];
        } elseif (is_string($datos['paradas_intermedias'])) {
            $paradas = json_decode($datos['paradas_intermedias'], true) ?: [];
        }
    }
    $resultado_paradas = _guardar_paradas_intermedias($nodo_viaje, $paradas);
    if (!$resultado_paradas['exito']) {
        return $resultado_paradas;
    }

    // Guardar opciones avanzadas y condiciones de pago
    $opciones = [
        'restriccion_edad' => $datos['restriccion_edad'] ?? '0',
        'edad_minima' => $datos['edad_minima'] ?? '18',
        'edad_maxima' => $datos['edad_maxima'] ?? '80',
        'permite_efectivo' => $datos['permite_efectivo'] ?? '1',
        'cuotas_efectivo_max' => $datos['cuotas_efectivo_max'] ?? '3',
        'permite_transferencia' => $datos['permite_transferencia'] ?? '1',
        'cuotas_transferencia_max' => $datos['cuotas_transferencia_max'] ?? '1',
        'mostrar_dj_en_terminales' => $datos['mostrar_dj_en_terminales'] ?? '0',
    ];
    $aplicar_retroactivo = (($datos['aplicar_retroactivo'] ?? '') === '1');
    $resultado_opciones = guardar_opciones_avanzadas_viaje($nombre_dueno, $nombre_viaje, $opciones, $aplicar_retroactivo);
    if (!$resultado_opciones['exito']) {
        return $resultado_opciones;
    }

    guardar_ambos(ConfiguracionApli::NOMBRE_APP);
    return ['exito' => true];
}

/**
 * Sustituye los placeholders {{NOMBRE_VIAJE}} y {{FECHA_VIAJE}} en
 * un texto de declaración jurada por los datos reales del viaje.
 *
 * Si el viaje no tiene fecha definida (vacía o "a confirmar"), el
 * placeholder de la fecha se reemplaza por una racha de puntos para
 * completar a mano.
 *
 * @param string $contenido
 * @param Nodo   $nodo_viaje
 * @return string
 */
function _sustituir_placeholders_dj(string $contenido, Nodo $nodo_viaje): string {
    $nombre_visible = $nodo_viaje->adyacente('nombre')
        ? $nodo_viaje->adyacente('nombre')->dato()
        : $nodo_viaje->dato();

    $destino = $nodo_viaje->adyacente('destino')
        ? trim($nodo_viaje->adyacente('destino')->dato())
        : '';
    if ($destino === '') {
        $destino = '............................................................................................................................';
    }

    $fecha_iso = $nodo_viaje->adyacente('fecha')
        ? trim($nodo_viaje->adyacente('fecha')->dato())
        : '';

    if ($fecha_iso === '' || $fecha_iso === 'a confirmar') {
        $fecha_mostrar = '............................................................................................................................';
    } else {
        $fecha_mostrar = formatear_fecha_visible($fecha_iso);
    }

    return str_replace(
        ['{{NOMBRE_VIAJE}}', '{{DESTINO_VIAJE}}', '{{FECHA_VIAJE}}'],
        [$nombre_visible, $destino, $fecha_mostrar],
        $contenido
    );
}

/**
 * Devuelve el HTML de una declaración jurada del viaje. Si el nodo no
 * existe todavía, o si se pasa $forzar_default = true, devuelve el
 * texto por defecto con los placeholders ya sustituidos por los datos
 * del viaje (nombre visible y fecha), y lo marca con es_default = true.
 *
 * @param string $nombre_dueno
 * @param string $nombre_viaje
 * @param string $tipo  "mayor" o "menor"
 * @param bool   $forzar_default  Si es true, devuelve siempre el default
 *                                aunque exista un nodo guardado.
 * @return array
 */
function obtener_declaracion_jurada(string $nombre_dueno, string $nombre_viaje, string $tipo, bool $forzar_default = false): array {
    $tipo = ($tipo === 'menor') ? 'menor' : 'mayor';
    $enlace = 'declaracion_jurada_' . $tipo;

    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];
    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    if (!$forzar_default) {
        $nodo_dj = $nodo_viaje->adyacente($enlace);
        if ($nodo_dj) {
            return [
                'exito' => true,
                'contenido' => $nodo_dj->dato(),
                'es_default' => false,
            ];
        }
    }

    $default = ($tipo === 'mayor') ? TEXTO_DJ_MAYOR_DEFAULT : TEXTO_DJ_MENOR_DEFAULT;
    $default = _sustituir_placeholders_dj($default, $nodo_viaje);

    return [
        'exito' => true,
        'contenido' => $default,
        'es_default' => true,
    ];
}

/**
 * Guarda el HTML de una declaración jurada del viaje. Crea el nodo si
 * no existe, o lo actualiza si ya existe.
 *
 * @param string $nombre_dueno
 * @param string $nombre_viaje
 * @param string $tipo  "mayor" o "menor"
 * @param string $contenido
 * @return array
 */
function guardar_declaracion_jurada(string $nombre_dueno, string $nombre_viaje, string $tipo, string $contenido): array {
    $tipo = ($tipo === 'menor') ? 'menor' : 'mayor';
    $enlace = 'declaracion_jurada_' . $tipo;

    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];
    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    $nodo_dj = $nodo_viaje->adyacente($enlace);
    if ($nodo_dj) {
        $nodo_dj->_dato($contenido);
    } else {
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($contenido), $enlace);
    }

    guardar_ambos(ConfiguracionApli::NOMBRE_APP);
    return ['exito' => true];
}

/**
 * Elimina los viajes "de prueba" de un dueño.
 *
 * Conserva el viaje principal (por nombre visible:
 * "Peregrinación a la Visita del Papa León XIV a Luján")
 * y cualquier viaje que no tenga un prefijo conocido de
 * prueba en su identificador (viajeprueba, viajemicro,
 * viajeval, viajedup, viajecol, viajesin).
 *
 * No elimina viajes con ventas registradas.
 *
 * Pensado para el botón de limpieza del admin. Se usa
 * cuando las pruebas automáticas acumulan viajes que
 * ralentizan los listados.
 *
 * @param string $nombre_dueno
 * @return array
 */
function limpiar_viajes_de_prueba(string $nombre_dueno): array {
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) {
        return ['exito' => false, 'error' => 'Dueño no encontrado o sin viajes'];
    }

    $prefijos = ['viajeprueba', 'viajemicro', 'viajeval', 'viajedup', 'viajecol', 'viajesin'];
    $nombre_principal = 'Peregrinación a la Visita del Papa León XIV a Luján';

    $adyacentes = (array) $nodo_viajes->adyacentes();
    $borrados = [];
    $conservados = [];
    $con_ventas = [];

    foreach ($adyacentes as $nombre_viaje => $nodo_viaje) {
        $nombre_viaje = (string)$nombre_viaje;

        // Conservar el viaje principal (por nombre visible).
        $nombre_visible = $nodo_viaje->adyacente('nombre')
            ? $nodo_viaje->adyacente('nombre')->dato()
            : '';
        if ($nombre_visible === $nombre_principal) {
            $conservados[] = $nombre_viaje;
            continue;
        }

        // Conservar cualquier viaje que no tenga prefijo de prueba.
        $es_de_prueba = false;
        foreach ($prefijos as $p) {
            if (strpos($nombre_viaje, $p) === 0) {
                $es_de_prueba = true;
                break;
            }
        }
        if (!$es_de_prueba) {
            $conservados[] = $nombre_viaje;
            continue;
        }

        // No eliminar si tiene ventas registradas.
        if (viaje_tiene_ventas($nombre_dueno, $nombre_viaje)) {
            $con_ventas[] = $nombre_viaje;
            continue;
        }

        // Fase 2, v74z: destruir el subárbol completo del viaje
        // antes de desenlazarlo. Antes solo se desenlazaba,
        // dejando el mismo subárbol huérfano que eliminar_viaje
        // antes de v74r (~250 nodos por micro arrastrado).
        _destruir_viaje_completo($nodo_viaje);
        $nodo_viajes->eliminar_adyacente($nombre_viaje);
        Nodo::eliminar($nodo_viaje);
        $borrados[] = $nombre_viaje;
    }

    guardar_ambos(ConfiguracionApli::NOMBRE_APP);

    return [
        'exito' => true,
        'borrados' => $borrados,
        'cantidad_borrados' => count($borrados),
        'conservados' => $conservados,
        'con_ventas' => $con_ventas,
    ];
}

// ============================================================
// Destrucción progresiva del subárbol de un viaje
//
// Fase 2 del plan de optimización del grafo (§8.6 del prompt
// del piloto). El framework no recolecta nodos huérfanos: si
// se desenlaza un nodo sin destruirlo, queda ocupando memoria
// y disco. Estos helpers destruyen el subárbol completo de un
// viaje respetando las referencias externas (empresa, terminal).
//
// Reglas:
//  - Todo nodo "campo" (dato string sin adyacentes propios) se
//    destruye al destruir su padre.
//  - Toda referencia a un nodo externo (empresa, terminal) se
//    desenlaza pero NO se destruye.
//  - Toda referencia circular interna se desenlaza; los nodos
//    destino los destruye quien corresponda.
//  - El orden de destrucción va de hojas a raíz, para que
//    Nodo::eliminar no falle por referencias entrantes.
// ============================================================

/**
 * Destruye un micro: copia de vehículo, campos, y desenlaza
 * las referencias externas (empresa) y circulares (viaje).
 *
 * Debe llamarse después de desenlazar el micro del contenedor
 * `micros` del viaje, para que Nodo::eliminar no falle.
 *
 * @param Nodo $nodo_micro
 */
function _destruir_micro(Nodo $nodo_micro): void {
    $nodo_copia = $nodo_micro->adyacente('vehiculo_copia');
    if ($nodo_copia) {
        // Desenlazar PRIMERO: el micro apunta a la copia. Si no
        // se desenlaza antes de destruir la copia, la copia
        // tiene una referencia entrante y Nodo::eliminar falla.
        $nodo_micro->eliminar_adyacente('vehiculo_copia');
        _destruir_vehiculo_completo($nodo_copia);
    }
    // Desenlazar referencias externas/circulares antes de destruir.
    $nodo_micro->eliminar_adyacente('empresa');
    $nodo_micro->eliminar_adyacente('viaje');
    _destruir_campos_simples($nodo_micro);
    Nodo::eliminar($nodo_micro);
}

/**
 * Destruye un TerminalViaje: desenlaza las referencias a
 * terminal y a parada, y destruye sus campos override.
 *
 * @param Nodo $nodo_tv
 */
function _destruir_terminal_viaje(Nodo $nodo_tv): void {
    $nodo_tv->eliminar_adyacente('terminal');
    $nodo_tv->eliminar_adyacente('punto_subida_bajada');
    _destruir_campos_simples($nodo_tv);
    Nodo::eliminar($nodo_tv);
}

/**
 * Destruye una parada intermedia.
 *
 * @param Nodo $nodo_parada
 */
function _destruir_parada(Nodo $nodo_parada): void {
    _destruir_campos_simples($nodo_parada);
    Nodo::eliminar($nodo_parada);
}

/**
 * Destruye el subárbol completo de un viaje.
 *
 * Orden: micros (uno por uno, después el contenedor),
 * TerminalViaje (uno por uno, después el contenedor),
 * paradas (una por una, después el contenedor), DJs,
 * opciones avanzadas, y al final los campos simples del
 * propio viaje.
 *
 * NO destruye el nodo viaje en sí: de eso se encarga
 * eliminar_viaje, después de desenlazarlo del contenedor
 * del dueño.
 *
 * @param Nodo $nodo_viaje
 */
function _destruir_viaje_completo(Nodo $nodo_viaje): void {
    // 1. Micros. Primero desenlazar del contenedor, después
    //    destruir el micro (que ya no tiene entrantes).
    $nodo_micros = $nodo_viaje->adyacente('micros');
    if ($nodo_micros) {
        $adyacentes_micros = (array) $nodo_micros->adyacentes();
        foreach ($adyacentes_micros as $nombre_micro => $nodo_micro) {
            $nodo_micros->eliminar_adyacente((string)$nombre_micro);
            _destruir_micro($nodo_micro);
        }
        _destruir_campos_simples($nodo_micros);
        $nodo_viaje->eliminar_adyacente('micros');
        Nodo::eliminar($nodo_micros);
    }

    // 2. Terminales autorizadas (TerminalViaje).
    $nodo_terminales = $nodo_viaje->adyacente('terminales_autorizadas');
    if ($nodo_terminales) {
        $adyacentes_tv = (array) $nodo_terminales->adyacentes();
        foreach ($adyacentes_tv as $nombre_terminal => $nodo_tv) {
            $nodo_terminales->eliminar_adyacente((string)$nombre_terminal);
            _destruir_terminal_viaje($nodo_tv);
        }
        _destruir_campos_simples($nodo_terminales);
        $nodo_viaje->eliminar_adyacente('terminales_autorizadas');
        Nodo::eliminar($nodo_terminales);
    }

    // 3. Paradas intermedias (lista árbol hmi/hd/p).
    $nodo_paradas = $nodo_viaje->adyacente('paradas_intermedias');
    if ($nodo_paradas) {
        while ($parada = eliminar_hmi($nodo_paradas)) {
            _destruir_parada($parada);
        }
        _destruir_campos_simples($nodo_paradas);
        $nodo_viaje->eliminar_adyacente('paradas_intermedias');
        Nodo::eliminar($nodo_paradas);
    }

    // 4. Declaraciones juradas (nodos hoja con dato HTML).
    foreach (['declaracion_jurada_mayor', 'declaracion_jurada_menor'] as $enlace_dj) {
        $nodo_dj = $nodo_viaje->adyacente($enlace_dj);
        if ($nodo_dj) {
            _destruir_campos_simples($nodo_dj);
            $nodo_viaje->eliminar_adyacente($enlace_dj);
            Nodo::eliminar($nodo_dj);
        }
    }

    // 5. Opciones avanzadas (contenedor de campos string).
    $nodo_opciones = $nodo_viaje->adyacente('opciones_avanzadas');
    if ($nodo_opciones) {
        _destruir_campos_simples($nodo_opciones);
        $nodo_viaje->eliminar_adyacente('opciones_avanzadas');
        Nodo::eliminar($nodo_opciones);
    }

    // 6. Campos simples del propio viaje (nombre, fecha, hora,
    //    origen, destino, dueno, contadores).
    _destruir_campos_simples($nodo_viaje);
}

// Incluir submódulos de viajes
require_once __DIR__ . '/ViajeMicros.php';
require_once __DIR__ . '/ViajeAsientos.php';
require_once __DIR__ . '/ViajeOpciones.php';
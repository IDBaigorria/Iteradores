<?php
/**
 * Núcleo de gestión de viajes.
 *
 * @package   Iteradores
 * @since     1.5piloto.8
 * @version   1.5piloto.70
 */

use Iteradores\Nodos\Nodo;
use Iteradores\Controlador\Controlador;
use Iteradores\Configuracion\Conf;
include_once("./Configuracion/Configuracion.php");
include_once("./Nodos/Nodo.php");
include_once("./Controlador/Controlador.php");
include_once("./miscelaneas/Arbol.php");

/**
 * Texto por defecto de la declaración jurada del pasajero mayor de 18 años
 * (Anexo I). Se usa cuando el viaje todavía no tiene una declaración guardada.
 */
const TEXTO_DJ_MAYOR_DEFAULT = <<<'HTML'
ANEXO I
DECLARACIÓN JURADA DEL PASAJERO MAYOR DE 18 AÑOS

VIAJE TURÍSTICO / RELIGIOSO

Quien suscribe, ..........................................................................................................................

DNI ..........................................................., domiciliado/a en ....................................................................................................................,

localidad de ...................................................................................................................., participará del viaje turístico/religioso denominado

{{NOMBRE_VIAJE}}

a realizarse en {{DESTINO_VIAJE}},

el/los día/días {{FECHA_VIAJE}}

Declaro que he sido informado/a de las características del viaje, las actividades previstas, el medio de transporte, los lugares de alojamiento y demás servicios comprendidos.

Asimismo, dejo constancia de cualquier información de salud, indicación o circunstancia que considere necesario comunicar a los responsables del viaje:

....................................................................................................................................................................................

....................................................................................................................................................................................

....................................................................................................................................................................................

Obra Social / Prepaga: ............................................................................................................

N.º de afiliado: ........................................................................................................................

Teléfonos de contacto en caso de urgencia:

........................................................................................................................................................

........................................................................................................................................................

DATOS DE SALUD

Autorizo que la información de salud proporcionada en este formulario pueda ser registrada y digitalizada exclusivamente para facilitar la organización y asistencia durante el viaje.

Dicha información tendrá acceso limitado a las personas responsables que necesiten conocerla y podrá ser comunicada a profesionales o servicios de salud cuando resulte necesario ante una situación de asistencia.

La información será conservada durante el tiempo necesario para dichas finalidades y conforme a la normativa aplicable.

CONSENTIMIENTO PARA EL TRATAMIENTO DE DATOS DE SALUD

De conformidad con lo dispuesto por el artículo 7 de la Ley 25.326 de Protección de Datos Personales, presto mi consentimiento expreso y por escrito para el tratamiento de los datos de salud consignados en este formulario.

☐ SÍ, PRESTÓ MI CONSENTIMIENTO al tratamiento de mis datos de salud en los términos del artículo 7 de la Ley 25.326.
   (tildar o marcar con una X)

Asimismo, autorizo, en caso de necesidad y urgencia, a que se solicite asistencia médica y se adopten las indicaciones que los profesionales de la salud consideren necesarias, en los términos del artículo 9 de la Ley 26.529 de Derechos del Paciente, procurando que se me informe de ello a la brevedad posible.

Declaro que los datos consignados son verdaderos y que comunicaré cualquier circunstancia que considere relevante para mi seguridad o asistencia durante el viaje.

<br>

Firma: ..............................................................................................................

Aclaración: ........................................................................................................

DNI: ...................................................................................................................

Fecha: ....../....../............

El titular de los datos puede ejercer los derechos de acceso, rectificación, supresión y oposición previstos en la Ley 25.326 contactando al organizador del viaje.
HTML;

/**
 * Texto por defecto de la declaración jurada del pasajero menor de 18 años
 * (Anexo II). Se usa cuando el viaje todavía no tiene una declaración guardada.
 */
const TEXTO_DJ_MENOR_DEFAULT = <<<'HTML'
ANEXO II
AUTORIZACIÓN Y DECLARACIÓN DEL PASAJERO MENOR DE 18 AÑOS

VIAJE TURÍSTICO / RELIGIOSO

Por la presente, quien suscribe ....................................................................................................................,

DNI ..........................................................., en carácter de:

☐ Padre  ☐ Madre  ☐ Tutor/a  ☐ Responsable
   (tildar o marcar con una X)

autorizo al/la menor ....................................................................................................................,

DNI ..........................................................., a participar del viaje turístico/religioso denominado

{{NOMBRE_VIAJE}}

a realizarse en {{DESTINO_VIAJE}},

el/los día/días {{FECHA_VIAJE}}

Declaro haber sido informado/a de las características del viaje, las actividades previstas, el medio de transporte, los lugares de alojamiento y demás servicios comprendidos.

SALUD

Dejo constancia de cualquier información de salud, indicación o circunstancia que considere necesario que conozcan los responsables del viaje:

....................................................................................................................................................................................

....................................................................................................................................................................................

....................................................................................................................................................................................

Obra Social / Prepaga: ............................................................................................................

N.º de afiliado: ........................................................................................................................

Teléfonos de contacto en caso de urgencia:

........................................................................................................................................................

........................................................................................................................................................

Autorizo que la información de salud proporcionada en este formulario pueda ser registrada y digitalizada exclusivamente para facilitar la organización y asistencia del menor durante el viaje.

Dicha información tendrá acceso limitado a las personas responsables que necesiten conocerla y podrá ser comunicada a profesionales o servicios de salud cuando resulte necesario ante una situación de asistencia.

La información será conservada durante el tiempo necesario para dichas finalidades y conforme a la normativa aplicable.

CONSENTIMIENTO PARA EL TRATAMIENTO DE DATOS DE SALUD DEL MENOR

De conformidad con lo dispuesto por el artículo 7 de la Ley 25.326 de Protección de Datos Personales, en mi carácter de padre, madre, tutor/a o responsable legal del menor, presto consentimiento expreso y por escrito para el tratamiento de los datos de salud del menor consignados en este formulario.

☐ SÍ, PRESTÓ MI CONSENTIMIENTO al tratamiento de los datos de salud del menor en los términos del artículo 7 de la Ley 25.326.
   (tildar o marcar con una X)

Asimismo, autorizo, en caso de necesidad y urgencia, a que se solicite asistencia médica para el/la menor y se adopten las indicaciones que los profesionales de la salud consideren necesarias, en los términos del artículo 9 de la Ley 26.529 de Derechos del Paciente, procurando que se me informe de ello a la brevedad posible.

Declaro que los datos consignados son verdaderos y que informaré cualquier circunstancia que considere relevante para la seguridad o asistencia del/la menor durante el viaje.

<br>

Firma del padre, madre, tutor/a o responsable:
....................................................................................................................

Aclaración: ........................................................................................................

DNI: ...................................................................................................................

Teléfono: ............................................................................................................

Fecha: ....../....../............

El titular de los datos (o su representante legal) puede ejercer los derechos de acceso, rectificación, supresión y oposición previstos en la Ley 25.326 contactando al organizador del viaje.
HTML;

/**
 * Obtiene el contenedor de viajes de un dueño, creándolo si no existe.
 */
function obtener_contenedor_viajes_dueno(string $nombre_dueno) {
    $raiz_usuarios = Nodo::nodo_por_id('usuarios');
    if (!$raiz_usuarios) return null;

    $nodo_dueno = $raiz_usuarios->adyacente($nombre_dueno);
    if (!$nodo_dueno) return null;

    $nodo_viajes = $nodo_dueno->adyacente('viajes');
    if (!$nodo_viajes) {
        $nodo_viajes = Nodo::crear_con_dato('');
        $nodo_dueno->_adyacente_en($nodo_viajes, 'viajes');
    }
    return $nodo_viajes;
}

/**
 * Lista viajes de un dueño.
 */
function listar_viajes_de_dueno(string $nombre_dueno): array {
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return [];

    $adyacentes = (array) $nodo_viajes->adyacentes();
    if (!$adyacentes) return [];

    $viajes = [];
    foreach ($adyacentes as $nombre_viaje => $nodo_viaje) {
        $viajes[] = formatear_viaje($nombre_viaje, $nodo_viaje);
    }
    return $viajes;
}

/**
 * Lista viajes autorizados para una terminal.
 */
function listar_viajes_de_terminal(string $nombre_terminal): array {
    $raiz_usuarios = Nodo::nodo_por_id('usuarios');
    if (!$raiz_usuarios) return [];

    $nodo_terminal = $raiz_usuarios->adyacente($nombre_terminal);
    if (!$nodo_terminal) return [];

    $nodo_dueno = $nodo_terminal->adyacente('dueno');
    if (!$nodo_dueno) return [];

    $nombre_dueno = $nodo_dueno->dato();
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return [];

    $viajes_autorizados = [];
    $adyacentes = (array) $nodo_viajes->adyacentes();
    foreach ($adyacentes as $nombre_viaje => $nodo_viaje) {
        $viaje = formatear_viaje($nombre_viaje, $nodo_viaje, $nombre_terminal); 
        if (in_array($nombre_terminal, $viaje['terminales_autorizadas'])) {
            $viajes_autorizados[] = $viaje;
        }
    }
    return $viajes_autorizados;
}

/**
 * Formatea los datos de un viaje, incluyendo micros, terminales y opciones.
 * Si se pasa $nombre_terminal, se calcula 'vendidos_aqui' por micro para esa terminal.
 *
 * El campo 'reservados' del viaje se calcula siempre sumando los reservados
 * de cada micro, para no depender de que el nodo persistido del viaje esté
 * actualizado (viajes creados antes de la v1.5piloto.27 pueden tener el nodo
 * 'reservados' en "0" o inexistente).
 */
function formatear_viaje(string $nombre_viaje, $nodo_viaje, ?string $nombre_terminal = null): array {
    $datos = [];
    $datos['nombre_viaje'] = $nombre_viaje;
    $datos['dueno'] = $nodo_viaje->adyacente('dueno') ? $nodo_viaje->adyacente('dueno')->dato() : '';
    $datos['nombre'] = $nodo_viaje->adyacente('nombre') ? $nodo_viaje->adyacente('nombre')->dato() : '';
    $datos['fecha'] = $nodo_viaje->adyacente('fecha') ? $nodo_viaje->adyacente('fecha')->dato() : '';
    $datos['fecha_visible'] = formatear_fecha_visible($datos['fecha']);
    $datos['hora'] = $nodo_viaje->adyacente('hora') ? $nodo_viaje->adyacente('hora')->dato() : '';
    $datos['origen'] = $nodo_viaje->adyacente('origen') ? $nodo_viaje->adyacente('origen')->dato() : '';
    $datos['destino'] = $nodo_viaje->adyacente('destino') ? $nodo_viaje->adyacente('destino')->dato() : '';
    // Los contadores se calculan al final del loop de micros, sumando los de cada micro.
    // Así no dependemos de que los nodos del viaje estén al día: cualquier
    // desfase entre el nodo del viaje y el estado real de los micros se
    // evita calculándolos siempre al vuelo.
    $datos['ocupacion'] = '0';
    $datos['disponibles'] = '0';
    $datos['seleccionados'] = '0';
    $datos['vendidos'] = '0';
    $datos['reservados'] = '0';

    // Paradas intermedias (lista tipo árbol hmi/hd).
    // A partir de v1.5piloto.34 cada parada se devuelve como objeto
    // {nombre, hora_estimada}. La hora estimada es opcional.
    $paradas = [];
    $nodo_paradas = $nodo_viaje->adyacente('paradas_intermedias');
    if ($nodo_paradas) {
        $actual_parada = hmi($nodo_paradas);
        $seg = 0;
        while ($actual_parada && $seg < 100) {
            $nodo_hora = $actual_parada->adyacente('hora_estimada');
            $paradas[] = [
                'nombre' => $actual_parada->dato(),
                'hora_estimada' => $nodo_hora ? $nodo_hora->dato() : '',
            ];
            $actual_parada = hd($actual_parada);
            $seg++;
        }
    }
    $datos['paradas_intermedias'] = $paradas;

    // Determinar si el viaje está activo
    $fecha = $datos['fecha'];
    if ($fecha === 'a confirmar' || $fecha === '') {
        $datos['activo'] = '1';
    } else {
        $hoy = date('Y-m-d');
        $datos['activo'] = (strtotime($fecha) >= strtotime($hoy)) ? '1' : '0';
    }

    // Verificar si tiene ventas
    $datos['tiene_ventas'] = viaje_tiene_ventas($datos['dueno'], $nombre_viaje) ? '1' : '0';

    // Calcular ventas por micro de la terminal actual (si corresponde)
    $vendidos_por_micro = [];
    if ($nombre_terminal !== null) {
        $contenedor_ventas = obtener_contenedor_ventas_dueno($datos['dueno']);
        if ($contenedor_ventas) {
            $venta_iter = hmi($contenedor_ventas);
            while ($venta_iter) {
                $nodo_terminal_venta = $venta_iter->adyacente('terminal');
                $nodo_micro_venta = $venta_iter->adyacente('micro');
                $nodo_viaje_venta = $venta_iter->adyacente('viaje');

                if ($nodo_terminal_venta && $nodo_terminal_venta->dato() === $nombre_terminal
                    && $nodo_viaje_venta && $nodo_viaje_venta->dato() === $nombre_viaje
                    && $nodo_micro_venta) {
                    $micro_id = $nodo_micro_venta->id();
                    $cabeza = $venta_iter->adyacente('asientos');
                    $cantidad = 0;
                    if ($cabeza) {
                        $asiento = $cabeza->adyacente('primer');
                        $seg = 0;
                        while ($asiento && $seg < 100) {
                            $cantidad++;
                            $asiento = $asiento->adyacente('siguiente');
                            $seg++;
                        }
                    }
                    $vendidos_por_micro[$micro_id] = ($vendidos_por_micro[$micro_id] ?? 0) + $cantidad;
                }
                $venta_iter = hd($venta_iter);
            }
        }
    }

    // Pre-cargar el contenedor de empresas del dueño (para resolver nombres visibles)
    $raiz_usuarios = Nodo::nodo_por_id('usuarios');
    $nodo_dueno_iter = $raiz_usuarios ? $raiz_usuarios->adyacente($datos['dueno']) : null;
    $nodo_empresas = $nodo_dueno_iter ? $nodo_dueno_iter->adyacente('empresas') : null;

    // Micros
    $micros = [];
    $total_reservados_micros = 0;
    $total_seleccionados_micros = 0;
    $total_vendidos_micros = 0;
    $total_ocupacion_micros = 0;
    $nodo_micros = $nodo_viaje->adyacente('micros');
    if ($nodo_micros) {
        $adyacentes_micros = (array) $nodo_micros->adyacentes();
        foreach ($adyacentes_micros as $nombre_micro => $nodo_micro) {
            // Identificador de empresa: puede venir como nodo enlazado (micros nuevos)
            // o como nodo suelto cuyo dato es el string (micros viejos).
            $identificador_empresa = '';
            $nodo_empresa_enlazada = $nodo_micro->adyacente('empresa');
            if ($nodo_empresa_enlazada) {
                $identificador_empresa = $nodo_empresa_enlazada->dato();
            }

            // Nombre visible: buscar siempre la empresa real en el contenedor del dueño
            // usando el identificador. Esto funciona para micros nuevos y viejos.
            $nombre_empresa = $identificador_empresa;
            if ($identificador_empresa !== '' && $nodo_empresas) {
                $nodo_empresa_real = $nodo_empresas->adyacente($identificador_empresa);
                if ($nodo_empresa_real && $nodo_empresa_real->adyacente('nombre')) {
                    $nombre_empresa = $nodo_empresa_real->adyacente('nombre')->dato();
                }
            }

            // Patente: preferentemente desde vehiculo_copia (config nueva), fallback al enlace viejo
            $patente = '';
            $nodo_copia = $nodo_micro->adyacente('vehiculo_copia');
            if ($nodo_copia) {
                $patente = $nodo_copia->dato();
            } else {
                $nodo_patente = $nodo_micro->adyacente('patente');
                if ($nodo_patente) $patente = $nodo_patente->dato();
            }

            // Nombre visible del vehículo (desde la copia clonada)
            $nombre_vehiculo = $patente;
            if ($nodo_copia && $nodo_copia->adyacente('nombre')) {
                $nombre_vehiculo = $nodo_copia->adyacente('nombre')->dato();
            }

            // Contadores calculados al vuelo desde los asientos reales del micro.
            // No dependemos de los nodos 'seleccionados', 'vendidos', etc. del
            // micro, que pueden estar desactualizados si alguna operación no
            // llamó a actualizar_contadores_micro.
            $c_micro = contar_contadores_micro($nodo_micro);

            $total_reservados_micros += $c_micro['reservados'];
            $total_seleccionados_micros += $c_micro['seleccionados'];
            $total_vendidos_micros += $c_micro['vendidos'];
            $total_ocupacion_micros += $c_micro['ocupacion'];

            $micros[] = [
                'nombre_micro' => $nombre_micro,
                'empresa' => $identificador_empresa,
                'patente' => $patente,
                'nombre_empresa' => $nombre_empresa,
                'nombre_vehiculo' => $nombre_vehiculo,
                'monto' => $nodo_micro->adyacente('monto') ? $nodo_micro->adyacente('monto')->dato() : '0',
                'ocupacion' => (string)$c_micro['ocupacion'],
                'seleccionados' => (string)$c_micro['seleccionados'],
                'vendidos' => (string)$c_micro['vendidos'],
                'reservados' => (string)$c_micro['reservados'],
                'disponibles' => (string)$c_micro['disponibles'],
                'vendidos_aqui' => ($nombre_terminal !== null) ? (string)($vendidos_por_micro[$nodo_micro->id()] ?? 0) : null,
            ];
        }
    }
    $datos['micros'] = $micros;

    // Contadores del viaje: siempre la suma de los contadores de cada micro.
    // Fórmula de disponibles consistente con el micro: los seleccionados y los
    // reservados siguen restando, porque mientras lo están no pueden venderse
    // desde otra terminal ni ser reservados de nuevo.
    $datos['ocupacion'] = (string)$total_ocupacion_micros;
    $datos['seleccionados'] = (string)$total_seleccionados_micros;
    $datos['vendidos'] = (string)$total_vendidos_micros;
    $datos['reservados'] = (string)$total_reservados_micros;
    $datos['disponibles'] = (string)max(
        0,
        $total_ocupacion_micros - $total_vendidos_micros - $total_seleccionados_micros - $total_reservados_micros
    );

    // Terminales autorizadas
    // NOTA v1.5piloto.31: las claves del contenedor siguen siendo los nombres de las terminales,
    // pero los nodos destino son ahora "Nodo TerminalViaje" (nodo intermedio), no el Nodo Usuario
    // terminal directamente. Acá solo devolvemos la lista de nombres, que es lo que consume el front.
    $terminales = [];
    $nodo_terminales = $nodo_viaje->adyacente('terminales_autorizadas');
    if ($nodo_terminales) {
        $adyacentes_terminales = (array) $nodo_terminales->adyacentes();
        foreach ($adyacentes_terminales as $nombre_terminal_iter => $nodo_terminal) {
            $terminales[] = $nombre_terminal_iter;
        }
    }
    $datos['terminales_autorizadas'] = $terminales;

    // Opciones avanzadas (definida en ViajeOpciones.php)
    $datos['opciones_avanzadas'] = obtener_opciones_avanzadas_viaje($datos['dueno'], $nombre_viaje);
    return $datos;
}

/**
 * Verifica si un viaje tiene ventas registradas.
 */
function viaje_tiene_ventas(string $nombre_dueno, string $nombre_viaje): bool {
    $raiz_usuarios = Nodo::nodo_por_id('usuarios');
    if (!$raiz_usuarios) return false;

    $nodo_dueno = $raiz_usuarios->adyacente($nombre_dueno);
    if (!$nodo_dueno) return false;

    $contenedor_ventas = $nodo_dueno->adyacente('ventas');
    if (!$contenedor_ventas) return false;

    $actual = hmi($contenedor_ventas);
    while ($actual) {
        $nodo_viaje_venta = $actual->adyacente('viaje');
        if ($nodo_viaje_venta && $nodo_viaje_venta->dato() === $nombre_viaje) {
            return true;
        }
        $actual = hd($actual);
    }
    return false;
}

/**
 * Guarda la lista de paradas intermedias en el nodo viaje.
 * Reemplaza por completo la lista actual.
 *
 * A partir de v1.5piloto.31:
 * - Reutiliza los nodos parada existentes cuando el nombre coincide, para no
 *   romper el enlace `punto_subida_bajada` de los Nodos TerminalViaje.
 * - Rechaza la operación si alguna parada que está siendo referenciada por algún
 *   TerminalViaje (vía `punto_subida_bajada`) quedaría fuera de la nueva lista.
 *
 * A partir de v1.5piloto.34:
 * - Acepta elementos como string (retrocompatible) o como array
 *   {nombre, hora_estimada}. La hora se valida contra /^\d{2}:\d{2}$/;
 *   si no cumple, se guarda vacío.
 * - Escribe el enlace `hora_estimada` en el nodo parada cuando corresponda.
 *
 * @param Nodo $nodo_viaje Nodo del viaje.
 * @param array $paradas Lista de paradas (strings u objetos {nombre, hora_estimada}).
 * @return array Resultado con 'exito' => true, o 'exito' => false + 'error'.
 */
function _guardar_paradas_intermedias(Nodo $nodo_viaje, array $paradas): array {
    // 1. Normalizar la lista nueva.
    //    Array asociativo nombre => hora (string). Si hay repetidos, gana el último.
    $paradas_normalizadas = [];
    foreach ($paradas as $p) {
        if (is_array($p)) {
            $nombre = trim((string)($p['nombre'] ?? ''));
            $hora = trim((string)($p['hora_estimada'] ?? ''));
        } else {
            $nombre = trim((string)$p);
            $hora = '';
        }
        if ($nombre === '') continue;
        // Validar formato HH:MM. Si no cumple, se guarda vacío.
        if ($hora !== '' && !preg_match('/^\d{2}:\d{2}$/', $hora)) {
            $hora = '';
        }
        $paradas_normalizadas[$nombre] = $hora;
    }

    $nombres_nuevos = array_keys($paradas_normalizadas);

    // 2. Validar que ninguna parada en uso quede fuera del set nuevo
    $nodo_terminales = $nodo_viaje->adyacente('terminales_autorizadas');
    if ($nodo_terminales) {
        $adyacentes = (array) $nodo_terminales->adyacentes();
        foreach ($adyacentes as $nombre_terminal => $nodo_tv) {
            // Saltar nodos viejos sin migrar (formato anterior a v1.5piloto.31)
            if (!$nodo_tv->adyacente('terminal')) continue;

            $nodo_punto = $nodo_tv->adyacente('punto_subida_bajada');
            if (!$nodo_punto) continue;

            $nombre_parada = $nodo_punto->dato();
            if (!isset($paradas_normalizadas[$nombre_parada])) {
                return [
                    'exito' => false,
                    'error' => "No se puede eliminar la parada \"$nombre_parada\" porque está siendo usada como punto de subida/bajada por la terminal \"$nombre_terminal\". Primero hay que liberar esa configuración."
                ];
            }
        }
    }

    // 3. Indexar los nodos parada existentes por su dato (para reutilizarlos)
    $nodos_existentes = [];
    $nodo_paradas = $nodo_viaje->adyacente('paradas_intermedias');
    if ($nodo_paradas) {
        $actual = hmi($nodo_paradas);
        $seg = 0;
        while ($actual && $seg < 500) {
            $nodos_existentes[$actual->dato()] = $actual;
            $actual = hd($actual);
            $seg++;
        }
        // Vaciar la lista (los nodos en sí quedan vivos hasta que se reutilicen o queden huérfanos)
        while ($hijo = hmi($nodo_paradas)) {
            eliminar_hmi($nodo_paradas);
        }
    } else {
        $nodo_paradas = Nodo::crear_con_dato('');
        $nodo_viaje->_adyacente_en($nodo_paradas, 'paradas_intermedias');
    }

    // 4. Reinsertar en orden (usando _hmi, que agrega al inicio, por eso invertimos)
    $nombres_invertidos = array_reverse($nombres_nuevos);
    foreach ($nombres_invertidos as $nombre_parada) {
        $hora = $paradas_normalizadas[$nombre_parada];

        if (isset($nodos_existentes[$nombre_parada])) {
            $nodo_parada = $nodos_existentes[$nombre_parada];
            // Actualizar la hora estimada del nodo reutilizado
            $nodo_hora = $nodo_parada->adyacente('hora_estimada');
            if ($hora === '') {
                if ($nodo_hora) $nodo_parada->eliminar_adyacente('hora_estimada');
            } else {
                if ($nodo_hora) $nodo_hora->_dato($hora);
                else $nodo_parada->_adyacente_en(Nodo::crear_con_dato($hora), 'hora_estimada');
            }
        } else {
            $nodo_parada = Nodo::crear_con_dato($nombre_parada);
            if ($hora !== '') {
                $nodo_parada->_adyacente_en(Nodo::crear_con_dato($hora), 'hora_estimada');
            }
        }
        _hmi($nodo_paradas, $nodo_parada);
    }

    return ['exito' => true];
}

/**
 * Agrega un nuevo viaje.
 */
function agregar_viaje(array $datos): array {
    $nombre_dueno = $datos['nombre_dueno'] ?? '';
    $nombre_viaje = $datos['nombre_viaje'] ?? '';
    if (empty($nombre_dueno) || empty($nombre_viaje)) {
        return ['exito' => false, 'error' => 'Dueño y nombre de viaje son obligatorios'];
    }

    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    if ($nodo_viajes->adyacente($nombre_viaje)) {
        return ['exito' => false, 'error' => 'Ya existe un viaje con ese nombre'];
    }

    $nodo_viaje = Nodo::crear_con_dato($nombre_viaje);
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($nombre_dueno), 'dueno');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['nombre'] ?? ''), 'nombre');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['fecha'] ?? ''), 'fecha');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['hora'] ?? ''), 'hora');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['origen'] ?? ''), 'origen');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['destino'] ?? ''), 'destino');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'ocupacion');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'disponibles');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'seleccionados');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'vendidos');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'reservados');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato(''), 'micros');
    $nodo_viaje->_adyacente_en(Nodo::crear_con_dato(''), 'terminales_autorizadas');

    // Guardar paradas intermedias si las hay
    $paradas = [];
    if (isset($datos['paradas_intermedias'])) {
        if (is_array($datos['paradas_intermedias'])) {
            $paradas = $datos['paradas_intermedias'];
        } elseif (is_string($datos['paradas_intermedias'])) {
            $paradas = json_decode($datos['paradas_intermedias'], true) ?: [];
        }
    }
    if (!empty($paradas)) {
        $resultado_paradas = _guardar_paradas_intermedias($nodo_viaje, $paradas);
        if (!$resultado_paradas['exito']) {
            return $resultado_paradas;
        }
    }

    $nodo_viajes->_adyacente_en($nodo_viaje, $nombre_viaje);
    guardar_ambos(Conf::NOMBRE_APP);
    return ['exito' => true];
}

/**
 * Edita los datos básicos de un viaje.
 */
function editar_viaje(string $nombre_viaje, array $datos): array {
    $nombre_dueno = $datos['nombre_dueno'] ?? '';
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    foreach (['nombre', 'fecha', 'hora', 'origen', 'destino'] as $campo) {
        if (isset($datos[$campo])) {
            $nodo_campo = $nodo_viaje->adyacente($campo);
            if ($nodo_campo) $nodo_campo->_dato($datos[$campo]);
            else $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos[$campo]), $campo);
        }
    }

    // Guardar paradas intermedias si se enviaron
    if (isset($datos['paradas_intermedias'])) {
        $paradas = $datos['paradas_intermedias'];
        if (is_string($paradas)) {
            $paradas = json_decode($paradas, true) ?: [];
        }
        $resultado_paradas = _guardar_paradas_intermedias($nodo_viaje, is_array($paradas) ? $paradas : []);
        if (!$resultado_paradas['exito']) {
            return $resultado_paradas;
        }
    }

    guardar_ambos(Conf::NOMBRE_APP);
    return ['exito' => true];
}

/**
 * Elimina un viaje.
 */
function eliminar_viaje(string $nombre_viaje, string $nombre_dueno): array {
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    // Verificar si tiene ventas
    if (viaje_tiene_ventas($nombre_dueno, $nombre_viaje)) {
        return ['exito' => false, 'error' => 'No se pueden eliminar viajes con ventas ya realizadas'];
    }

    // TODO: eliminar nodos huérfanos
    $nodo_viajes->eliminar_adyacente($nombre_viaje);
    guardar_ambos(Conf::NOMBRE_APP);
    return ['exito' => true];
}

/**
 * Autoriza una terminal (punto de venta) en un viaje.
 *
 * A partir de v1.5piloto.31, cada autorización crea un Nodo TerminalViaje
 * (nodo intermedio, dato vacío) que contiene el enlace `terminal` hacia el
 * Nodo Usuario terminal, y cuelga del contenedor `terminales_autorizadas`
 * con el nombre de la terminal como clave.
 *
 * @param string $nombre_viaje     Identificador del viaje.
 * @param string $nombre_terminal  Nombre de usuario de la terminal.
 * @param string $nombre_dueno     Nombre de usuario del dueño.
 * @return array Resultado.
 */
function agregar_terminal_autorizada(string $nombre_viaje, string $nombre_terminal, string $nombre_dueno): array {
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    // Verificar que exista el Nodo Usuario terminal
    $raiz_usuarios = Nodo::nodo_por_id('usuarios');
    if (!$raiz_usuarios) return ['exito' => false, 'error' => 'No hay usuarios'];

    $nodo_usuario_terminal = $raiz_usuarios->adyacente($nombre_terminal);
    if (!$nodo_usuario_terminal) {
        return ['exito' => false, 'error' => 'La terminal no existe'];
    }

    // Obtener o crear el contenedor
    $nodo_terminales = $nodo_viaje->adyacente('terminales_autorizadas');
    if (!$nodo_terminales) {
        $nodo_terminales = Nodo::crear_con_dato('');
        $nodo_viaje->_adyacente_en($nodo_terminales, 'terminales_autorizadas');
    }

    if ($nodo_terminales->adyacente($nombre_terminal)) {
        return ['exito' => false, 'error' => 'La terminal ya está autorizada'];
    }

    // Crear nodo intermedio TerminalViaje
    $nodo_terminal_viaje = Nodo::crear_con_dato('');
    $nodo_terminal_viaje->_adyacente_en($nodo_usuario_terminal, 'terminal');
    $nodo_terminal_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'cambiar_punto_predeterminado');

    $nodo_terminales->_adyacente_en($nodo_terminal_viaje, $nombre_terminal);

    guardar_ambos(Conf::NOMBRE_APP);
    return ['exito' => true];
}

/**
 * Quita una terminal autorizada de un viaje.
 *
 * Desenlaza el Nodo TerminalViaje del contenedor y limpia sus enlaces internos.
 * El nodo intermedio queda huérfano (no se destruye), siguiendo el mismo
 * criterio que eliminar_micro_de_viaje.
 *
 * @param string $nombre_viaje     Identificador del viaje.
 * @param string $nombre_terminal  Nombre de usuario de la terminal.
 * @param string $nombre_dueno     Nombre de usuario del dueño.
 * @return array Resultado.
 */
function eliminar_terminal_autorizada(string $nombre_viaje, string $nombre_terminal, string $nombre_dueno): array {
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    $nodo_terminales = $nodo_viaje->adyacente('terminales_autorizadas');
    if (!$nodo_terminales) return ['exito' => false, 'error' => 'No hay terminales'];

    $nodo_terminal_viaje = $nodo_terminales->adyacente($nombre_terminal);
    if (!$nodo_terminal_viaje) {
        return ['exito' => false, 'error' => 'La terminal no está autorizada'];
    }

    // Limpiar enlaces internos antes de desenlazar (evita dejar referencias colgando)
    $nodo_terminal_viaje->eliminar_adyacente('punto_subida_bajada');

    $nodo_terminales->eliminar_adyacente($nombre_terminal);

    guardar_ambos(Conf::NOMBRE_APP);
    return ['exito' => true];
}

/**
 * Obtiene las opciones configuradas para la combinación viaje + terminal.
 *
 * A partir de v1.5piloto.31 incluye las opciones de punto de subida/bajada.
 * A partir de v1.5piloto.32 incluye las condiciones de pago (override).
 *
 * Los campos de condiciones de pago devuelven cadena vacía si no están
 * configurados en el nodo intermedio, para distinguir "sin override" de
 * "override en 0". El frontend usa esa cadena vacía para saber que debe
 * usar la configuración del viaje.
 *
 * @param string $nombre_dueno     Nombre de usuario del dueño.
 * @param string $nombre_viaje     Identificador del viaje.
 * @param string $nombre_terminal  Nombre de usuario de la terminal.
 * @return array
 */
function obtener_opciones_terminal_viaje(string $nombre_dueno, string $nombre_viaje, string $nombre_terminal): array {
    $defaults = [
        'cambiar_punto_predeterminado' => '0',
        'punto_subida_bajada' => '',
        // Condiciones de pago: vacío = sin override (usar config del viaje)
        'permite_efectivo' => '',
        'cuotas_efectivo_max' => '',
        'permite_transferencia' => '',
        'cuotas_transferencia_max' => '',
    ];

    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return $defaults;

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return $defaults;

    $nodo_terminales = $nodo_viaje->adyacente('terminales_autorizadas');
    if (!$nodo_terminales) return $defaults;

    $nodo_terminal_viaje = $nodo_terminales->adyacente($nombre_terminal);
    if (!$nodo_terminal_viaje) return $defaults;

    $opciones = $defaults;

    $nodo_cambiar = $nodo_terminal_viaje->adyacente('cambiar_punto_predeterminado');
    if ($nodo_cambiar) $opciones['cambiar_punto_predeterminado'] = $nodo_cambiar->dato();

    $nodo_punto = $nodo_terminal_viaje->adyacente('punto_subida_bajada');
    if ($nodo_punto) $opciones['punto_subida_bajada'] = $nodo_punto->dato();

    $campos_pago = [
        'permite_efectivo',
        'cuotas_efectivo_max',
        'permite_transferencia',
        'cuotas_transferencia_max',
    ];
    foreach ($campos_pago as $campo) {
        $nodo_campo = $nodo_terminal_viaje->adyacente($campo);
        if ($nodo_campo) $opciones[$campo] = $nodo_campo->dato();
    }

    return $opciones;
}

/**
 * Guarda las opciones configuradas para la combinación viaje + terminal.
 *
 * A partir de v1.5piloto.32 acepta los 4 campos de condiciones de pago.
 * La convención es:
 * - Si `permite_efectivo`, `permite_transferencia`, `cuotas_efectivo_max` y
 *   `cuotas_transferencia_max` vienen todos vacíos, se eliminan los 4 enlaces
 *   del nodo intermedio (sin override).
 * - Si vienen con valor, se escriben los 4 en el nodo intermedio.
 *
 * Se permite que el terminal deshabilite un método con `permite_X = "0"`.
 * No se permite deshabilitar ambos: en ese caso se devuelve error.
 *
 * @param string $nombre_dueno     Nombre de usuario del dueño.
 * @param string $nombre_viaje     Identificador del viaje.
 * @param string $nombre_terminal  Nombre de usuario de la terminal.
 * @param array  $opciones         Datos a guardar.
 * @return array Resultado.
 */
function guardar_opciones_terminal_viaje(string $nombre_dueno, string $nombre_viaje, string $nombre_terminal, array $opciones): array {
    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    $nodo_terminales = $nodo_viaje->adyacente('terminales_autorizadas');
    if (!$nodo_terminales) return ['exito' => false, 'error' => 'El viaje no tiene terminales autorizadas'];

    $nodo_terminal_viaje = $nodo_terminales->adyacente($nombre_terminal);
    if (!$nodo_terminal_viaje) {
        return ['exito' => false, 'error' => 'La terminal no está autorizada en este viaje'];
    }

    // === Punto de subida/bajada ===
    $cambiar = ($opciones['cambiar_punto_predeterminado'] ?? '0') === '1' ? '1' : '0';
    $punto = trim((string)($opciones['punto_subida_bajada'] ?? ''));

    $nodo_cambiar = $nodo_terminal_viaje->adyacente('cambiar_punto_predeterminado');
    if ($nodo_cambiar) $nodo_cambiar->_dato($cambiar);
    else $nodo_terminal_viaje->_adyacente_en(Nodo::crear_con_dato($cambiar), 'cambiar_punto_predeterminado');

    if ($cambiar === '1' && $punto !== '') {
        // Buscar el nodo parada existente
        $nodo_parada_encontrado = null;
        $nodo_paradas = $nodo_viaje->adyacente('paradas_intermedias');
        if ($nodo_paradas) {
            $actual = hmi($nodo_paradas);
            $seg = 0;
            while ($actual && $seg < 100) {
                if ($actual->dato() === $punto) {
                    $nodo_parada_encontrado = $actual;
                    break;
                }
                $actual = hd($actual);
                $seg++;
            }
        }
        if (!$nodo_parada_encontrado) {
            return ['exito' => false, 'error' => 'La parada seleccionada no existe en el viaje'];
        }
        $nodo_punto = $nodo_terminal_viaje->adyacente('punto_subida_bajada');
        if ($nodo_punto) {
            $nodo_terminal_viaje->_adyacente_en($nodo_parada_encontrado, 'punto_subida_bajada', true);
        } else {
            $nodo_terminal_viaje->_adyacente_en($nodo_parada_encontrado, 'punto_subida_bajada');
        }
    } else {
        $nodo_terminal_viaje->eliminar_adyacente('punto_subida_bajada');
    }

    // === Condiciones de pago (override) ===
    $campos_pago = ['permite_efectivo', 'cuotas_efectivo_max', 'permite_transferencia', 'cuotas_transferencia_max'];
    $todos_vacios = true;
    foreach ($campos_pago as $campo) {
        if (isset($opciones[$campo]) && trim((string)$opciones[$campo]) !== '') {
            $todos_vacios = false;
            break;
        }
    }

    if ($todos_vacios) {
        // Sin override: eliminar los 4 enlaces si existían
        foreach ($campos_pago as $campo) {
            $nodo_terminal_viaje->eliminar_adyacente($campo);
        }
    } else {
        // Hay override. Sanitizar y validar.
        $permite_efectivo = ($opciones['permite_efectivo'] ?? '1') === '1' ? '1' : '0';
        $permite_transferencia = ($opciones['permite_transferencia'] ?? '1') === '1' ? '1' : '0';

        if ($permite_efectivo === '0' && $permite_transferencia === '0') {
            return ['exito' => false, 'error' => 'Debe permitirse al menos un método de pago'];
        }

        $cuotas_efectivo_max = _clipear_cuotas($opciones['cuotas_efectivo_max'] ?? '3');
        $cuotas_transferencia_max = _clipear_cuotas($opciones['cuotas_transferencia_max'] ?? '1');

        _actualizar_o_crear_campo($nodo_terminal_viaje, 'permite_efectivo', $permite_efectivo);
        _actualizar_o_crear_campo($nodo_terminal_viaje, 'cuotas_efectivo_max', $cuotas_efectivo_max);
        _actualizar_o_crear_campo($nodo_terminal_viaje, 'permite_transferencia', $permite_transferencia);
        _actualizar_o_crear_campo($nodo_terminal_viaje, 'cuotas_transferencia_max', $cuotas_transferencia_max);
    }

    guardar_ambos(Conf::NOMBRE_APP);
    return ['exito' => true];
}
/**
 * Guarda un viaje (alta o edición) junto con sus opciones avanzadas.
 */
function guardar_viaje_completo(array $datos): array {
    $nombre_dueno = $datos['nombre_dueno'] ?? '';
    $nombre_viaje = $datos['nombre_viaje'] ?? '';
    if (empty($nombre_dueno) || empty($nombre_viaje)) {
        return ['exito' => false, 'error' => 'Dueño y nombre de viaje son obligatorios'];
    }

    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];

    $es_alta = !$nodo_viajes->adyacente($nombre_viaje);
    if ($es_alta) {
        // Crear viaje nuevo
        $nodo_viaje = Nodo::crear_con_dato($nombre_viaje);
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($nombre_dueno), 'dueno');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['nombre'] ?? ''), 'nombre');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['fecha'] ?? ''), 'fecha');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['hora'] ?? ''), 'hora');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['origen'] ?? ''), 'origen');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos['destino'] ?? ''), 'destino');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'ocupacion');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'disponibles');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'seleccionados');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'vendidos');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato('0'), 'reservados');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato(''), 'micros');
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato(''), 'terminales_autorizadas');
        $nodo_viajes->_adyacente_en($nodo_viaje, $nombre_viaje);
    } else {
        // Editar viaje existente
        $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
        foreach (['nombre', 'fecha', 'hora', 'origen', 'destino'] as $campo) {
            if (isset($datos[$campo])) {
                $nodo_campo = $nodo_viaje->adyacente($campo);
                if ($nodo_campo) $nodo_campo->_dato($datos[$campo]);
                else $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($datos[$campo]), $campo);
            }
        }
    }

    // Guardar paradas intermedias
    $paradas = [];
    if (isset($datos['paradas_intermedias'])) {
        if (is_array($datos['paradas_intermedias'])) {
            $paradas = $datos['paradas_intermedias'];
        } elseif (is_string($datos['paradas_intermedias'])) {
            $paradas = json_decode($datos['paradas_intermedias'], true) ?: [];
        }
    }
    $resultado_paradas = _guardar_paradas_intermedias($nodo_viaje, $paradas);
    if (!$resultado_paradas['exito']) {
        return $resultado_paradas;
    }

    // Guardar opciones avanzadas y condiciones de pago
    $opciones = [
        'restriccion_edad' => $datos['restriccion_edad'] ?? '0',
        'edad_minima' => $datos['edad_minima'] ?? '18',
        'edad_maxima' => $datos['edad_maxima'] ?? '80',
        'permite_efectivo' => $datos['permite_efectivo'] ?? '1',
        'cuotas_efectivo_max' => $datos['cuotas_efectivo_max'] ?? '3',
        'permite_transferencia' => $datos['permite_transferencia'] ?? '1',
        'cuotas_transferencia_max' => $datos['cuotas_transferencia_max'] ?? '1',
        'mostrar_dj_en_terminales' => $datos['mostrar_dj_en_terminales'] ?? '0',
    ];
    $resultado_opciones = guardar_opciones_avanzadas_viaje($nombre_dueno, $nombre_viaje, $opciones);
    if (!$resultado_opciones['exito']) {
        return $resultado_opciones;
    }

    guardar_ambos(Conf::NOMBRE_APP);
    return ['exito' => true];
}

/**
 * Sustituye los placeholders {{NOMBRE_VIAJE}} y {{FECHA_VIAJE}} en
 * un texto de declaración jurada por los datos reales del viaje.
 *
 * Si el viaje no tiene fecha definida (vacía o "a confirmar"), el
 * placeholder de la fecha se reemplaza por una racha de puntos para
 * completar a mano.
 *
 * @param string $contenido
 * @param Nodo   $nodo_viaje
 * @return string
 */
function _sustituir_placeholders_dj(string $contenido, Nodo $nodo_viaje): string {
    $nombre_visible = $nodo_viaje->adyacente('nombre')
        ? $nodo_viaje->adyacente('nombre')->dato()
        : $nodo_viaje->dato();

    $destino = $nodo_viaje->adyacente('destino')
        ? trim($nodo_viaje->adyacente('destino')->dato())
        : '';
    if ($destino === '') {
        $destino = '............................................................................................................................';
    }

    $fecha_iso = $nodo_viaje->adyacente('fecha')
        ? trim($nodo_viaje->adyacente('fecha')->dato())
        : '';

    if ($fecha_iso === '' || $fecha_iso === 'a confirmar') {
        $fecha_mostrar = '............................................................................................................................';
    } else {
        $fecha_mostrar = formatear_fecha_visible($fecha_iso);
    }

    return str_replace(
        ['{{NOMBRE_VIAJE}}', '{{DESTINO_VIAJE}}', '{{FECHA_VIAJE}}'],
        [$nombre_visible, $destino, $fecha_mostrar],
        $contenido
    );
}

/**
 * Devuelve el HTML de una declaración jurada del viaje. Si el nodo no
 * existe todavía, o si se pasa $forzar_default = true, devuelve el
 * texto por defecto con los placeholders ya sustituidos por los datos
 * del viaje (nombre visible y fecha), y lo marca con es_default = true.
 *
 * @param string $nombre_dueno
 * @param string $nombre_viaje
 * @param string $tipo  "mayor" o "menor"
 * @param bool   $forzar_default  Si es true, devuelve siempre el default
 *                                aunque exista un nodo guardado.
 * @return array
 */
function obtener_declaracion_jurada(string $nombre_dueno, string $nombre_viaje, string $tipo, bool $forzar_default = false): array {
    $tipo = ($tipo === 'menor') ? 'menor' : 'mayor';
    $enlace = 'declaracion_jurada_' . $tipo;

    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];
    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    if (!$forzar_default) {
        $nodo_dj = $nodo_viaje->adyacente($enlace);
        if ($nodo_dj) {
            return [
                'exito' => true,
                'contenido' => $nodo_dj->dato(),
                'es_default' => false,
            ];
        }
    }

    $default = ($tipo === 'mayor') ? TEXTO_DJ_MAYOR_DEFAULT : TEXTO_DJ_MENOR_DEFAULT;
    $default = _sustituir_placeholders_dj($default, $nodo_viaje);

    return [
        'exito' => true,
        'contenido' => $default,
        'es_default' => true,
    ];
}

/**
 * Guarda el HTML de una declaración jurada del viaje. Crea el nodo si
 * no existe, o lo actualiza si ya existe.
 *
 * @param string $nombre_dueno
 * @param string $nombre_viaje
 * @param string $tipo  "mayor" o "menor"
 * @param string $contenido
 * @return array
 */
function guardar_declaracion_jurada(string $nombre_dueno, string $nombre_viaje, string $tipo, string $contenido): array {
    $tipo = ($tipo === 'menor') ? 'menor' : 'mayor';
    $enlace = 'declaracion_jurada_' . $tipo;

    $nodo_viajes = obtener_contenedor_viajes_dueno($nombre_dueno);
    if (!$nodo_viajes) return ['exito' => false, 'error' => 'Dueño no encontrado'];
    $nodo_viaje = $nodo_viajes->adyacente($nombre_viaje);
    if (!$nodo_viaje) return ['exito' => false, 'error' => 'Viaje no encontrado'];

    $nodo_dj = $nodo_viaje->adyacente($enlace);
    if ($nodo_dj) {
        $nodo_dj->_dato($contenido);
    } else {
        $nodo_viaje->_adyacente_en(Nodo::crear_con_dato($contenido), $enlace);
    }

    guardar_ambos(Conf::NOMBRE_APP);
    return ['exito' => true];
}

// Incluir submódulos de viajes
require_once __DIR__ . '/ViajeMicros.php';
require_once __DIR__ . '/ViajeAsientos.php';
require_once __DIR__ . '/ViajeOpciones.php';
/***
 * Asientos y pasaje del micro.
 * @version 1.5piloto.82h
 */

// Modo actual del panel #info_asiento_viaje.
// Valores: null (oculto), 'propios' (grilla de propios), 'simple' (una sola tarjeta ajena/libre/vendida).
let info_asiento_modo = null;

// Polling adaptativo por inactividad.
const SYNC_INTERVALO_MS = 15000;
const SYNC_MAX_SIN_ACTIVIDAD = 10;
let sync_contador_sin_actividad = 0;
let sync_asientos_pausado = false;

function obtener_dueno_viaje_seleccionado() {
    if (viaje_seleccionado && viaje_seleccionado.dueno) {
        return viaje_seleccionado.dueno;
    }
    return obtener_nombre_dueno_actual();
}

/**
 * Busca un asiento en un array de estados por (piso, fila, columna).
 * Si `piso` viene vacío o undefined, cae a (fila, columna) —
 * comportamiento anterior (compatibilidad con flujos viejos).
 *
 * Fix v1.5piloto.82h: un micro con pisos distintos puede tener
 * asientos con la misma (fila, columna) en pisos distintos. Sin
 * piso, el .find() matchea el del primer piso.
 */
function _buscar_asiento_en_estados(estados, piso, fila, columna) {
    if (piso !== null && piso !== undefined && piso !== '') {
        return estados.find(e => String(e.piso) === String(piso) && e.fila === fila && e.columna === columna);
    }
    return estados.find(e => e.fila === fila && e.columna === columna);
}

/**
 * Devuelve true si hay una venta en curso. Se apoya en el hook
 * expuesto por ventas.js para no acceder directamente a la
 * variable venta_form_abierto (que es un let de scope global y
 * podria dar TDZ si se la lee muy temprano).
 */
function _venta_en_curso() {
    if (typeof window.venta_en_curso === 'function') {
        try {
            return window.venta_en_curso() === true;
        } catch (e) {
            return false;
        }
    }
    return false;
}

function iniciar_sync_asientos() {
    detener_sync_asientos();
    if (!viaje_seleccionado || !micro_seleccionado) return;

    microSyncActual = micro_seleccionado;
    sync_contador_sin_actividad = 0;
    sync_asientos_pausado = false;
    ocultar_cartel_inactividad();
    solicitar_estado_asientos();
    intervaloSyncAsientos = setInterval(solicitar_estado_asientos, SYNC_INTERVALO_MS);
}

function detener_sync_asientos() {
    if (intervaloSyncAsientos) {
        clearInterval(intervaloSyncAsientos);
        intervaloSyncAsientos = null;
    }
    microSyncActual = null;
    sync_asientos_pausado = false;
    sync_contador_sin_actividad = 0;
    ocultar_cartel_inactividad();
}

async function solicitar_estado_asientos() {
    const nombre_micro_actual = microSyncActual || micro_seleccionado;
    if (!nombre_micro_actual || !viaje_seleccionado) return;

    let nombre_dueno = obtener_dueno_viaje_seleccionado();
    const respuesta = await fetch("index.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
            accion: "viajes/estado_asientos",
            nombre_viaje: viaje_seleccionado.nombre_viaje,
            nombre_micro: nombre_micro_actual,
            nombre_dueno
        })
    });
    const datos = await respuesta.json();

    // Condicion de carrera: si mientras el fetch estaba en vuelo
    // se inicio una operacion de asiento (clic, reserva, etc.),
    // descartar la respuesta. El estado que devuelve el backend
    // es de antes de esa operacion y pisaria el estado mas nuevo.
    if (operacion_asiento_en_curso) {
        return;
    }

    if (datos.exito) {
        estados_asientos_actuales = datos.asientos;
        actualizar_colores_asientos(datos.asientos);
        refrescar_info_asientos_propios(info_asiento_modo === null);
    }

    sync_contador_sin_actividad++;
    if (sync_contador_sin_actividad >= SYNC_MAX_SIN_ACTIVIDAD && !sync_asientos_pausado) {
        pausar_sync_por_inactividad();
    }
}

function pausar_sync_por_inactividad() {
    if (intervaloSyncAsientos) {
        clearInterval(intervaloSyncAsientos);
        intervaloSyncAsientos = null;
    }
    sync_asientos_pausado = true;
    mostrar_cartel_inactividad();
}

function reanudar_sync_por_actividad() {
    if (!sync_asientos_pausado) return;
    if (!viaje_seleccionado || !micro_seleccionado) return;

    sync_asientos_pausado = false;
    sync_contador_sin_actividad = 0;
    ocultar_cartel_inactividad();
    solicitar_estado_asientos();
    intervaloSyncAsientos = setInterval(solicitar_estado_asientos, SYNC_INTERVALO_MS);
}

function registrar_actividad_usuario() {
    sync_contador_sin_actividad = 0;
    if (sync_asientos_pausado) {
        reanudar_sync_por_actividad();
    }
}

function mostrar_cartel_inactividad() {
    const cartel = document.getElementById('aviso_inactividad_pasaje');
    if (cartel) cartel.classList.remove('hidden');
}

function ocultar_cartel_inactividad() {
    const cartel = document.getElementById('aviso_inactividad_pasaje');
    if (cartel) cartel.classList.add('hidden');
}

function actualizar_colores_asientos(estados) {
    const asientosDOM = document.querySelectorAll('#croquis_pasaje_micro .seat');
    asientosDOM.forEach(seat => {
        const piso = seat.dataset.piso;
        const fila = seat.dataset.fila;
        const columna = seat.dataset.columna;
        const estadoObj = _buscar_asiento_en_estados(estados, piso, fila, columna);
        if (estadoObj) {
            seat.classList.remove('seat-libre', 'seat-seleccionado', 'seat-seleccionado-propio', 'seat-vendido', 'seat-no-disponible', 'seat-reservado');
            if (estadoObj.estado === 'seleccionado') {
                if (estadoObj.seleccionado_por === usuario_actual.nombre_usuario) {
                    seat.classList.add('seat-seleccionado-propio');
                } else {
                    seat.classList.add('seat-seleccionado');
                }
            } else if (estadoObj.estado === 'reservado') {
                seat.classList.add('seat-reservado');
            } else {
                seat.classList.add(`seat-${estadoObj.estado}`);
            }
            seat.dataset.estado = estadoObj.estado;
            seat.dataset.seleccionado_por = estadoObj.seleccionado_por || '';
            seat.dataset.reservado_por = estadoObj.reservado_por || '';
        }
    });
    mostrar_boton_confirmar_venta();
}

async function seleccionar_asiento_pasaje(piso, fila, columna) {
    if (!micro_seleccionado || !viaje_seleccionado) return;
    if (operacion_asiento_en_curso) return;

    operacion_asiento_en_curso = true;

    const nombre_dueno = obtener_dueno_viaje_seleccionado();
    const nombre_terminal = usuario_actual.nombre_usuario;
    const nombre_micro = micro_seleccionado;

    detener_sync_asientos();

    try {
        const respuesta = await fetch("index.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({
                accion: "viajes/seleccionar_asiento",
                nombre_viaje: viaje_seleccionado.nombre_viaje,
                nombre_micro: nombre_micro,
                piso: (piso !== null && piso !== undefined) ? String(piso) : '',
                fila,
                columna,
                nombre_dueno,
                nombre_terminal
            })
        });
        const resultado = await respuesta.json();

        if (resultado.exito) {
            const asiento = _buscar_asiento_en_estados(estados_asientos_actuales, piso, fila, columna);
            if (asiento) {
                asiento.estado = 'seleccionado';
                asiento.seleccionado_por = nombre_terminal;
            }
            actualizar_colores_asientos(estados_asientos_actuales);
            refrescar_info_asientos_propios(true);
            mostrar_aviso("Asiento seleccionado", 'exito');
        } else {
            const estado_actual = _buscar_asiento_en_estados(estados_asientos_actuales, piso, fila, columna);
            if (estado_actual && estado_actual.estado === 'seleccionado' && estado_actual.seleccionado_por === nombre_terminal) {
                mostrar_aviso("Asiento seleccionado", 'exito');
            } else {
                mostrar_aviso(resultado.error || "No se pudo seleccionar", 'error');
                await solicitar_estado_asientos();
            }
        }
    } catch (error) {
        console.error("Error en selección:", error);
        mostrar_aviso("Error de comunicación", 'error');
        await solicitar_estado_asientos();
    } finally {
        operacion_asiento_en_curso = false;
        if (viaje_seleccionado && micro_seleccionado) {
            iniciar_sync_asientos();
        }
    }
}

async function deseleccionar_asiento_pasaje(piso, fila, columna) {
    if (!micro_seleccionado || !viaje_seleccionado) return;
    if (operacion_asiento_en_curso) return;
    if (_venta_en_curso()) {
        mostrar_aviso('Hay una venta en curso. Termínala o cancelala antes de liberar el asiento.', 'error');
        return;
    }

    operacion_asiento_en_curso = true;

    const nombre_dueno = obtener_dueno_viaje_seleccionado();
    const nombre_terminal = usuario_actual.nombre_usuario;
    const nombre_micro = micro_seleccionado;

    detener_sync_asientos();

    try {
        const respuesta = await fetch("index.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({
                accion: "viajes/deseleccionar_asiento",
                nombre_viaje: viaje_seleccionado.nombre_viaje,
                nombre_micro: nombre_micro,
                piso: (piso !== null && piso !== undefined) ? String(piso) : '',
                fila,
                columna,
                nombre_dueno,
                nombre_terminal
            })
        });
        const resultado = await respuesta.json();

        if (resultado.exito) {
            const asiento = _buscar_asiento_en_estados(estados_asientos_actuales, piso, fila, columna);
            if (asiento) {
                asiento.estado = 'libre';
                asiento.seleccionado_por = null;
            }
            actualizar_colores_asientos(estados_asientos_actuales);
            refrescar_info_asientos_propios(true);
            mostrar_aviso("Asiento liberado", 'exito');
        } else {
            mostrar_aviso(resultado.error || "No se pudo liberar", 'error');
            await solicitar_estado_asientos();
        }
    } catch (error) {
        console.error("Error en deselección:", error);
        mostrar_aviso("Error de comunicación", 'error');
        await solicitar_estado_asientos();
    } finally {
        operacion_asiento_en_curso = false;
        if (viaje_seleccionado && micro_seleccionado) {
            iniciar_sync_asientos();
        }
    }
}

/**
 * Determina si un asiento es "propio" del usuario actual:
 * - Terminal: seleccionado por el propio usuario.
 * - Dueño/admin: reservado por el equipo.
 */
function es_asiento_propio(asiento) {
    if (!asiento) return false;
    if (usuario_actual.nivel === 'terminal') {
        return asiento.estado === 'seleccionado' && asiento.seleccionado_por === usuario_actual.nombre_usuario;
    }
    if (usuario_actual.nivel === 'dueno' || es_admin_o_soporte()) {
        return asiento.estado === 'reservado';
    }
    return false;
}

function obtener_asientos_propios() {
    return estados_asientos_actuales.filter(es_asiento_propio);
}

let deseleccion_masiva_en_curso = false;

async function deseleccionar_todos_los_propios() {
    if (deseleccion_masiva_en_curso) return;
    deseleccion_masiva_en_curso = true;
    try {
        await _deseleccionar_todos_los_propios_interno();
    } finally {
        deseleccion_masiva_en_curso = false;
    }
}

async function _deseleccionar_todos_los_propios_interno() {
    const propios = obtener_asientos_propios();
    if (propios.length === 0) return;

    const es_terminal = usuario_actual.nivel === 'terminal';
    const nombre_dueno = obtener_dueno_viaje_seleccionado();
    const nombre_micro = micro_seleccionado;

    for (const asiento of propios) {
        try {
            if (es_terminal) {
                await fetch("index.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/x-www-form-urlencoded" },
                    body: new URLSearchParams({
                        accion: "viajes/deseleccionar_asiento",
                        nombre_viaje: viaje_seleccionado.nombre_viaje,
                        nombre_micro: nombre_micro,
                        piso: asiento.piso || '',
                        fila: asiento.fila,
                        columna: asiento.columna,
                        nombre_dueno: nombre_dueno,
                        nombre_terminal: usuario_actual.nombre_usuario
                    })
                });
                const local = estados_asientos_actuales.find(e => e.fila === asiento.fila && e.columna === asiento.columna);
                if (local) {
                    local.estado = 'libre';
                    local.seleccionado_por = null;
                }
            } else {
                await fetch("index.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/x-www-form-urlencoded" },
                    body: new URLSearchParams({
                        accion: "viajes/liberar_reserva_asiento",
                        nombre_viaje: viaje_seleccionado.nombre_viaje,
                        nombre_micro: nombre_micro,
                        piso: asiento.piso || '',
                        fila: asiento.fila,
                        columna: asiento.columna,
                        nombre_dueno: nombre_dueno
                    })
                });
                const local = estados_asientos_actuales.find(e => e.fila === asiento.fila && e.columna === asiento.columna);
                if (local) {
                    local.estado = 'libre';
                    local.reservado_por = null;
                    local.pasajero = null;
                    local.tiene_pasajero = false;
                }
            }
        } catch (e) {
            console.error("Error al deseleccionar asiento propio:", e);
        }
    }

    actualizar_colores_asientos(estados_asientos_actuales);
}

/**
 * Construye el HTML de una tarjeta de asiento individual.
 *
 * Muestra:
 * - Número de asiento
 * - Estado
 * - Si fue seleccionado por otra terminal (no el propio usuario): quién
 * - Si tiene venta asociada: código de venta y terminal vendedora
 * - Si tiene pasajero: nombre completo, DNI (sin puntos) y celular
 * - Botones según rol y estado
 *
 * Botones:
 * - "Reservar para equipo" (dueño/admin, asiento libre)
 * - "Liberar" (terminal, seleccionado por él mismo)
 * - "Asignar pasajero" (dueño/admin, reservado sin pasajero)
 * - "Liberar reserva" (dueño/admin, reservado)
 * - "Ver pasaje" (todos, reservado con pasajero o vendido)
 * - "Ver compra" (solo si el usuario actual fue quien realizó la venta)
 */
function construir_html_tarjeta_asiento(asiento) {
    const es_propio = es_asiento_propio(asiento);
    const es_terminal = usuario_actual.nivel === 'terminal';
    const es_dueno_o_admin = usuario_actual.nivel === 'dueno' || es_admin_o_soporte();

    let html = `<div class="asiento-card">`;
    html += `<div class="asiento-card-header">Asiento ${asiento.numero}</div>`;

    // Texto y color del estado
    if (es_propio && es_terminal) {
        html += `<div class="asiento-card-estado status-propio">SELECCIONADO POR TI</div>`;
    } else {
        html += `<div class="asiento-card-estado status-${asiento.estado}">${String(asiento.estado).toUpperCase()}</div>`;
    }

    // Seleccionado por otra terminal.
    // La comparación sigue siendo contra `seleccionado_por` (nombre de usuario)
    // porque es lo que identifica al propio usuario; solo cambia el texto que
    // se muestra, que prefiere el nombre real.
    if (asiento.seleccionado_por && asiento.seleccionado_por !== usuario_actual.nombre_usuario) {
        const nombre_mostrar = asiento.seleccionado_por_nombre_real || asiento.seleccionado_por;
        html += `<div class="asiento-card-linea"><span>Seleccionado por:</span><b>${nombre_mostrar}</b></div>`;
    }

    // Código de venta (si el asiento tiene venta asociada)
    if (asiento.venta_id) {
        html += `<div class="asiento-card-linea"><span>Cód. de venta:</span><b>${asiento.venta_id}</b></div>`;
    }

    // Terminal vendedora (solo en asientos vendidos)
    if (asiento.estado === 'vendido' && asiento.venta_terminal) {
        const vendedor_mostrar = asiento.venta_terminal_nombre_real || asiento.venta_terminal;
        html += `<div class="asiento-card-linea"><span>Vendido por:</span><b>${vendedor_mostrar}</b></div>`;
    }

    // Datos del pasajero (si hay)
    if (asiento.tiene_pasajero && asiento.pasajero) {
        const p = asiento.pasajero;
        const nombre = p.nombre_completo || '';
        const dni_visible = p.dni_visible || normalizar_dni_js(p.dni || '');
        const celular = p.celular || '';
        if (nombre) html += `<div class="asiento-card-linea"><span>Pasajero:</span><b>${nombre}</b></div>`;
        if (dni_visible) html += `<div class="asiento-card-linea"><span>DNI:</span><b>${dni_visible}</b></div>`;
        if (celular) html += `<div class="asiento-card-linea"><span>Celular:</span><b>${celular}</b></div>`;
    }

    // Botones
    const botones = [];

    // Si hay una venta en curso, los botones que modifican el asiento
    // arrancan deshabilitados. Los de lectura (Ver pasaje / Ver compra)
    // siguen activos.
    const bloqueo_venta = _venta_en_curso() ? ' disabled' : '';

    const piso_attr = ` data-piso="${asiento.piso || ''}"`;
    if (es_dueno_o_admin && asiento.estado === 'libre') {
        botones.push(`<button class="btn primary btn-reservar-asiento"${bloqueo_venta} data-fila="${asiento.fila}" data-columna="${asiento.columna}"${piso_attr}>Reservar para equipo</button>`);
    }

    if (es_terminal && es_propio) {
        botones.push(`<button class="btn danger btn-liberar-seleccion"${bloqueo_venta} data-fila="${asiento.fila}" data-columna="${asiento.columna}"${piso_attr}>Liberar</button>`);
    }

    if (es_dueno_o_admin && asiento.estado === 'reservado' && !asiento.tiene_pasajero) {
        botones.push(`<button class="btn primary btn-asignar-pasajero"${bloqueo_venta} data-fila="${asiento.fila}" data-columna="${asiento.columna}"${piso_attr}>Asignar pasajero</button>`);
    }

    if (es_dueno_o_admin && asiento.estado === 'reservado') {
        botones.push(`<button class="btn danger btn-liberar-reserva"${bloqueo_venta} data-fila="${asiento.fila}" data-columna="${asiento.columna}"${piso_attr}>Liberar reserva</button>`);
    }

    // Ver pasaje: disponible en reservado con pasajero o vendido
    if ((asiento.estado === 'reservado' && asiento.tiene_pasajero) || asiento.estado === 'vendido') {
        botones.push(`<button class="btn btn-ver-pasaje-asiento" data-fila="${asiento.fila}" data-columna="${asiento.columna}"${piso_attr}>Ver pasaje</button>`);
    }

    // Ver compra: dueño y admin lo ven siempre; la terminal solo si ella
    // hizo la venta. La comparación es contra `venta_terminal`, que guarda
    // el nombre de usuario (identificador). El texto que se muestra en la
    // tarjeta usa `venta_terminal_nombre_real` como fallback.
    if (asiento.estado === 'vendido' && asiento.venta_id) {
        const puede_ver_compra = es_dueno_o_admin
            || (es_terminal && asiento.venta_terminal === usuario_actual.nombre_usuario);
        if (puede_ver_compra) {
            botones.push(`<button class="btn btn-ver-compra-asiento" data-fila="${asiento.fila}" data-columna="${asiento.columna}" data-venta-id="${asiento.venta_id}">Ver compra</button>`);
        }
    }

    if (botones.length > 0) {
        html += `<div class="asiento-card-acciones">${botones.join('')}</div>`;
    }

    html += `</div>`;
    return html;
}

/**
 * Renderiza el panel de info con una lista de tarjetas en grilla de 2 columnas.
 */
function renderizar_tarjetas_asientos(asientos, titulo, modo) {
    const panel = $("#info_asiento_viaje");
    if (!panel) return;

    if (!asientos || asientos.length === 0) {
        panel.innerHTML = '';
        panel.classList.add('hidden');
        info_asiento_modo = null;
        return;
    }

    let html = `<div class="section-title">${titulo}</div>`;
    html += `<div class="asientos-grid">`;
    for (const asiento of asientos) {
        html += construir_html_tarjeta_asiento(asiento);
    }
    html += `</div>`;

    panel.innerHTML = html;
    panel.classList.remove('hidden');
    info_asiento_modo = modo;

    // Listeners de botones
    panel.querySelectorAll('.btn-reservar-asiento').forEach(btn => {
        btn.addEventListener('click', () => abrir_modal_reservar_asiento(btn.dataset.piso, btn.dataset.fila, btn.dataset.columna));
    });
    panel.querySelectorAll('.btn-liberar-seleccion').forEach(btn => {
        btn.addEventListener('click', () => deseleccionar_asiento_pasaje(btn.dataset.piso, btn.dataset.fila, btn.dataset.columna));
    });
    panel.querySelectorAll('.btn-asignar-pasajero').forEach(btn => {
        btn.addEventListener('click', () => abrir_modal_asignar_pasajero(btn.dataset.piso, btn.dataset.fila, btn.dataset.columna));
    });
    panel.querySelectorAll('.btn-liberar-reserva').forEach(btn => {
        btn.addEventListener('click', () => liberar_reserva_equipo(btn.dataset.piso, btn.dataset.fila, btn.dataset.columna));
    });
    panel.querySelectorAll('.btn-ver-pasaje-asiento').forEach(btn => {
        btn.addEventListener('click', () => ver_pasaje_asiento(btn.dataset.piso, btn.dataset.fila, btn.dataset.columna));
    });
    panel.querySelectorAll('.btn-ver-compra-asiento').forEach(btn => {
        btn.addEventListener('click', () => ver_compra_asiento(btn.dataset.ventaId));
    });

    // Re-aplicar el estado de bloqueo por si la grilla se dibujo
    // durante una venta en curso.
    actualizar_bloqueo_botones_asientos();
}

function refrescar_info_asientos_propios(forzar = false) {
    if (!forzar && (operacion_asiento_en_curso || deseleccion_masiva_en_curso)) return;
    if (!forzar && info_asiento_modo !== 'propios') return;

    const propios = obtener_asientos_propios();
    if (propios.length === 0) {
        const panel = $("#info_asiento_viaje");
        if (panel) {
            panel.innerHTML = '';
            panel.classList.add('hidden');
        }
        info_asiento_modo = null;
        return;
    }

    const titulo = (usuario_actual.nivel === 'terminal')
        ? `Asientos seleccionados (${propios.length})`
        : `Asientos reservados (${propios.length})`;
    renderizar_tarjetas_asientos(propios, titulo, 'propios');
}

function mostrar_info_asiento(asiento) {
    if (!asiento) return;

    if (es_asiento_propio(asiento)) {
        const propios = obtener_asientos_propios();
        const titulo = (usuario_actual.nivel === 'terminal')
            ? `Asientos seleccionados (${propios.length})`
            : `Asientos reservados (${propios.length})`;
        renderizar_tarjetas_asientos(propios, titulo, 'propios');
    } else {
        renderizar_tarjetas_asientos([asiento], 'Información de asiento', 'simple');
    }
}

/**
 * Abre el modal de reserva de un asiento libre para dueño/admin.
 * Incluye un checkbox para asignar los datos del pasajero en el mismo paso.
 */
function abrir_modal_reservar_asiento(piso, fila, columna) {
    if (_venta_en_curso()) {
        mostrar_aviso('Hay una venta en curso. Termínala o cancelala antes de reservar un asiento.', 'error');
        return;
    }
    const asiento = _buscar_asiento_en_estados(estados_asientos_actuales, piso, fila, columna);
    if (!asiento) {
        mostrar_aviso("Asiento no encontrado", 'error');
        return;
    }
    if (asiento.estado !== 'libre') {
        mostrar_aviso("El asiento ya no está libre", 'error');
        actualizar_detalle_viaje_actual();
        return;
    }

    const html = `
        <h3>Reservar asiento ${asiento.numero}</h3>
        <div class="field">
            <label><input type="checkbox" id="reservar_asignar_pasajero_check"> ¿Asignar datos del pasajero ahora?</label>
        </div>
        <div id="reservar_form_pasajero_container" style="display:none; margin-top:15px;">
            ${construir_html_formulario_pasajero(0, { incluir_selector_sb: false, incluir_ficha: false })}
        </div>
        <div class="actions" style="margin-top:15px;">
            <button class="btn primary" id="btn_confirmar_reserva">Reservar</button>
            <button class="btn" id="btn_cancelar_reserva">Cancelar</button>
        </div>
    `;

    abrir_modal_apilado('Reservar asiento', html);

    const contenedorModal = document.getElementById('modal_apilado_contenido');
    const checkbox = contenedorModal.querySelector('#reservar_asignar_pasajero_check');
    const contenedorPasajero = contenedorModal.querySelector('#reservar_form_pasajero_container');

    conectar_listeners_formulario_pasajero(contenedorPasajero, 0);

    checkbox.addEventListener('change', () => {
        contenedorPasajero.style.display = checkbox.checked ? '' : 'none';
    });

    contenedorModal.querySelector('#btn_cancelar_reserva').addEventListener('click', () => {
        cerrar_modal_apilado();
    });

    contenedorModal.querySelector('#btn_confirmar_reserva').addEventListener('click', async () => {
        let datos_pasajero = null;

        if (checkbox.checked) {
            const r = recolectar_datos_pasajero(0, { incluir_selector_sb: false, incluir_ficha: false });
            if (!r.ok) {
                mostrar_aviso(r.error, 'error');
                return;
            }
            datos_pasajero = r.datos;
        }

        const nombre_dueno = obtener_dueno_viaje_seleccionado();
        const params = {
            accion: "viajes/reservar_asiento",
            nombre_viaje: viaje_seleccionado.nombre_viaje,
            nombre_micro: micro_seleccionado,
            piso: (piso !== null && piso !== undefined) ? String(piso) : '',
            fila,
            columna,
            nombre_dueno
        };
        if (datos_pasajero) {
            params.datos_pasajero = JSON.stringify(datos_pasajero);
        }

        const respuesta = await fetch("index.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams(params)
        });
        const resultado = await respuesta.json();

        if (resultado.exito) {
            mostrar_aviso("Asiento reservado", 'exito');

            const nombre_dueno_reserva = nombre_dueno;
            const nombre_viaje_reserva = viaje_seleccionado ? viaje_seleccionado.nombre_viaje : '';
            const nombre_micro_reserva = micro_seleccionado || '';

            cerrar_modal_apilado();

            // Refrescar el modal grande que quedó vivo detrás, sin reconstruirlo.
            await refrescar_contadores_viaje_actual();
            await solicitar_estado_asientos();
            refrescar_info_asientos_propios(true);

            if (datos_pasajero) {
                mostrar_modal_chico_impresion_reserva(
                    nombre_dueno_reserva,
                    nombre_viaje_reserva,
                    nombre_micro_reserva,
                    fila,
                    columna,
                    asiento.numero
                );
            }
        } else {
            mostrar_aviso(resultado.error || "No se pudo reservar", 'error');
        }
    });
}
/**
 * Abre el modal de asignación de pasajero a un asiento reservado sin pasajero.
 *
 * Usa el patrón on_volver para que:
 *  - El header muestre el botón "← Volver".
 *  - "Cancelar" ejecute el callback (vuelve al detalle del viaje) en vez de
 *    cerrar todo.
 *  - Tras el éxito, se vuelva al detalle del viaje y se muestre el modal
 *    chico de impresión por encima.
 */
function abrir_modal_asignar_pasajero(piso, fila, columna) {
    if (_venta_en_curso()) {
        mostrar_aviso('Hay una venta en curso. Termínala o cancelala antes de asignar un pasajero.', 'error');
        return;
    }
    const asiento = _buscar_asiento_en_estados(estados_asientos_actuales, piso, fila, columna);
    if (!asiento) {
        mostrar_aviso("Asiento no encontrado", 'error');
        return;
    }
    if (asiento.estado !== 'reservado') {
        mostrar_aviso("El asiento ya no está reservado", 'error');
        actualizar_detalle_viaje_actual();
        return;
    }
    if (asiento.tiene_pasajero) {
        mostrar_aviso("El asiento ya tiene un pasajero asignado", 'error');
        return;
    }

    const html = `
        <h3>Asignar pasajero al asiento ${asiento.numero}</h3>
        ${construir_html_formulario_pasajero(0, { incluir_selector_sb: false, incluir_ficha: false })}
        <div class="actions" style="margin-top:15px;">
            <button class="btn primary" id="btn_confirmar_asignar">Asignar</button>
            <button class="btn" id="btn_cancelar_asignar">Cancelar</button>
        </div>
    `;

    abrir_modal_apilado('Asignar pasajero', html);

    const contenedorModal = document.getElementById('modal_apilado_contenido');
    conectar_listeners_formulario_pasajero(contenedorModal, 0);

    contenedorModal.querySelector('#btn_cancelar_asignar').addEventListener('click', () => {
        cerrar_modal_apilado();
    });

    contenedorModal.querySelector('#btn_confirmar_asignar').addEventListener('click', async () => {
        const r = recolectar_datos_pasajero(0, { incluir_selector_sb: false, incluir_ficha: false });
        if (!r.ok) {
            mostrar_aviso(r.error, 'error');
            return;
        }

        const nombre_dueno = obtener_dueno_viaje_seleccionado();
        const nombre_viaje_asig = viaje_seleccionado ? viaje_seleccionado.nombre_viaje : '';
        const nombre_micro_asig = micro_seleccionado || '';

        const respuesta = await fetch("index.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({
                accion: "viajes/asignar_pasajero_reserva",
                nombre_viaje: nombre_viaje_asig,
                nombre_micro: nombre_micro_asig,
                piso: (piso !== null && piso !== undefined) ? String(piso) : '',
                fila,
                columna,
                nombre_dueno,
                datos_pasajero: JSON.stringify(r.datos)
            })
        });
        const resultado = await respuesta.json();

        if (resultado.exito) {
            mostrar_aviso("Pasajero asignado", 'exito');

            cerrar_modal_apilado();

            // Refrescar el modal grande que quedó vivo detrás.
            await refrescar_contadores_viaje_actual();
            await solicitar_estado_asientos();
            refrescar_info_asientos_propios(true);

            mostrar_modal_chico_impresion_reserva(
                nombre_dueno,
                nombre_viaje_asig,
                nombre_micro_asig,
                fila,
                columna,
                asiento.numero
            );
        } else {
            mostrar_aviso(resultado.error || "No se pudo asignar", 'error');
        }
    });
}

/**
 * Muestra el modal con los datos del pasajero de un asiento (reservado con
 * pasajero o vendido). No muestra ficha de salud ni opción de imprimir.
 */
function ver_pasaje_asiento(piso, fila, columna) {
    const asiento = _buscar_asiento_en_estados(estados_asientos_actuales, piso, fila, columna);
    if (!asiento) {
        mostrar_aviso("Asiento no encontrado", 'error');
        return;
    }
    if (!asiento.tiene_pasajero || !asiento.pasajero) {
        mostrar_aviso("Este asiento no tiene pasajero", 'error');
        return;
    }

    const p = asiento.pasajero;
    const nombre = p.nombre_completo || '';
    const dni_visible = p.dni_visible || normalizar_dni_js(p.dni || '');
    const celular = p.celular || '';
    const celular_emergencia = p.celular_emergencia || '';
    const email = p.email || '';
    const fecha_nacimiento = p.fecha_nacimiento_visible || p.fecha_nacimiento || '';
    const direccion = p.direccion || '';
    const localidad = p.localidad || '';

    let html = `<h3>Pasaje del asiento ${asiento.numero}</h3>`;
    html += `<div class="seccion">`;
    html += `<h4>Datos del pasajero</h4>`;
    if (nombre) html += `<div class="detail-line"><span>Nombre:</span><strong>${nombre}</strong></div>`;
    if (dni_visible) html += `<div class="detail-line"><span>DNI:</span><strong>${dni_visible}</strong></div>`;
    if (celular) html += `<div class="detail-line"><span>Celular:</span><strong>${celular}</strong></div>`;
    if (celular_emergencia) html += `<div class="detail-line"><span>Celular de emergencia:</span><strong>${celular_emergencia}</strong></div>`;
    if (email) html += `<div class="detail-line"><span>Email:</span><strong>${email}</strong></div>`;
    if (fecha_nacimiento) html += `<div class="detail-line"><span>Fecha de nacimiento:</span><strong>${fecha_nacimiento}</strong></div>`;
    if (direccion || localidad) {
        const dir = [direccion, localidad].filter(v => v).join(', ');
        html += `<div class="detail-line"><span>Dirección:</span><strong>${dir}</strong></div>`;
    }
    html += `</div>`;

    // El botón de imprimir aparece siempre que haya pasajero. Según si hay
    // venta asociada o no, la URL cambia:
    //  - Con venta: usa el flujo de impresión de venta (con filtro por DNI).
    //  - Sin venta (reserva del equipo): usa el flujo de impresión de reserva,
    //    que muestra "EQUIPO" en lugar del código de venta.
    const nv = viaje_seleccionado ? viaje_seleccionado.nombre_viaje : '';
    const nm = micro_seleccionado || '';
    const nd = obtener_dueno_viaje_seleccionado();
    // v77c: botón "Cambiar de asiento" si el usuario tiene permiso.
    const puede_cambiar = _puede_cambiar_asiento(asiento);
    const btn_cambiar_html = puede_cambiar
        ? `<button class="btn" id="btn_cambiar_asiento_pasaje">Cambiar de asiento</button>`
        : '';
    if (asiento.venta_id) {
        html += `<div class="actions" style="margin-top:15px;">
            <button class="btn primary" id="btn_imprimir_pasaje_asiento" data-modo="venta" data-venta-id="${asiento.venta_id}" data-dni="${p.dni || ''}">Imprimir pasaje</button>
            ${btn_cambiar_html}
            <button class="btn" id="btn_cerrar_ver_pasaje">Cerrar</button>
        </div>`;
    } else {
        html += `<div class="actions" style="margin-top:15px;">
            <button class="btn primary" id="btn_imprimir_pasaje_asiento" data-modo="reserva" data-dueno="${nd}" data-viaje="${nv}" data-micro="${nm}" data-fila="${fila}" data-columna="${columna}">Imprimir pasaje</button>
            ${btn_cambiar_html}
            <button class="btn" id="btn_cerrar_ver_pasaje">Cerrar</button>
        </div>`;
    }

    abrir_modal_apilado('Ver pasaje', html);

    const btnImprimir = document.getElementById('btn_imprimir_pasaje_asiento');
    if (btnImprimir) {
        btnImprimir.addEventListener('click', function() {
            const modo = this.dataset.modo;
            if (modo === 'venta') {
                const id = this.dataset.ventaId;
                const dni = this.dataset.dni;
                window.open(`index.php?imprimir=1&tipo=pasajes&id_venta=${id}&dni=${dni}`, '_blank');
            } else {
                const nd = this.dataset.dueno;
                const nv = this.dataset.viaje;
                const nm = this.dataset.micro;
                const fila = this.dataset.fila;
                const columna = this.dataset.columna;
                window.open(
                    `index.php?imprimir=1&tipo=pasaje_reserva`
                    + `&dueno=${encodeURIComponent(nd)}`
                    + `&viaje=${encodeURIComponent(nv)}`
                    + `&micro=${encodeURIComponent(nm)}`
                    + `&fila=${fila}&columna=${columna}`,
                    '_blank'
                );
            }
        });
    }

    // v77c: listener del botón "Cambiar de asiento".
    const btnCambiar = document.getElementById('btn_cambiar_asiento_pasaje');
    if (btnCambiar) {
        btnCambiar.addEventListener('click', () => {
            abrir_modal_cambiar_asiento(nd, nv, nm, fila, columna, null, piso);
        });
    }

    const btnCerrar = document.getElementById('btn_cerrar_ver_pasaje');
    if (btnCerrar) {
        btnCerrar.addEventListener('click', cerrar_modal_apilado);
    }
}

/**
 * "Ver compra" desde la tarjeta de asiento: navega a la pestaña Vendidos
 * y resalta la tarjeta de la venta indicada. La lógica de la navegación
 * vive en ventas.js (función ir_a_venta_en_vendidos).
 */
function ver_compra_asiento(venta_id) {
    // Desde el croquis conocemos el viaje y el dueño, así que se los pasamos
    // para que la pestaña Vendidos pueda aplicar el filtro correcto.
    const nombre_dueno = viaje_seleccionado ? viaje_seleccionado.dueno : '';
    const nombre_viaje = viaje_seleccionado ? viaje_seleccionado.nombre_viaje : '';
    ir_a_venta_en_vendidos(venta_id, nombre_dueno, nombre_viaje);
}

/**
 * Muestra el modal chico flotante para imprimir el pasaje de un asiento
 * reservado para el equipo. Se invoca después de reservar un asiento con
 * datos del pasajero, o después de asignar un pasajero a una reserva
 * existente. Al cerrar, el modal grande ya está cerrado y el usuario ve
 * el detalle del viaje debajo.
 *
 * Recibe todos los datos como parámetros explícitos porque el cierre del
 * modal grande (cerrar_modal_generico) limpia micro_seleccionado y
 * microSyncActual; si leyéramos del estado global acá, la URL saldría sin
 * el micro y la impresión fallaría con "Viaje no encontrado".
 *
 * @param {string} nombre_dueno
 * @param {string} nombre_viaje
 * @param {string} nombre_micro
 * @param {string} fila
 * @param {string} columna
 * @param {string|number} numero_asiento
 */
function mostrar_modal_chico_impresion_reserva(nombre_dueno, nombre_viaje, nombre_micro, fila, columna, numero_asiento) {
    const contenedor = document.getElementById('modal_chico_impresion_reserva');
    const titulo = document.getElementById('modal_chico_impresion_reserva_titulo');
    const btnImprimir = document.getElementById('btn_modal_chico_imprimir_reserva');
    const btnCerrar = document.getElementById('btn_modal_chico_cerrar_reserva');
    if (!contenedor || !titulo || !btnImprimir || !btnCerrar) return;

    titulo.textContent = `Asiento ${numero_asiento} reservado para el equipo`;

    btnImprimir.onclick = () => {
        const url = `index.php?imprimir=1&tipo=pasaje_reserva`
            + `&dueno=${encodeURIComponent(nombre_dueno)}`
            + `&viaje=${encodeURIComponent(nombre_viaje)}`
            + `&micro=${encodeURIComponent(nombre_micro)}`
            + `&fila=${encodeURIComponent(fila)}`
            + `&columna=${encodeURIComponent(columna)}`;
        window.open(url, '_blank');
    };

    btnCerrar.onclick = () => {
        contenedor.classList.add('hidden');
    };

    contenedor.classList.remove('hidden');
}

/**
 * Liberar reserva de un asiento. Si tiene pasajero asignado, avisa que
 * se va a perder la asignación antes de continuar.
 */
async function liberar_reserva_equipo(piso, fila, columna) {
    if (!micro_seleccionado || !viaje_seleccionado) return;
    if (operacion_asiento_en_curso) return;
    if (_venta_en_curso()) {
        mostrar_aviso('Hay una venta en curso. Termínala o cancelala antes de liberar la reserva.', 'error');
        return;
    }

    const asiento = _buscar_asiento_en_estados(estados_asientos_actuales, piso, fila, columna);
    if (!asiento) {
        mostrar_aviso("Asiento no encontrado", 'error');
        return;
    }

    let mensaje = `¿Liberar la reserva del asiento ${asiento.numero}?`;
    if (asiento.tiene_pasajero) {
        mensaje = `El asiento ${asiento.numero} tiene un pasajero asignado. Si liberás la reserva, también se pierde la asignación del pasajero.\n\n¿Continuar?`;
    }
    if (!confirm(mensaje)) return;

    operacion_asiento_en_curso = true;
    const nombre_dueno = obtener_nombre_dueno_actual();
    const nombre_micro = micro_seleccionado;
    detener_sync_asientos();

    try {
        const respuesta = await fetch("index.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({
                accion: "viajes/liberar_reserva_asiento",
                nombre_viaje: viaje_seleccionado.nombre_viaje,
                nombre_micro: nombre_micro,
                piso: (piso !== null && piso !== undefined) ? String(piso) : '',
                fila,
                columna,
                nombre_dueno
            })
        });
        const resultado = await respuesta.json();
        if (resultado.exito) {
            mostrar_aviso("Reserva liberada correctamente", 'exito');
            const asientoLocal = _buscar_asiento_en_estados(estados_asientos_actuales, piso, fila, columna);
            if (asientoLocal) {
                asientoLocal.estado = 'libre';
                asientoLocal.reservado_por = null;
                asientoLocal.pasajero = null;
                asientoLocal.tiene_pasajero = false;
            }
            actualizar_colores_asientos(estados_asientos_actuales);
            refrescar_info_asientos_propios(true);
        } else {
            mostrar_aviso(resultado.error || "No se pudo liberar la reserva", 'error');
            await solicitar_estado_asientos();
        }
    } catch (error) {
        console.error("Error al liberar reserva:", error);
        mostrar_aviso("Error de comunicación", 'error');
        await solicitar_estado_asientos();
    } finally {
        operacion_asiento_en_curso = false;
        if (viaje_seleccionado && micro_seleccionado) {
            iniciar_sync_asientos();
        }
    }
}

/**
 * Reserva un asiento para el equipo (dueño). Sin pasajero asociado. Se
 * mantiene por compatibilidad interna por si se usa programáticamente.
 * El flujo interactivo ahora pasa por abrir_modal_reservar_asiento.
 */
async function reservar_asiento_equipo(piso, fila, columna) {
    if (!micro_seleccionado || !viaje_seleccionado) return;
    if (operacion_asiento_en_curso) return;
    operacion_asiento_en_curso = true;
    const nombre_dueno = obtener_nombre_dueno_actual();
    const nombre_micro = micro_seleccionado;
    detener_sync_asientos();

    try {
        const respuesta = await fetch("index.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({
                accion: "viajes/reservar_asiento",
                nombre_viaje: viaje_seleccionado.nombre_viaje,
                nombre_micro: nombre_micro,
                piso: (piso !== null && piso !== undefined) ? String(piso) : '',
                fila,
                columna,
                nombre_dueno
            })
        });
        const resultado = await respuesta.json();
        if (resultado.exito) {
            mostrar_aviso("Asiento reservado para el equipo", 'exito');
            const asiento = _buscar_asiento_en_estados(estados_asientos_actuales, piso, fila, columna);
            if (asiento) {
                asiento.estado = 'reservado';
                asiento.reservado_por = nombre_dueno;
                asiento.seleccionado_por = null;
            }
            actualizar_colores_asientos(estados_asientos_actuales);
            refrescar_info_asientos_propios(true);
        } else {
            mostrar_aviso(resultado.error || "No se pudo reservar el asiento", 'error');
            await solicitar_estado_asientos();
        }
    } catch (error) {
        console.error("Error al reservar:", error);
        mostrar_aviso("Error de comunicación", 'error');
        await solicitar_estado_asientos();
    } finally {
        operacion_asiento_en_curso = false;
        if (viaje_seleccionado && micro_seleccionado) {
            iniciar_sync_asientos();
        }
    }
}

function renderizar_pasaje_micro(micro) {
    const contenedorCroquis = $("#croquis_pasaje_micro");
    const contenedorFoto = $("#foto_micro_viaje");
    contenedorCroquis.innerHTML = '';
    contenedorFoto.innerHTML = '';

    window.micro_actual = micro;

    // Resetear el panel de info al abrir otro micro
    info_asiento_modo = null;
    const panelInfo = $("#info_asiento_viaje");
    if (panelInfo) {
        panelInfo.innerHTML = '';
        panelInfo.classList.add('hidden');
    }

    if (micro.foto) {
        contenedorFoto.innerHTML = `<img src="${micro.foto}" alt="Foto del micro" style="max-width:200px; max-height:200px; border-radius:8px;">`;
    }

    const configuracion = micro.configuracion;
    if (configuracion && configuracion.pisos && configuracion.pisos.length > 0) {
        configuracion.pisos.forEach((piso, index) => {
            const titulo = document.createElement('div');
            titulo.className = 'section-title';
            titulo.textContent = `Piso ${index + 1}`;
            contenedorCroquis.appendChild(titulo);

            const busDiv = document.createElement('div');
            busDiv.className = 'bus';
            busDiv.innerHTML = `<div class="bus-front">FRENTE · CONDUCTOR</div>`;

            for (let fila = 1; fila <= piso.filas; fila++) {
                const filaDiv = document.createElement('div');
                filaDiv.className = 'seat-row';
                for (let col = 1; col <= piso.columnas; col++) {
                    const asiento = piso.asientos.find(a => parseInt(a.fila) === fila && parseInt(a.columna) === col);
                    if (asiento) {
                        const seat = document.createElement('div');
                        seat.className = `seat seat-${asiento.estado}`;
                        seat.textContent = String(asiento.numero).padStart(2, '0');
                        seat.dataset.piso = String(index + 1);
                        seat.dataset.fila = asiento.fila;
                        seat.dataset.columna = asiento.columna;
                        seat.dataset.numero = asiento.numero;
                        seat.dataset.estado = asiento.estado;
                        seat.dataset.reservado_por = asiento.reservado_por || '';
                        filaDiv.appendChild(seat);
                    } else {
                        const empty = document.createElement('div');
                        empty.className = 'aisle';
                        filaDiv.appendChild(empty);
                    }
                }
                busDiv.appendChild(filaDiv);
            }
            busDiv.innerHTML += `<div class="bus-back">PARTE TRASERA</div>`;
            contenedorCroquis.appendChild(busDiv);
        });

        contenedorCroquis.onclick = async (event) => {
            if (venta_form_abierto || operacion_asiento_en_curso) return;
            const seat = event.target.closest('.seat');
            if (!seat) return;
            const piso = seat.dataset.piso;
            const fila = seat.dataset.fila;
            const columna = seat.dataset.columna;
            const asiento = _buscar_asiento_en_estados(estados_asientos_actuales, piso, fila, columna);
            if (!asiento) return;

            const es_terminal = usuario_actual.nivel === 'terminal';

            if (es_terminal) {
                const es_propio_clic = es_asiento_propio(asiento);
                const es_libre_clic = asiento.estado === 'libre';
                const propios = obtener_asientos_propios();
                if (!es_propio_clic && !es_libre_clic && propios.length > 0) {
                    await deseleccionar_todos_los_propios();
                }
            }

            mostrar_info_asiento(asiento);

            if (es_terminal) {
                if (asiento.estado === 'reservado') {
                    mostrar_aviso("Asiento reservado para el equipo", 'info');
                    return;
                }
                if (asiento.estado === 'libre') {
                    seleccionar_asiento_pasaje(piso, fila, columna);
                } else if (asiento.estado === 'seleccionado' && asiento.seleccionado_por === usuario_actual.nombre_usuario) {
                    deseleccionar_asiento_pasaje(piso, fila, columna);
                }
            }
        };
    } else {
        contenedorCroquis.innerHTML = '<p>No hay configuración de asientos.</p>';
    }

    $("#pasaje_micro_viaje").classList.remove("hidden");
    micro_seleccionado = micro.nombre_micro;
    iniciar_sync_asientos();

    const leyendaHTML = `
        <div class="legend" style="margin-top:15px;">
            <div class="legend-item"><span class="swatch sw-free"></span> Libre</div>
            <div class="legend-item"><span class="swatch sw-selected"></span> Seleccionado</div>
            <div class="legend-item"><span class="swatch sw-sold"></span> Vendido</div>
            <div class="legend-item"><span class="swatch sw-reserved"></span> Reservado</div>
        </div>
    `;
    contenedorCroquis.insertAdjacentHTML('beforeend', leyendaHTML);

    // Botones de impresión: dueño, terminal, admin y soporte.
    // La terminal se agrega en v79e. Antes se la excluía porque
    // el backend no estaba adaptado a carga parcial; hoy sí lo
    // está. Los datos que exponen croquis y planilla ya los ve
    // la terminal en el modal "Ver pasaje" y en el propio croquis,
    // así que no es una fuga nueva.
    if (usuario_actual.nivel === 'dueno' || usuario_actual.nivel === 'terminal' || es_admin_o_soporte()) {
        const nombre_dueno_imp = obtener_dueno_viaje_seleccionado();
        const nombre_viaje_imp = viaje_seleccionado ? viaje_seleccionado.nombre_viaje : '';
        const nombre_micro_imp = micro.nombre_micro;

        const botonesHTML = `
            <div class="acciones-impresion-micro" style="margin-top:12px; display:flex; gap:10px; justify-content:center; flex-wrap:wrap;">
                <button class="btn" id="btn_imprimir_croquis_micro">Imprimir Croquis</button>
                <button class="btn primary" id="btn_imprimir_planilla_micro">Imprimir Planilla</button>
                <button class="btn" id="btn_imprimir_planilla_vacia_micro">Imprimir Planilla Vacía</button>
            </div>
        `;
        contenedorCroquis.insertAdjacentHTML('beforeend', botonesHTML);

        const btn_croquis = document.getElementById('btn_imprimir_croquis_micro');
        if (btn_croquis) {
            btn_croquis.addEventListener('click', () => {
                const url = `index.php?imprimir=1&tipo=croquis_micro`
                    + `&dueno=${encodeURIComponent(nombre_dueno_imp)}`
                    + `&viaje=${encodeURIComponent(nombre_viaje_imp)}`
                    + `&micro=${encodeURIComponent(nombre_micro_imp)}`;
                window.open(url, '_blank');
            });
        }

        const btn_planilla = document.getElementById('btn_imprimir_planilla_micro');
        if (btn_planilla) {
            btn_planilla.addEventListener('click', () => {
                const url = `index.php?imprimir=1&tipo=planilla_pasajeros_micro`
                    + `&dueno=${encodeURIComponent(nombre_dueno_imp)}`
                    + `&viaje=${encodeURIComponent(nombre_viaje_imp)}`
                    + `&micro=${encodeURIComponent(nombre_micro_imp)}`;
                window.open(url, '_blank');
            });
        }

        const btn_planilla_vacia = document.getElementById('btn_imprimir_planilla_vacia_micro');
        if (btn_planilla_vacia) {
            btn_planilla_vacia.addEventListener('click', () => {
                const url = `index.php?imprimir=1&tipo=planilla_pasajeros_micro`
                    + `&dueno=${encodeURIComponent(nombre_dueno_imp)}`
                    + `&viaje=${encodeURIComponent(nombre_viaje_imp)}`
                    + `&micro=${encodeURIComponent(nombre_micro_imp)}`
                    + `&vacia=1`;
                window.open(url, '_blank');
            });
        }
    }
}

/**
 * Manejador del botón "Reiniciar selección" del panel de pasaje.
 */
async function reiniciar_seleccion_propia() {
    if (operacion_asiento_en_curso) return;

    const propios = obtener_asientos_propios();
    if (propios.length === 0) {
        mostrar_aviso("No hay asientos seleccionados", 'info');
        return;
    }

    const texto = (usuario_actual.nivel === 'terminal')
        ? "¿Liberar todos los asientos seleccionados?"
        : "¿Liberar todas las reservas del equipo?";
    if (!confirm(texto)) return;

    operacion_asiento_en_curso = true;
    detener_sync_asientos();

    try {
        await deseleccionar_todos_los_propios();
        const panel = $("#info_asiento_viaje");
        if (panel) {
            panel.innerHTML = '';
            panel.classList.add('hidden');
        }
        info_asiento_modo = null;
        mostrar_aviso("Selección liberada", 'exito');
    } catch (e) {
        console.error("Error al reiniciar selección:", e);
        mostrar_aviso("Error al liberar los asientos", 'error');
    } finally {
        operacion_asiento_en_curso = false;
        if (viaje_seleccionado && micro_seleccionado) {
            iniciar_sync_asientos();
        }
    }
}

/**
 * Normaliza un DNI dejando solo dígitos. Respaldo por si el backend no envía
 * dni_visible. Se define también en pasajeros.js; como ambos archivos cargan
 * siempre juntos, el nombre de la función debe coincidir. Si ya está definida,
 * no se redefine.
 */
if (typeof normalizar_dni_js !== 'function') {
    window.normalizar_dni_js = function(dni) {
        return String(dni || '').replace(/\D+/g, '');
    };
}

// Listeners globales de actividad
document.addEventListener('mousemove', registrar_actividad_usuario);
document.addEventListener('keydown', registrar_actividad_usuario);
document.addEventListener('click', registrar_actividad_usuario);
document.addEventListener('touchstart', registrar_actividad_usuario);

/**
 * Aplica o quita el disabled de los botones que modifican el
 * asiento (Reservar, Liberar, Asignar, Liberar reserva) segun
 * si hay una venta en curso. Los botones de lectura (Ver pasaje,
 * Ver compra) quedan siempre activos.
 *
 * Se llama desde renderizar_tarjetas_asientos y desde el hook
 * que expone ventas.js al abrir/cerrar el modal de venta.
 */
function actualizar_bloqueo_botones_asientos() {
    const bloqueado = _venta_en_curso();
    const selectores = [
        '.btn-reservar-asiento',
        '.btn-liberar-seleccion',
        '.btn-asignar-pasajero',
        '.btn-liberar-reserva'
    ];
    selectores.forEach(sel => {
        document.querySelectorAll(sel).forEach(btn => {
            btn.disabled = bloqueado;
        });
    });
}

window.actualizar_bloqueo_botones_asientos = actualizar_bloqueo_botones_asientos;

// ============================================================
// v77c: cambiar de asiento de un pasaje.
//
// El modal pide los datos al backend (estado de asientos +
// configuración del micro), arma el croquis, deja elegir un
// asiento nuevo y hace el POST a `viajes/cambiar_asiento`.
// Funciona desde el croquis (viajes-asientos.js) y desde la
// pestaña Clientes (pasajeros.js).
// ============================================================

// Estado del modal de cambiar asiento.
let cambiar_asiento_datos_modal = null;

/**
 * Determina si el usuario actual puede cambiar el asiento dado.
 * Reglas:
 *  - Dueño/admin/soporte: puede mover vendidos y reservados.
 *  - Terminal: solo puede mover asientos vendidos por él mismo.
 */
function _puede_cambiar_asiento(asiento) {
    if (!asiento) return false;
    if (!asiento.tiene_pasajero) return false;
    if (asiento.estado !== 'vendido' && asiento.estado !== 'reservado') return false;

    if (usuario_actual.nivel === 'dueno' || es_admin_o_soporte()) return true;

    if (usuario_actual.nivel === 'terminal') {
        if (asiento.estado === 'reservado') return false;
        return asiento.venta_terminal === usuario_actual.nombre_usuario;
    }
    return false;
}

/**
 * Determina si un asiento es válido como destino del cambio.
 *
 * @param {object} a            Asiento candidato (estado + tiene_pasajero).
 * @param {string} estado_origen 'vendido' o 'reservado'.
 * @param {boolean} es_terminal  Si el usuario actual es terminal.
 */
function _es_destino_valido(a, estado_origen, es_terminal) {
    if (!a) return false;
    if (a.tiene_pasajero === true) return false;
    if (a.estado === 'vendido') return false;
    if (a.estado === 'seleccionado') return false;
    if (a.estado === 'no disponible') return false;

    if (es_terminal) {
        return a.estado === 'libre';
    }
    return a.estado === 'libre' || a.estado === 'reservado';
}

/**
 * Abre el modal de cambio de asiento.
 *
 * @param {string} nombre_dueno
 * @param {string} nombre_viaje
 * @param {string} nombre_micro
 * @param {string} fila_origen
 * @param {string} columna_origen
 */
async function abrir_modal_cambiar_asiento(nombre_dueno, nombre_viaje, nombre_micro, fila_origen, columna_origen, on_exito, piso_origen = null) {
    if (_venta_en_curso()) {
        mostrar_aviso('Hay una venta en curso. Termínala o cancelala antes de cambiar un asiento.', 'error');
        return;
    }

    // Fetch de estado de asientos.
    let estados = [];
    try {
        const r = await fetch("index.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({
                accion: "viajes/estado_asientos",
                nombre_viaje,
                nombre_micro,
                nombre_dueno
            })
        });
        const d = await r.json();
        if (!d.exito || !Array.isArray(d.asientos)) {
            mostrar_aviso(d.error || 'No se pudo cargar el estado de asientos', 'error');
            return;
        }
        estados = d.asientos;
    } catch (e) {
        console.error('Error cargando asientos:', e);
        mostrar_aviso('Error de comunicación', 'error');
        return;
    }

    // Fetch de configuración del micro.
    let micro_data = null;
    try {
        const r = await fetch("index.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({
                accion: "viajes/obtener_micro",
                nombre_viaje,
                nombre_micro,
                nombre_dueno
            })
        });
        const d = await r.json();
        if (!d.exito || !d.micro) {
            mostrar_aviso(d.error || 'No se pudo cargar el micro', 'error');
            return;
        }
        micro_data = d.micro;
    } catch (e) {
        console.error('Error cargando micro:', e);
        mostrar_aviso('Error de comunicación', 'error');
        return;
    }

    const origen = _buscar_asiento_en_estados(estados, piso_origen, String(fila_origen), String(columna_origen));
    if (!origen) {
        mostrar_aviso('No se encontró el asiento actual', 'error');
        return;
    }
    if (!origen.tiene_pasajero) {
        mostrar_aviso('El asiento actual no tiene pasajero asignado', 'error');
        return;
    }

    const es_terminal = usuario_actual.nivel === 'terminal';

    // Guardar estado del modal.
    cambiar_asiento_datos_modal = {
        dueno: nombre_dueno,
        viaje: nombre_viaje,
        micro: nombre_micro,
        origen_piso: (piso_origen !== null && piso_origen !== undefined) ? String(piso_origen) : '',
        origen_fila: String(fila_origen),
        origen_columna: String(columna_origen),
        origen_numero: origen.numero,
        origen_estado: origen.estado,
        origen_venta_id: origen.venta_id || null,
        origen_pasajero_dni: origen.pasajero ? origen.pasajero.dni : null,
        micro_config: micro_data.configuracion,
        destino: null,
        dejar_reservado: origen.estado === 'reservado',
        // v77d: callback opcional que el llamador puede pasar
        // para refrescar su propia UI tras el cambio (por
        // ejemplo, re-abrir el detalle del pasajero con el
        // asiento nuevo).
        on_exito: (typeof on_exito === 'function') ? on_exito : null
    };

    // Armar croquis.
    let croquis_html = '';
    const configuracion = micro_data.configuracion || {};
    if (configuracion.pisos && configuracion.pisos.length > 0) {
        configuracion.pisos.forEach((piso, index) => {
            croquis_html += `<div class="section-title">Piso ${index + 1}</div>`;
            croquis_html += '<div class="bus"><div class="bus-front">FRENTE · CONDUCTOR</div>';
            for (let f = 1; f <= piso.filas; f++) {
                croquis_html += '<div class="seat-row">';
                for (let c = 1; c <= piso.columnas; c++) {
                    const a = piso.asientos.find(x => parseInt(x.fila) === f && parseInt(x.columna) === c);
                    if (a) {
                        const piso_num = String(index + 1);
                        const a_estado = _buscar_asiento_en_estados(estados, piso_num, String(a.fila), String(a.columna));
                        const a_estado_str = a_estado ? a_estado.estado : 'libre';
                        const a_tiene_pas = a_estado ? (a_estado.tiene_pasajero === true) : false;
                        const es_origen = (String(a.fila) === String(fila_origen) && String(a.columna) === String(columna_origen) && (piso_origen === null || piso_origen === undefined || piso_origen === '' || String(piso_origen) === piso_num));
                        const valido = !es_origen && _es_destino_valido({ estado: a_estado_str, tiene_pasajero: a_tiene_pas }, origen.estado, es_terminal);
                        const clases = ['seat', `seat-${a_estado_str}`];
                        if (es_origen) clases.push('seat-origen');
                        if (!valido && !es_origen) clases.push('seat-deshabilitado');
                        if (valido) clases.push('seat-elegible');
                        croquis_html += `<div class="${clases.join(' ')}" data-piso="${piso_num}" data-fila="${a.fila}" data-columna="${a.columna}" data-numero="${a.numero}" data-valido="${valido ? '1' : '0'}" data-origen="${es_origen ? '1' : '0'}">${String(a.numero).padStart(2, '0')}</div>`;
                    } else {
                        croquis_html += '<div class="aisle"></div>';
                    }
                }
                croquis_html += '</div>';
            }
            croquis_html += '<div class="bus-back">PARTE TRASERA</div></div>';
        });
    } else {
        croquis_html = '<p class="muted">No hay configuración de asientos.</p>';
    }

    const checkbox_html = origen.estado === 'reservado'
        ? `<div class="field" style="margin-top:15px;">
            <label><input type="checkbox" id="cambiar_dejar_reservado" checked> Dejar el asiento viejo reservado (sin pasajero).</label>
           </div>`
        : '';

    const pasajero_nombre = origen.pasajero ? (origen.pasajero.nombre_completo || origen.pasajero.dni_visible || '') : '';

    const html = `
        <h3>Cambiar de asiento</h3>
        <p class="muted">Pasajero: <b>${pasajero_nombre}</b><br>Asiento actual: <b>${origen.numero}</b></p>
        <p class="muted small">Hacé click en el asiento nuevo. Los asientos elegibles están marcados.</p>
        <div style="max-height: 55vh; overflow-y: auto; border: 1px solid #ddd; border-radius: 6px; padding: 10px; background: #fafafa;">
            ${croquis_html}
        </div>
        <div class="legend" style="margin-top:10px;">
            <div class="legend-item"><span class="swatch sw-free"></span> Libre</div>
            <div class="legend-item"><span class="swatch sw-reserved"></span> Reservado sin pasajero</div>
            <div class="legend-item"><span class="swatch sw-sold"></span> Vendido</div>
        </div>
        ${checkbox_html}
        <div class="actions" style="margin-top:15px;">
            <button class="btn primary" id="btn_confirmar_cambiar_asiento" disabled>Confirmar cambio</button>
            <button class="btn" id="btn_cancelar_cambiar_asiento">Cancelar</button>
        </div>
    `;

    abrir_modal_apilado('Cambiar de asiento', html);

    const cont = document.getElementById('modal_apilado_contenido');
    if (!cont) return;

    cont.querySelectorAll('.seat').forEach(seat => {
        seat.addEventListener('click', () => {
            if (seat.dataset.valido !== '1') return;
            cont.querySelectorAll('.seat-elegido').forEach(s => s.classList.remove('seat-elegido'));
            seat.classList.add('seat-elegido');
            if (cambiar_asiento_datos_modal) {
                cambiar_asiento_datos_modal.destino = {
                    piso: seat.dataset.piso || '',
                    fila: seat.dataset.fila,
                    columna: seat.dataset.columna,
                    numero: seat.dataset.numero
                };
            }
            const btn = cont.querySelector('#btn_confirmar_cambiar_asiento');
            if (btn) btn.disabled = false;
        });
    });

    const chk = cont.querySelector('#cambiar_dejar_reservado');
    if (chk) {
        chk.addEventListener('change', () => {
            if (cambiar_asiento_datos_modal) {
                cambiar_asiento_datos_modal.dejar_reservado = chk.checked;
            }
        });
    }

    cont.querySelector('#btn_cancelar_cambiar_asiento').addEventListener('click', () => {
        cambiar_asiento_datos_modal = null;
        cerrar_modal_apilado();
    });
    cont.querySelector('#btn_confirmar_cambiar_asiento').addEventListener('click', _confirmar_cambiar_asiento);
}

/**
 * Confirma el cambio de asiento. Hace el POST y maneja el
 * resultado: refresca el croquis si corresponde, ofrece
 * reimprimir el pasaje.
 */
async function _confirmar_cambiar_asiento() {
    const d = cambiar_asiento_datos_modal;
    if (!d || !d.destino) return;

    const btn = document.getElementById('btn_confirmar_cambiar_asiento');
    if (btn) btn.disabled = true;

    try {
        const resp = await fetch("index.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({
                accion: "viajes/cambiar_asiento",
                nombre_viaje: d.viaje,
                nombre_micro: d.micro,
                piso_vieja: d.origen_piso || '',
                piso_nueva: d.destino.piso || '',
                fila_vieja: d.origen_fila,
                columna_vieja: d.origen_columna,
                fila_nueva: d.destino.fila,
                columna_nueva: d.destino.columna,
                nombre_dueno: d.dueno,
                nombre_solicitante: usuario_actual.nombre_usuario,
                dejar_reservado_viejo: d.dejar_reservado ? '1' : '0'
            })
        });
        const resultado = await resp.json();

        if (resultado.exito) {
            mostrar_aviso("Asiento cambiado", 'exito');

            // Snapshot antes de limpiar el estado.
            const snap = {
                estado: d.origen_estado,
                dueno: d.dueno,
                viaje: d.viaje,
                micro: d.micro,
                destino_fila: d.destino.fila,
                destino_columna: d.destino.columna,
                destino_numero: d.destino.numero,
                pasajero_dni: d.origen_pasajero_dni
            };

            // v77d: guardar el callback antes de limpiar el
            // estado, y ejecutarlo después de cerrar el modal
            // apilado. Se usa para que el llamador pueda
            // refrescar su UI (por ejemplo, el modal de detalle
            // del pasajero en la pestaña Clientes).
            const on_exito_snap = d.on_exito;
            cambiar_asiento_datos_modal = null;
            cerrar_modal_apilado();

            if (typeof on_exito_snap === 'function') {
                try { on_exito_snap(snap); } catch (e) { console.error(e); }
            }

            // Refrescar el croquis de atrás si estamos en el croquis.
            if (typeof viaje_seleccionado !== 'undefined' && viaje_seleccionado
                && viaje_seleccionado.nombre_viaje === snap.viaje
                && typeof micro_seleccionado !== 'undefined' && micro_seleccionado === snap.micro) {
                try { await solicitar_estado_asientos(); } catch (e) { console.error(e); }
                try { await refrescar_contadores_viaje_actual(); } catch (e) { console.error(e); }
                if (typeof refrescar_info_asientos_propios === 'function') {
                    refrescar_info_asientos_propios(true);
                }
            }

            // Ofrecer reimprimir el pasaje.
            if (snap.estado === 'vendido' && snap.pasajero_dni) {
                if (typeof mostrar_modal_chico_impresion_pasajero === 'function') {
                    mostrar_modal_chico_impresion_pasajero(snap.pasajero_dni, snap.dueno);
                }
            } else if (snap.estado === 'reservado') {
                if (typeof mostrar_modal_chico_impresion_reserva === 'function') {
                    mostrar_modal_chico_impresion_reserva(
                        snap.dueno,
                        snap.viaje,
                        snap.micro,
                        snap.destino_fila,
                        snap.destino_columna,
                        snap.destino_numero
                    );
                }
            }
        } else {
            mostrar_aviso(resultado.error || "No se pudo cambiar el asiento", 'error');
            if (btn) btn.disabled = false;
        }
    } catch (e) {
        console.error("Error al cambiar asiento:", e);
        mostrar_aviso("Error de comunicación", 'error');
        if (btn) btn.disabled = false;
    }
}
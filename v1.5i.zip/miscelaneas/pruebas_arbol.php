<?php
/**
 * Pruebas exhaustivas para el manejo de árbol con nodos.
 * Este archivo se incluye temporalmente en index.php para ejecutar las pruebas.
 *
 * @package   Iteradores
 * @since     1.5piloto.14
 */

use Iteradores\Nodos\Nodo;

// Función para imprimir resultados de prueba
function probar($condicion, $descripcion) {
    if ($condicion) {
        echo "✔ $descripcion\n";
    } else {
        echo "✘ $descripcion\n";
        exit(1); // Detener si falla
    }
}

// Incluir funciones de árbol
require_once __DIR__ . '/Arbol.php';

echo "=== Pruebas de Árbol ===\n";

// Crear nodos
$A = Nodo::crear_con_dato('A');
$B = Nodo::crear_con_dato('B');
$C = Nodo::crear_con_dato('C');
$D = Nodo::crear_con_dato('D');
$E = Nodo::crear_con_dato('E');
$F = Nodo::crear_con_dato('F');
$G = Nodo::crear_con_dato('G'); // para pruebas adicionales
$H = Nodo::crear_con_dato('H');

// Construir árbol inicial:
// A -> B, C
// B -> D, E
// C -> F

_hmi($A, $B);
_hd($B, $C);

_hmi($B, $D);
_hd($D, $E);

_hmi($C, $F);

// Verificaciones iniciales
probar(hmi($A) === $B, "El hijo más izquierdo de A es B");
probar(hd($B) === $C, "El hermano derecho de B es C");
probar(hd($C) === null, "C no tiene hermano derecho");
probar(p($B) === $A, "El padre de B es A");
probar(p($C) === $A, "El padre de C es A");
probar(hmi($B) === $D, "El hijo más izquierdo de B es D");
probar(hd($D) === $E, "El hermano derecho de D es E");
probar(hd($E) === null, "E no tiene hermano derecho");
probar(hmi($C) === $F, "El hijo más izquierdo de C es F");
probar(p($F) === $C, "El padre de F es C");

// Prueba de inserción de nuevo hijo más izquierdo en A
_hmi($A, $G); // G debería ser nuevo hmi de A, y su hd debe ser B
probar(hmi($A) === $G, "Después de insertar G como hmi, hmi(A) es G");
probar(hd($G) === $B, "El hermano derecho de G es B");
probar(hd($B) === $C, "El hermano derecho de B sigue siendo C");
probar(p($G) === $A, "El padre de G es A");

// Prueba de inserción de hermano derecho en medio (entre B y C)
_hd($B, $H); // Insertar H entre B y C
probar(hd($B) === $H, "Después de insertar H, el hermano derecho de B es H");
probar(hd($H) === $C, "El hermano derecho de H es C");
probar(p($H) === $A, "El padre de H es A");
probar(p($C) === $A, "C sigue teniendo padre A");

// Verificar que la lista de hijos de A desde hmi es G, B, H, C
$hijo = hmi($A);
$secuencia = [];
while ($hijo) {
    $secuencia[] = $hijo->dato();
    $hijo = hd($hijo);
}
probar($secuencia === ['G', 'B', 'H', 'C'], "La secuencia de hijos de A es G, B, H, C");

// Prueba de que p() devuelve null para raíz
probar(p($A) === null, "El padre de A es null");

echo "Todas las pruebas pasaron correctamente.\n";